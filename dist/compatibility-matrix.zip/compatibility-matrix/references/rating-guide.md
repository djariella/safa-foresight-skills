# Rating guide

## Contents

1. Five tests for an end state
2. The question and the five ratings
3. Rules for rating
4. Three kinds of reason for an X
5. An illustration
6. What a healthy result looks like
7. Common mistakes
8. Large fields, contested ratings and pairs that cannot be judged
9. Other words for the same ratings
10. Who rates, and how much to trust the ratings
11. What pair ratings cannot see

## 1. Five tests for an end state

Check these before rating. Poor end states produce poor skeletons whatever the ratings are.

1. **It is a state.** It describes what is true in the target year. "Buses run every ten minutes on the main routes" is a state. "Invest in buses" is an action.
2. **It belongs to the room.** Every part of the description can be traced to a flipchart, a post-it or something said at the table. Anything the team added or merged is noted in `team_note` and confirmed with the table facilitator.
3. **It is different from the others.** Two end states of the same uncertainty cannot both be true at the same time.
4. **The set covers the range.** There is more than a best case and a worst case. Look for a middle or mixed end state: good for some and hard for others, or solved in an unexpected way. If a table reported only two extremes, look in its transcript for a third and propose it to the team.
5. **The name is neutral.** Four to eight words that describe the situation without judging it.

Two to four end states for each uncertainty is the working range. If a table gives five or more, propose merging the closest.

## 2. The question and the five ratings

Compare every end state with every end state of every other uncertainty. Never compare two end states of the same uncertainty.

**The question: can both be true in this country in the target year?**

| Rating | Meaning | How to recognise it |
|---|---|---|
| S | They support each other | One makes the other more likely. People expect to see them together. |
| I | They can sit side by side | Neither affects the other much. |
| T | An unusual pairing that can still be true | People do not usually put these together. It needs a story to explain how both happened. |
| X | They cannot both be true | As the end states are written, one rules out the other. |
| Q | Not decided | Bring it to the team. Every Q becomes S, I, T or X before the analysis is final. |

## 3. Rules for rating

- **Rate the end states as they are written.** Read the full description of each, not only the name. If one description contains something the other excludes, that is X even if the names look compatible.
- **Use X only for a real contradiction.** Unlikely is not impossible. If someone can tell a believable story in which both are true, the rating is T.
- **Check the time horizon.** Some pairs could both be true eventually, but not by the target year. Count the years.
- **Check whether the story changes an end state.** If the only way to make a pair work is to change one end state into a different end state of the same uncertainty, the original pair is X.
- **T is valuable.** The unusual pairings are where scenarios stop being a best case and a worst case. Look for them on purpose: a good thing that happens alongside a hard thing, or a result reached by an unexpected route.
- **Do not let the topic decide the rating.** Whether the pair is good or bad for the workshop's topic is irrelevant here. Only ask whether both can be true.
- **Write the reasoning.** One line for every pair. A story for every T. For every X, the words that contradict. The reason has to explain the rating and not only restate it.
- **Possibility, not likelihood.** The test is whether any believable pattern exists in which both are true. How probable that pattern is does not matter at this step.
- **Direct relationships only.** If A and C clash only because of B, record the clash on A with B and on B with C. Recording it on A with C as well is a known fault in this method and removes too much.

## 4. Three kinds of reason for an X

| Kind | Meaning | Counts as X? |
|---|---|---|
| Logical | The wording of one end state rules out the other. | Yes |
| Empirical | Nothing in the wording conflicts, but it cannot happen in this place by the target year: there is not enough time, money, water, people or law for both. | Yes, with the reason written down |
| Normative | People do not want this pairing, or think it would be wrong. | No. Rate it T and tell the story. What people want belongs to the vision on day 2. |

Record the kind on every X. If the team cannot say which kind it is, the pair is probably a T.

## 5. An illustration

These pairs are invented to show the reasoning. They do not come from a workshop. The topic is public transport in a made-up country. The target year is 2045 and the ratings are made in 2027, so the horizon is 18 years.

| Pair | Rating | Reasoning |
|---|---|---|
| H1 Most new homes are in town centres, with F1 Fares and rates pay for frequent services | S | Many people living close together make a frequent service cheaper to run, and a frequent service makes the centre a better place to live. |
| W3 Most people work from home three days a week, with P1 Transport policy is stable for a decade | I | Neither changes the other much. |
| H2 Towns spread outward along the highways, with F1 Fares and rates pay for frequent services | T | Story: a levy on every new estate pays for buses to reach it, and councils agree the routes before the land is released. |
| H1 Most new homes are in town centres, with W2 One large employer on the edge of each town | T | Started as Q. The team's story: the employer runs its own shuttles from the centre, and the council plans around them. |
| H1 Most new homes are in town centres, with F3 Private operators run only what pays | X, logical | F3 as written has no services in town centres after 7 pm. H1 as written has centres where people live without cars. |
| H3 People leave the towns for the capital, with F1 Fares and rates pay for frequent services | X, empirical | Nothing in the wording conflicts. The team judged that towns losing residents could not raise enough in rates to pay for frequent services within 18 years. |

## 6. What a healthy result looks like

These are guide values from practice. They are not rules.

- Most pairs are S or I.
- A good number are T, each with a story the team believes. With no T at all, the skeletons will be a best case and a worst case.
- A few are X. Each X removes many combinations, because it removes every combination that contains that pair.
- The X ratings together remove between a quarter and two thirds of the combinations.
- Every end state appears in at least one surviving combination. If one does not, its ratings are too strict or it contradicts the rest of the room's picture. Tell the team.
- Several survivors have every pair supporting each other. They are the futures people reach for first, and the anchor for the set is usually one of them.

## 7. Common mistakes

- **Rating what is desirable instead of what is possible.** A pairing the team dislikes is not X.
- **Too many X.** The survivors are few and predictable. Go back through each X with the four checks: as written, impossible or only unlikely, within the horizon, does the story change an end state.
- **No X at all.** Every combination survives and the analysis gives no structure. Look for pairs where the descriptions contradict each other.
- **Rating from the names only.** The contradiction is often in the description.
- **Treating I and S as the same.** It matters later: combinations where every pair is S are the "expected" futures, and the set should include some that are not.
- **Leaving Q in the file.** A Q is a question for the team. It is not a rating.

## 8. Large fields, contested ratings and pairs that cannot be judged

**Large fields.** With six or more uncertainties, mark first how strongly each pair of uncertainties is linked: strong, conditional or independent (`python scripts/morph.py couplings FILE`). End states of independent uncertainties are rated I without discussion. The team then rates only the pairs from linked uncertainties. Keep to at most eight uncertainties and at most four end states each. Beyond that the matrix cannot be reviewed by people in an afternoon.

**Contested ratings.** When the team is split, record the majority view and mark the pair `"contested": true`. The sensitivity check in the morphological-analysis skill shows whether the disagreement changes which skeletons are possible. Often it does not, and the team can move on.

**A pair that cannot be judged.** If nobody can say whether two end states fit, one of them is usually unclear, or two end states of the same uncertainty overlap. Go back to the wording with the table facilitator before rating.

**Second opinions.** For a written scenario study, as opposed to a workshop, have two people rate the matrix separately and compare. The pairs where they differ are the ones to discuss.

## 9. Other words for the same ratings

SA Futures Agency's desk studies sometimes use three words. They map onto the letters like this.

| Elsewhere | Letters here |
|---|---|
| SA Futures Agency desk studies: consistent | S or I |
| SA Futures Agency desk studies: tension, plausible only with a named mechanism | T, with the mechanism as the story |
| SA Futures Agency desk studies: contradiction | X |
| Ritchey's morphological analysis: fits; possible but on the boundary; impossible | S or I; T; X |
| Ritchey: a pair of parameters with no direct connection, left blank | I for every pair in that block |
| Scenario technique, scale of 1 to 5 (Kosow and Gaßner): 5 strong mutual support, 4 mutual support, 3 neutral, 2 weak inconsistency, 1 strong inconsistency | S; S; I; T; X |

Studies that use a number scale, such as 1 to 5 or minus 3 to plus 3, are measuring the same thing in more steps. The letters are quicker to agree on and easier to explain to a room.

## 10. Who rates, and how much to trust the ratings

Ritchey's guidance for expert studies is a group of six to eight people with knowledge of the subject and a facilitator who has no stake in the result. A workshop facilitation team of four to six people who sat at the tables is close to that. The table facilitators supply the knowledge of what each table meant. The lead facilitator, or Claude, holds the method.

There is little published evidence on how far two groups would agree on the same matrix. The method's defence is procedural: a written reason for every rating, a review of every X and every unusual pairing by the whole team, contested ratings marked and tested, and the matrix published with the report. Do all four.

## 11. What pair ratings cannot see

A matrix checks two end states at a time. Three end states can clash as a group although each pair of them is possible. The remedy in the literature is to read the shortlisted combinations as wholes after the pair check. The scenario-families skill does this for every candidate.
