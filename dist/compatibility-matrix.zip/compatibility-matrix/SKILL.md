---
name: compatibility-matrix
description: Build the compatibility matrix for scenario end states. Rates every pair as supporting, independent, unusual, impossible or undecided, with reasons, and prepares the team review. Step 1 of 4.
---

# Compatibility matrix

This is the first of four skills that take a facilitation team from end states to scenario skeletons: **compatibility-matrix**, then morphological-analysis, then scenario-families, then scenario-set-selection. It was developed by Ariella Helfgott and SA Futures Agency.

The compatibility matrix asks one question of every pair of end states from different uncertainties: can both be true in this country in the target year? In the research literature this step is called a cross-consistency assessment. Everything after it depends on it. A careless matrix gives scenarios that contradict themselves or that are only a best case and a worst case.

The people using this skill have usually done this once, with expert help. They may not know what a good matrix looks like. Explain each step, show your reasoning, and keep saying whose decision each rating is: the team's.

## What you need

- The workshop file with `uncertainties` and `end_states` filled in (`references/workshop-file.md`). If the end states are not written up, use the day1-capture-to-end-states skill first.
- The full description of every end state, and ideally the table transcripts.
- The country, the topic and the target year.

## Steps

### 1. Check the end states first

Test each end state against the five tests in `references/rating-guide.md`. Report problems and suggest fixes. Do not silently rewrite the room's words. Poor end states cannot be rescued by good ratings.

### 2. Start with the uncertainties

Ask first, for each pair of uncertainties, whether one bears directly on the other. This is how the method's main author, Tom Ritchey, begins a cross-consistency assessment, and it takes a few minutes. With up to five uncertainties it is optional. With six or more it is needed, because there are hundreds of pairs of end states. Run:

```
python scripts/morph.py couplings FILE
```

It lists every pair of uncertainties. With the team, mark each as strong, conditional or independent. Pairs of end states from independent uncertainties are then set to I automatically, and the team's time goes to the pairs that matter.

### 3. Draft a rating for every pair

```
python scripts/morph.py template FILE
```

This adds every missing pair. Rate each one:

- **S** they support each other
- **I** they can sit side by side
- **T** an unusual pairing that can still be true, and needs a story
- **X** they cannot both be true, as the end states are written
- **Q** you are unsure, and the team should decide

Read `references/rating-guide.md` before rating. For every pair write one line of `reason`. For every T write the `story` of how both came to be true. For every X write which words contradict and give the `kind`: `logical` (the wording of one rules out the other) or `empirical` (it cannot happen in this place by the target year). A pairing that people do not want is not a contradiction. Rate it T.

Three rules matter most, and all three come from the research on this step:

- **Judge whether both can be true. Do not judge how likely it is.** If you can think of any believable pattern in which the two could exist together, the pair is not X.
- **Rate the direct relationship only.** If two end states clash only because of a third, that clash belongs to the pairs with the third. Counting it here as well removes combinations twice over.
- **The reason has to explain.** "These contradict each other" repeats the rating. "F3 has no services in town centres after 7 pm, and H1 has centres where people live without cars" explains it.

Use Q freely. A draft that sends eight honest questions to the team is worth more than one that guesses.

### 4. Check

```
python scripts/morph.py check FILE
```

Fix everything it reports. It also flags two things worth telling the team: an end state that is shut out because it is rated X against every end state of another uncertainty, and two end states of the same uncertainty that have the same rating against everything, which may mean they are one end state written twice. Then tell the user the counts of each rating and whether they look healthy, using the guide values in the rating guide.

### 5. Give the team something to review

Two options, and most teams want both:

- `python scripts/review_pack.py FILE` writes a branded page with the end states, the rating key, the coloured matrix, every X with its reason, and every T with its story.
- `python scripts/morph.py pairs-export FILE` writes a spreadsheet file the team can rate in directly. `pairs-import` reads it back.

### 6. Support the review

`references/team-review.md` has the agenda and the questions to ask. The team goes through every X, every Q and every T. As they decide, update the file. When the team is split on a pair, record the majority rating and set `"contested": true` on it. The next skill tests what depends on the contested ratings, which usually lets the team move on without settling every argument.

## What good looks like

- Every pair has a rating and a reason, no Q is left, every T has a story and every X has a kind.
- Most pairs are S or I. A good number are T. A few are X.
- Each table facilitator recognises their table's end states in the reasons.
- The team can explain any X to a participant in one sentence.

## Next

Hand over to the **morphological-analysis** skill.

Follow `references/writing-rules.md` and `references/brand.md`. `references/method-background.md` explains where the method comes from.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
