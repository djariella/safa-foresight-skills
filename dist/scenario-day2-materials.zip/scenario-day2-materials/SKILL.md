---
name: scenario-day2-materials
description: After skeletons are chosen, make day 2 workshop materials - recap and skeleton slides, placemat 2 per table, facilitator packs and read-aloud scenario descriptions. Use on the evening of day 1.
---

# Scenario day 2 materials

On the evening of day 1 the facilitation team has chosen its scenario skeletons. By the next morning every table needs a skeleton it can build on, and every table facilitator needs to know how to support it. This skill produces the five things that make that happen. It was developed by Ariella Helfgott and SA Futures Agency.

The team is tired and short of time at this point. Work fast, keep questions to the ones that matter, and give them files they can print without further editing.

## What you need

- The workshop file with `skeletons` filled in (see `references/workshop-file.md`). If the skeletons are not chosen yet, use the four skeleton skills first: compatibility-matrix, morphological-analysis, scenario-families and scenario-set-selection.
- Which table and facilitator has which skeleton.
- The country's fact base, for the read-aloud descriptions and the facilitator packs.
- The workshop deck, to add the recap and skeleton slides.

## What you make, in this order

### 1. Placemat 2 for each table

```
python scripts/build_placemats.py CONFIG.json placemat-2-by-table.pptx --skeletons WORKSHOP.json
```

One A3 page for each skeleton, with that table's end states written in step 1. `CONFIG.json` is the placemat configuration used for the workshop's other placemats (`assets/example/placemats.config.json` shows the form). The team prints enough copies for each table. This is the most urgent item, because printing takes longest.

### 2. The facilitator pack

For each skeleton, write a `pack` block in the workshop file: five or six prompts about the topic inside this skeleton, one question each on what it means for people, nature and the economy, and two or three things to watch for. `references/facilitator-pack.md` says how to write them. Then:

```
python scripts/facilitator_pack.py WORKSHOP.json
```

This writes `facilitator-pack.html`: two general pages for every facilitator (the job at the table, the 90 minutes, how to facilitate, twelve prompts, what to do if the table gets stuck) and one page for each skeleton. Open it in a browser and print to PDF, one copy for each facilitator.

Headings 2 to 5 on the prompts page are the four main parts of the system the workshop is about. They come from `system_parts` in the workshop file, which also sets the first four prompts on placemat 2 (see `references/facilitator-pack.md`). Write them for the topic before building the pack. To change any other wording on the general pages, edit `assets/pack_general.html`.

### 3. Read-aloud descriptions

One for each skeleton, read to the whole room before the tables start. One to two minutes aloud, which is 250 to 330 words. `references/read-aloud-descriptions.md` has the rules and the pattern. The short version: present tense, set in the target year, sourced present-day facts from the fact base, the main mechanisms that connect the end states, no characters, no invented numbers, and the skeleton's question at the end.

### 4. Recap and skeleton slides

Add these to the workshop deck. `references/recap-slides.md` lists each slide, what goes on it and what the lead facilitator says. Build them in the same template as the rest of the deck, with one card for each end state and one column for each uncertainty. Put the read-aloud description in the notes of each skeleton slide.

### 5. A topic briefing for facilitators, if there is time

One or two pages on what the workshop's topic means inside each skeleton, drawn from the fact base and the hosts' own research. It helps facilitators who know the method less well than the topic, or the topic less well than the method.

## Before you hand over

- Every end state on every placemat, slide and pack page matches the workshop file word for word.
- Every skeleton has a table and a facilitator, and they match across all materials.
- Every present-day fact in a description or pack has a source in the fact base.
- Titles are neutral working titles, and the materials say the table will choose its own name.
- The files are named with the workshop, the day and what they are.

## Writing and design

Follow `references/writing-rules.md` and `references/brand.md`.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
