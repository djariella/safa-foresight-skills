# Read-aloud descriptions

Before the tables start building, the lead facilitator reads a short description of each skeleton to the whole room. It gives every table the same starting picture and shows that the skeleton is grounded in facts about the country today.

## Rules

- **Length.** One to two minutes aloud: 250 to 330 words. Short sentences. It will be interpreted.
- **Present tense, in the target year.** Open with "It is [year], and ..."
- **Facts first.** Use present-day facts from the fact base, with the year, to show where each change started: "In [year] about [figure] of [what was measured]. By [target year] [the direction it has moved]." Do not invent numbers for the future. Describe the direction.
- **Mechanisms.** Say what caused what. How does one end state lead to another? Use the paragraph on how the skeleton fits together and the team's stories for the unusual pairings.
- **No characters.** No named or invented people, no "imagine", no scene-setting.
- **Both sides.** Every description has things that work and things that are hard, whichever skeleton it is.
- **No closing summary.** End with the skeleton's question about the topic, then one line asking the table to make it believable.
- **Sources.** After the text, a line marked "Background, not to read aloud" that names the source of each figure.

## How it sits in the speaker notes

```
Say: Skeleton A. [Working title]. This skeleton goes to [name]'s table.

In [year], [n] things are true. [End state 1]. [End state 2]. ...

Do: now read the description. It takes just under two minutes.

Say: It is [year], and ...

Your question: ...

[One line to the table.]

Background, not to read aloud: ...
```

## The pattern, paragraph by paragraph

1. **Open.** "It is [year], and [the one condition that makes the rest of this skeleton possible]."
2. **One paragraph for each link in the chain**, two to four in all. Each starts from a present-day fact with its year and figure, then says what is true in the target year and what caused it: "In [year] [fact, with its figure]. By [target year] [the direction of change], because [mechanism]."
3. **What is hard.** One paragraph on what this future costs, who pays for it, and what has been lost since the base year. Every skeleton has one, including the most hopeful.
4. **Close.** "Your question: [the skeleton's question about the topic]." Then one line asking the table to make it believable.

Check every figure against the fact base before the description is read to the room.
