# Writing the facilitator pack

The pack has two parts. The general pages are the same for every table and come from `assets/pack_general.html`. The skeleton pages are written fresh for every workshop, one for each skeleton, and stored in the workshop file under each skeleton's `pack` block.

## What a table facilitator needs to hear

The end states are the boundary conditions. They are true in the target year and the table does not change them. Inside those boundaries the table works out two things: what happens to the workshop's topic in this scenario, and what that means for people, nature and the economy. The end states do not say what happens to the topic. That is the table's work.

## The four main parts of the system

The first four of the eight prompts on placemat 2, and headings 2 to 5 on the prompts page of this pack, are the main parts of the system the workshop is about. Set them in the `workshop` block. The workshop file and the placemat configuration each have a `workshop` block, so put the same four parts in both:

```json
"system_parts": [
  ["Daily trips", "How do people get to work and school?", "How do people get to work and to school on an ordinary day? How long does it take, what does it cost, and who cannot make the trip?"],
  ["Buses and trains", "What runs, how often, and who runs it?", "Which services run, how often and until what time? Who runs them: government, companies, communities? Who works on them?"],
  ["Roads and paths", "What has been built? What is in poor repair?", "What has been built since the base year, and what is in poor repair? Who can walk or cycle safely?"],
  ["Paying for it", "Who pays: riders, ratepayers, employers?", "Who pays for services and for roads: riders, ratepayers, employers, national government? What has been cut?"]
]
```

Each part has a title of one to three words (18 characters at most, so it fits the placemat tile), a short question for the tile, and a longer prompt for the pack. The example above is for public transport. If `system_parts` is missing, the programs use four general parts: who uses the system, who provides it, what it depends on, and what is left over.

## The skeleton page

```json
"pack": {
  "prompts": ["...", "..."],
  "means": {"people": "...", "nature": "...", "economy": "..."},
  "watch_for": ["...", "..."]
}
```

**Prompts (five or six).** Each prompt takes one thing that is true in this skeleton and asks what it does to the topic. Start with a prompt that follows something concrete through the system. Use the details in the end state descriptions, and the stories the team told for the unusual pairings. End with a prompt about what still does not work. Questions only. Do not give answers.

An illustration, invented for this guide. The topic is public transport, and in this skeleton towns spread outward while services are well funded:

- Follow one person's trip to work from a new estate to the town centre. Which services do they use, how long does it take and what does it cost?
- A levy on new estates pays for the buses. Who sets it, who collects it, and what happens in a year when little is built?
- The large employers agree shift times with the bus operators. Who is at that table, and who is not?
- What still cannot be reached without a car, and who does that leave out?


**What it means (three questions).** One each for people, nature and the economy. In the hopeful skeleton, ask who still misses out and what it costs. In the worrying skeleton, ask who copes and how.

**Watch for (two or three).** The ways this particular table is likely to go off course, with what to say.

| Skeleton | Likely to | What to say |
|---|---|---|
| The most hopeful | Write a wish list, or describe its vision | "What did it take to get here, what went wrong on the way and who had to give something up?" The vision session is in the afternoon. |
| The most worrying | Stop at "everything is bad" | "How do people cope? Who still does well? What do communities do for themselves?" |
| One with unusual pairings | Say it could never happen | "Suppose it has. What had to happen for us to be here?" |
| One that many would call a success | Skip who loses | "Who is worse off than today?" |

## The general pages

Check these against the run sheet before printing: the times of the four steps, the time of the report-back, the number of uncertainties, and the languages people may speak in. The twelve prompt headings on page 2 match the eight prompts on placemat 2, with four more: first impressions, knowledge and values, who gains and who loses, and how we got here.

## Walk-through

Before the morning session, the lead facilitator walks each table facilitator through their page: read the end states, say how they fit together, and ask the facilitator to explain back why the skeleton is possible.

## Three rules for every table, from the research

- **The skeleton is the setting. It is not a plan.** Scenarios describe what the table cannot control. Goals and actions come in the afternoon. This separation is central to the CGIAR regional scenarios work (Vervoort and colleagues 2014).
- **Do not change the scenario to make an idea work.** If a table's idea fails in its scenario, that is a finding. The UK Government Office for Science gives the same rule for testing policies against scenarios.
- **Every scenario has both difficulties and openings**, whichever skeleton it started from.

One guide for forest-sector scenarios lets facilitators change a factor when a group finds its scenario incoherent. This workshop does not, because the team has already checked every skeleton, and a changed skeleton can no longer be compared with the others. If a table makes a strong case that its skeleton cannot hold together, the table facilitator notes it and tells the lead facilitator at the break.

Speaking in the present tense, as if living in the target year, is a practitioner convention. It works, and it is not something the research prescribes.
