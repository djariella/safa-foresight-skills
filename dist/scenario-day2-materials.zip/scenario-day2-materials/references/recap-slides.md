# The recap and skeleton slides

These open day 2. They show the room that the skeletons are made entirely from its own work. They take about 20 minutes with every slide, and about 17 with the optional ones left out.

| Order | Title pattern | On the slide | The facilitator says |
|---|---|---|---|
| 1 | From your tables' work to [n] skeletons | Eight number tiles: uncertainties, end states, pairs rated, possible combinations, survive the check, families, candidates, skeletons | "Here is what happened after you left yesterday." One sentence for each number. |
| 2 | [n] uncertainties, [m] end states | One column for each uncertainty, with the codes and names of its end states | "This is what you told us yesterday. Please tell us if we have recorded anything incorrectly." |
| 3 | One slide for each uncertainty | A card for each end state: code, name, description | Thank the table. Read the names. Ask "Have we recorded these correctly?" Take corrections. |
| 4 | How each pair of end states is rated | The four ratings with their meanings and counts | The question for every pair, and the four ratings |
| 5, optional | All [k] pairs in one matrix | The coloured matrix | "You do not need to read every square. Most are S. The dark squares are the pairs that cannot both be true." |
| 6 | [x] pairs that cannot be true together | Each pair, its reason, and how many combinations it removes | One sentence for each pair. Then how many combinations were set aside. |
| 7, optional | Unusual pairings in the skeletons | The unusual pairs that appear in the chosen skeletons, with their stories | "The unusual pairings are where the interesting scenarios come from." |
| 8, optional | Of [c] combinations, [s] survive | Four tiles and three or four patterns | The numbers, and that a useful set needs more than the futures people reach for first |
| 9, optional | Families | The grid of families, with the anchor marked | The two questions that separate the stories most |
| 10, optional | Candidates | A table of candidates with their end states | One candidate from each family |
| 11 | The questions [the topic] has to face | The topic questions, with where each was heard | Read each question. "We wanted scenarios that between them make us answer all of these." |
| 12, optional | Which candidate raises which question | The table of candidates against questions | What "central" means, and why this set |
| 13 | The [n] skeletons | A table: one column for each skeleton, one row for each uncertainty | Name each. "The names are working titles. Your table will give its scenario its own name." |
| 14 | One slide for each skeleton | End states on the left. "How it fits together" and "What it asks about [topic]" on the right | Read the end states. Read the description. Read the question. Name the table. |

Numbers and text come from the workshop file and from `analysis.json`, which the morphological-analysis skill writes. Do not retype them from memory.

Mark the optional slides in their notes with "Skip this slide if time is short." as the first line.

After the last skeleton slide comes "What makes a good scenario": plausible, grounded, coherent, honest. These four are the workshop's own wording. They cover the tests that recur in the literature for a single scenario, which are plausibility, internal consistency, relevance and challenge. For the set as a whole the recurring tests are difference, range and being comparable, and the selection criteria have already taken care of those.
