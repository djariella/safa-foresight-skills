#!/usr/bin/env python3
"""Build the facilitator pack for scenario building: two general pages for every table
facilitator, then one page for each skeleton. Output is one HTML file to open in a browser
and print to PDF (A4), one copy for each table facilitator.

Usage:  python facilitator_pack.py WORKSHOP.json [OUT.html]

Each skeleton in the workshop file needs a "pack" block:
  "pack": {"prompts": ["...", "..."],                      five or six prompts about the topic inside this skeleton
           "means": {"people": "...", "nature": "...", "economy": "..."},
           "watch_for": ["...", "..."]}
See references/facilitator-pack.md for how to write them.
"""
import base64, html, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "assets")
CSS = """
@page { size: A4; margin: 12mm 14mm 11mm 14mm; }
* { box-sizing: border-box; }
body { font-family: Helvetica, Arial, 'Liberation Sans', sans-serif; font-size: 9pt; line-height: 1.27; color: #22303C; margin: 0; }
section { page-break-before: always; }
section:first-of-type { page-break-before: auto; }
.top { display: flex; align-items: center; gap: 5mm; margin-bottom: 2mm; }
.top img { height: 5mm; } .top .r { margin-left: auto; } .top .r img { height: 3.8mm; }
.eyebrow { font-size: 8pt; letter-spacing: .09em; text-transform: uppercase; color: #E86933; font-weight: bold; margin: 0 0 1mm; }
h1 { font-size: 17pt; line-height: 1.1; color: #28537D; margin: 0 0 1.2mm; }
.lede { font-size: 9.8pt; color: #5B6770; margin: 0 0 1.5mm; }
h2 { font-size: 11pt; color: #28537D; margin: 2.8mm 0 1.1mm; padding-bottom: .5mm; border-bottom: .7pt solid #28537D; }
p { margin: 0 0 1.3mm; }
ul, ol { margin: 0 0 0 4.4mm; padding: 0; }
li { margin-bottom: .75mm; }
table { border-collapse: collapse; width: 100%; }
th, td { border: .5pt solid #B9C8D6; padding: 1.1mm 1.7mm; vertical-align: top; text-align: left; }
th { background: #28537D; color: #fff; font-size: 8.8pt; }
.box { border: .9pt solid #0297A6; background: #E9F6F8; padding: 1.8mm 2.5mm; }
.who { border: .5pt solid #B9C8D6; padding: 1.6mm 2.2mm; margin: 1.2mm 0 0; font-size: 9.4pt; }
.cols { column-count: 2; column-gap: 7mm; }
.g { break-inside: avoid; margin-bottom: 1.5mm; }
.g b { color: #28537D; }
.g p { margin: 0; }
.tag { display: inline-block; background: #E86933; color: #fff; font-size: 8pt; padding: 0 1.4mm; border-radius: 1mm; margin-left: 1mm; }
.foot { font-size: 7.6pt; color: #7a8791; margin-top: 2mm; }
.small { font-size: 8.6pt; }
.tight td, .tight th { padding: .75mm 1.7mm; }
td.c1 { width: 24mm; font-weight: bold; color: #28537D; }
td.c2 { width: 47mm; font-weight: bold; }
"""


def e(s):
    return html.escape(str(s or ""))


def general_parts(system):
    """The four main parts of the system, used when the workshop block has no "system_parts".
    The same list is in build_placemats.py. Each part: [title, short question, longer prompt]."""
    return [["Who uses it", "Who uses it? What do they get from it?", f"What do people get from the {system} on an ordinary day? What does it cost them, and who goes without?"],
            ["Who provides it", "Who does the work, and how?", "Who provides it: public bodies, businesses, cooperatives, households? Are they young or old, women or men? What do they earn?"],
            ["What it depends on", "Which resources? Where from?", f"Which resources does the {system} depend on: land, water, energy, materials, skills, money? Where do they come from, and who controls them?"],
            ["What is left over", "What is wasted or lost? Where does it go?", "What is wasted, lost or polluted along the way, and where does it go? What is used again, and by whom?"]]


def img(name):
    p = os.path.join(ASSETS, "brand", name)
    if not os.path.exists(p):
        return ""
    return '<img src="data:image/png;base64,' + base64.b64encode(open(p, "rb").read()).decode() + '">'


def build(path, out=None):
    w = json.load(open(path, encoding="utf-8"))
    ws = w.get("workshop", {})
    unc = w["uncertainties"]
    name = {s["code"]: s for u in unc for s in u["end_states"]}
    owner = {s["code"]: (u.get("short") or u["name"]) for u in unc for s in u["end_states"]}
    sk = w["skeletons"]
    t = ws.get("day2_times", {})
    topic = ws.get("topic", "the topic")
    credit = ws.get("method_credit", "Foresight method and materials: SA Futures Agency")
    hosts = " and ".join(ws.get("hosts", []))
    unc_names = [(u.get("short") or u["name"]).lower() for u in unc]
    vals = {
        "title": e(ws.get("title", "")), "day2": e(ws.get("day2", "")), "country": e(ws.get("country", "")),
        "year": e(ws.get("target_year", "")), "base": e(ws.get("base_year", "")), "capital": e(ws.get("place", "the capital")),
        "topic": e(topic), "topic_cap": e(topic[:1].upper() + topic[1:]), "n_unc": str(len(unc)), "unc_list": e(", ".join(unc_names[:-1]) + ", and " + unc_names[-1]),
        "topic_definition": e(ws.get("topic_definition", "")), "last_page": str(2 + len(sk)),
        "who": " ".join(f'{e(s.get("facilitator") or s.get("table") or "Table")}: <b>{e(s["id"])}</b>, {e(s["title"])}.' for s in sk),
        "credit": e(credit + (". For " + hosts if hosts else "")),
        "t_start": e(t.get("start", "9:15")), "t_read": e(t.get("read_end", "9:25")), "t_build": e(t.get("build_end", "10:30")),
        "t_name": e(t.get("name_end", "10:40")), "t_end": e(t.get("end", "10:45")), "t_report": e(t.get("reportback", "11:00 to 12:15")),
    }
    system = ws.get("system", "system")
    parts = [list(x) for x in (ws.get("system_parts") or general_parts(system))][:4]
    for i, part in enumerate(parts, 1):
        vals[f"part{i}_title"] = e(part[0]); vals[f"part{i}_text"] = e(part[2] if len(part) > 2 else part[1])
    vals["part_titles"] = e(", ".join(x[0].lower() for x in parts))
    gen = open(os.path.join(ASSETS, "pack_general.html"), encoding="utf-8").read()
    for k, v in vals.items():
        gen = gen.replace("{{" + k + "}}", v)
    top = f'<div class="top">{img("host_logo.png")}{img("partner_logo_1.png") if len(ws.get("hosts", [])) > 1 else ""}<span class="r">{img("safa_dark.png")}</span></div>'
    pages = ["<section>" + top + part + "</section>" for part in gen.split("<!--PAGEBREAK-->")]
    for s in sk:
        pk = s.get("pack", {})
        rows = "".join(f'<tr><td class="c1">{e(owner[c])}</td><td class="c2">{e(c)} {e(name[c]["name"])}</td><td>{e(name[c].get("description", ""))}</td></tr>' for c in s["combo"])
        means = pk.get("means", {})
        H = [top, f'<p class="eyebrow">Facilitator pack · Skeleton {e(s["id"])} · Scenario building, {vals["t_start"]} to {vals["t_end"]}</p>',
             f'<h1>{e(s["id"])}. {e(s["title"])}</h1>',
             f'<p class="lede">{e(s.get("tagline", ""))} The title is a working title. The table gives the scenario its own name.</p>',
             f'<p class="who">Facilitator: <b>{e(s.get("facilitator", "__________"))}</b> &nbsp;&nbsp;&nbsp;&nbsp; Table: __________ &nbsp;&nbsp; Name the table chooses: ______________________________</p>',
             f'<h2>The {len(s["combo"])} end states: true in {vals["year"]}, and fixed. Write them on placemat 2 before {vals["t_start"]}.</h2>',
             f'<table class="small">{rows}</table>',
             f'<h2>How they fit together</h2><p>{e(s.get("how_it_fits", ""))}</p>',
             f'<h2>The question this scenario puts to {e(topic)}</h2><p class="box">{e(s.get("asks", ""))}</p>']
        if pk.get("prompts"):
            H.append(f'<h2>Prompts for {e(topic)} in this scenario</h2><ul>' + "".join(f"<li>{e(x)}</li>" for x in pk["prompts"]) + "</ul>")
        if means:
            H.append("<h2>What it means for people, nature and the economy</h2><ul>" + "".join(
                f"<li><b>{lab}:</b> {e(means[k])}</li>" for k, lab in (("people", "People"), ("nature", "Nature"), ("economy", "The economy")) if means.get(k)) + "</ul>")
        if pk.get("watch_for"):
            H.append("<h2>Watch for</h2><ul>" + "".join(f"<li>{e(x)}</li>" for x in pk["watch_for"]) + "</ul>")
        H.append(f'<p class="foot">Facilitator pack · Skeleton {e(s["id"])} · {vals["credit"]}</p>')
        pages.append("<section>" + "".join(H) + "</section>")
    doc = f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Facilitator pack for scenario building: {vals["title"]}</title><style>{CSS}</style></head><body>{"".join(pages)}</body></html>'
    out = out or os.path.join(os.path.dirname(os.path.abspath(path)), "facilitator-pack.html")
    open(out, "w", encoding="utf-8").write(doc)
    print("Wrote", out, "-", 2 + len(sk), "pages expected")


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__); sys.exit(0 if len(sys.argv) > 1 else 1)
    build(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
