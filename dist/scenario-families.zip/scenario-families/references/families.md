# Grouping survivors into families

## Two ways to group, and why to use both

**By two uncertainties.** Choose two uncertainties. Every pair of their end states is one family. The other uncertainties vary inside each family. This is easy to draw as a grid and easy to explain to a room: "these are all the futures where towns spread out and services are well funded".

**By similarity.** Let the program group the survivors that share the most end states (`--cluster K`). This makes no assumption about which uncertainties matter most. It is harder to explain, so use it as a check on the first way, and as a source of ideas when no pair of uncertainties gives a good grid.

When both ways give roughly the same groups, the grouping is sound.

## Choosing the two uncertainties

Ask these of each candidate pair:

- If we change the end state on this uncertainty, does the scenario become about different people, or work by a different logic? If yes, it is a good axis. If it only becomes a bit better or a bit worse, it is not.
- Are the two axes about different things? One about actors and one about conditions works well. Two that move together make a grid with empty corners.
- Would a participant recognise the grid? The axes should be uncertainties the room argued about.

In a larger desk study by SA Futures Agency, with eight uncertainties and tens of thousands of combinations, the families were found the other way round: bundles of end states that reinforce each other were identified first, and five families were named around those bundles. With a large field, start from the clusters.

## When no pair works

- **Every pair leaves several empty families.** The field is tightly constrained. Use the similarity clusters as the families.
- **One family holds most of the survivors.** That axis has an end state that fits with everything. Try the pair with the next highest evenness.
- **Three uncertainties each matter as much as the others.** Use three axes if the field is large enough, or accept clusters.

## Choosing the candidate in each family

| Choice | When to use it |
|---|---|
| Most coherent: the most supporting pairs | The default. The clearest story, and the easiest for a table to build. |
| Most surprising: the most unusual pairings | When the team told a strong story for those pairings, and the shortlist needs something the room would not expect. |
| Most central: closest to the rest of the family | When the family is large and mixed, and you want its typical member. |

Then check the shortlist as a whole. Count how often each end state appears. An end state that appears nowhere should be brought in by changing one candidate. An end state that appears in most candidates is crowding out the others.

Count the unusual pairings in each candidate. Each one needs its story written down, because the table facilitator will have to tell it.

## Which candidate could anchor the set

The next skill starts from one anchor: the one combination the team agrees the set must contain. The rest of the set is then chosen for its difference from the anchor and from each other. While shortlisting, notice which candidates could play that part. Three kinds come up most often, and they are usually found among the survivors where every pair supports every other:

- the combination where what the tables hoped for happens together
- the combination where today's problems carry on and the efforts to change them stay too small
- the combination closest to where the country is heading now

One anchor is enough. A set does not need both a most hopeful and a most worrying skeleton, and a set built around both can read as a best case and a worst case with two others in between. If the team wants to record the most hopeful and most worrying combinations, the optional `edges` block in the workshop file holds them, and the program reports whether each is in a set. It does not require them.

## A check on span from another tradition

Jim Dator sorts images of the future into four forms: continued growth, collapse, a disciplined society organised around limits or shared values, and transformation. Ask which of the four the shortlist touches. If every candidate is a version of one form, the shortlist is narrow, and the team should look again at the families it passed over. Use this as a prompt for discussion. No published method scores a scenario set against the four forms, and the check does not require one candidate for each. Source: Dator (2009), "Alternative futures at the Manoa School", Journal of Futures Studies 14(2).

## Naming families and candidates

A family is named by its two end states: "Towns spread out, services are well funded". A candidate gets a working title of two to five words that says what happens, with no judgement: "Buses follow the new estates". Tables choose their own scenario names on day 2.

## What the research does, and what this skill does

- The scenario management school (Gausemeier, Fink and Schlake) groups the surviving combinations by hierarchical clustering, chooses the number of groups that best balances fewer scenarios against detail lost, describes each group by the end states that most of its members share, and checks the result on a map. This skill's similarity option does the same job in a simpler way and reports what the members of each cluster share.
- Cross-impact balance practice sorts the table of survivors by eye until families show, and its software manual says the automatic sort is only a start and should be finished by hand. The same applies here. The program proposes and the team decides.
- The program groups by the number of uncertainties on which two combinations differ, and names each cluster by its most central member. No published scenario method was found that uses exactly this procedure. It is a standard clustering technique, and it has one useful property: the central member is always a real surviving combination.

Sources: Fink and Schlake (2000), "Scenario management: an approach for strategic foresight", https://www.exinfm.com/pdffiles/scenario.pdf. ScenarioWizard manual, https://www.cross-impact.org/ressourcen/ScenarioWizardManual_en.pdf.
