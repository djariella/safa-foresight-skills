---
name: scenario-families
description: Group the surviving scenario combinations into families and shortlist one candidate from each. Chooses the family axes, checks them by clustering and reads each candidate whole. Step 3 of 4.
---

# Scenario families

This is the third of four skills that take a facilitation team from end states to scenario skeletons: compatibility-matrix, then morphological-analysis, then **scenario-families**, then scenario-set-selection. It was developed by Ariella Helfgott and SA Futures Agency.

After the morphological analysis there are tens or hundreds of surviving combinations. Nobody can discuss that many. A family is a group of survivors that tell broadly the same story. Grouping them lets the team see the handful of different kinds of future in the field, pick one clear example of each, and then choose between examples.

## What you need

The workshop file after the morphological analysis has been run. `analysis.md` should exist next to it.

## Steps

### 1. Look at the ways of grouping

```
python scripts/morph.py families FILE --cluster 8
```

This shows two things. Option 1 lists every pair of uncertainties as possible family axes, with how many families each gives, how many are empty and how evenly the survivors spread across them. Option 2 groups the survivors by similarity into the number of clusters you ask for, and says what the members of each cluster share. Ask for about twice as many clusters as there are tables.

### 2. Choose the two uncertainties that define the families

Recommend two, and explain why in a sentence. Use these tests in order:

1. **Story.** A change of end state on these two changes who the scenario is about and how it works. Usually one is about who does the main activity and one is about the conditions it happens under. For example: where people live, and who pays for the service.
2. **Clusters.** The similarity clusters are mostly defined by the same two uncertainties. If the clusters are defined by a different pair, look hard at that pair.
3. **Spread.** Few empty families, and high evenness. Use this to break a tie. Do not let it overrule the first test.

The team decides. Set `family_axes` in the workshop file and run `analyse` and `families` again.

`references/families.md` has more on choosing axes and on what to do when no pair works.

### 3. Shortlist one candidate from each family

For each family the output gives three combinations: the most central (closest to all the others in the family), the most coherent (most supporting pairs) and the most surprising (most unusual pairings). Propose one as the candidate:

- Choose the combination that tells the clearest and most distinct story. Coherence is a pass mark here and should not be used to rank. Research on choosing scenario sets, including Lord, Helfgott and Vervoort (2016), found that middle-of-the-road end states tend to rate as more compatible with everything, so always taking the most coherent combination pulls the shortlist towards the middle.
- Prefer the most surprising when its unusual pairings have strong stories from the team review. These are the futures a room would not think of by itself.
- Across the whole shortlist, vary the end states of the other uncertainties, so that every end state appears in at least one candidate. A shortlist where every candidate has the same water end state has wasted the water table's work.

Give each candidate a letter, a neutral working title of two to five words, a one-line description and its count of unusual pairings. Record them in `candidates`, each with its `family` number.

### 4. Read each candidate as a whole

```
python scripts/morph.py whole FILE
```

This lays out every candidate with all its end states and the rating and story for each pair. Pair ratings can miss a clash between three or more end states. For each candidate, ask the team: could one country be all of this at once, in the target year? If the answer is no, replace the candidate with another from the same family, record the struck combination in `excluded_combos` with the reason, and run `analyse` again.

### 5. Note which candidate could anchor the set

The next skill starts from one anchor: the one combination the team agrees the set must contain. It builds the rest of the set from there. Tell the team which candidates could play that part, and why. Common choices are the combination where what the tables hoped for happens together, the one where today's problems carry on, and the one closest to where the country is heading now. The team chooses in the next skill. A set does not need both a most hopeful and a most worrying skeleton.

### 6. Show the team

Run `python scripts/review_pack.py FILE`. The page now shows the family grid with the candidate in each family. Walk the team through it family by family.

## What good looks like

- The team can describe each family in a phrase, such as "spread-out towns with well-funded services".
- Every candidate is clearly a different kind of future from the others.
- Between them the candidates use every end state.
- The shortlist holds at least one candidate the team would be willing to anchor the set on.
- The shortlist holds more than one kind of story. A quick test uses four familiar shapes of future: things carry on and grow, things break down, society lives within firm limits, and something changes the rules. A shortlist with only the first two is too narrow.

## Next

Hand over to the **scenario-set-selection** skill.

Follow `references/writing-rules.md`. Working titles are neutral descriptions.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
