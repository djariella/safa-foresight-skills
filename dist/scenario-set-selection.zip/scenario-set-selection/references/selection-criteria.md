# Criteria for choosing the set of skeletons

Choose as many skeletons as there are tables. `python scripts/morph.py sets FILE` checks criteria 2 to 8 for every possible set and ranks them.

| | Criterion | Why | How the script checks it |
|---|---|---|---|
| 1 | One skeleton for each table | Every table builds a different scenario | `--n`, or `workshop.tables` |
| 2 | The anchor is in: the one combination the team agreed the set must contain | It gives the set a starting point the team has chosen and can explain. The other skeletons are chosen for their difference from it and from each other. | `anchor` is kept in every set |
| 3 | No more than one from any family | Two from one family give similar stories | `family_axes` |
| 4 | Every end state is used at least once | Every table sees its own work in the set | Compares the end states used with the full list |
| 5 | Any two skeletons differ on most uncertainties | The scenarios must be clearly different for the comparison on day 2 to teach anything | Smallest difference between any two is more than half the uncertainties |
| 6 | At least one skeleton contains unusual pairings | These are the scenarios that challenge what people expect | Counts T pairs inside each skeleton |
| 7 | The set covers the questions the topic has to face | It ties the scenarios to the purpose of the workshop | Every `topic_questions` id is `central` in at least one skeleton |
| 8 | No skeleton contains an X pair, and no rating inside it is still Q | Every skeleton has to be possible | Checks every pair inside every skeleton |

## Choosing the anchor, and building from it

The team picks one anchor and says why in one line. Good anchors are combinations the room will recognise at once:

- the future the tables hoped for, where their most hopeful end states happen together
- the future where today's problems carry on and the efforts to change them stay too small
- the combination closest to where the country is heading now

The set does not need both a most hopeful and a most worrying skeleton. One anchor is enough. With the anchor fixed, the program grows a set from it by adding, each time, the candidate farthest from those already chosen. It then ranks every set that contains the anchor against the criteria, so the team can see whether the grown set is also the best one.

This is a published procedure. In Lord, Helfgott and Vervoort (2016) the team enters an initial scenario and the set is grown from it by repeatedly adding the farthest combination, and the paper describes the initial scenario as a feature of participatory workshops. Tietje (2005) describes a similar procedure that starts from one scenario the analyst chooses. Both note that the result depends on the starting point. For that reason, record the anchor and the reason, and if the team is unsure between two anchors, run `--anchor` with each and compare the sets.

If the anchor is a hard future, give it a neutral title. Tables usually do very good work on it. If the future the room hoped for is not in the set, say so when the set is presented, and tell the room that the vision session on day 2 is where that future is built.

## Criterion 7 in practice

1. Write down the questions the workshop's topic has to face in this country. Use the words the tables used on day 1. Four to seven questions is the working range. Record where each was heard.
2. For each candidate, ask of each question: can a table build this scenario without answering it? If not, the question is central. If the scenario touches it, mark it partly.
3. The chosen set should make every question central at least once.

For public transport, the questions might include: distance (if most homes are far from the centre, what can public transport still do well?), who pays (if fares and rates cannot cover the cost, who does?), and who is left out (who cannot get to work or school in this future?).

## When no set meets every criterion

Keep 1, 2 and 8. Get as close as possible on the rest. Tell the team which criterion was relaxed and what that costs, and say so when the set is presented to the room.

## A strong candidate that is left out

Pass its question to the table whose skeleton is closest, and add it to that skeleton's question about the topic.

## Titles

Each skeleton gets a working title of two to five words that describes what happens. It does not judge. Tell tables the titles are working titles and that they will choose their own name. "Buses follow the new estates" is a working title. "Sprawl wins" is a judgement.

## Allocation

Tables keep the seats they had on day 1. Give each facilitator the skeleton they can best support. Most people will build a scenario that contains an end state from another table, which is intended.

## How different is different enough

The program counts, for every two skeletons in a set, the number of uncertainties on which they differ. It reports the smallest count, the mean, and the highest mean that any set of that size could reach in this field. With four skeletons and an uncertainty that has three end states, two skeletons have to share an end state, so the highest possible mean is below the number of uncertainties. With four uncertainties of 3, 3, 4 and 3 end states, the highest possible is 3.5 of 4.

It also draws 20,000 random sets from the survivors and reports how many are as different and use every end state. The share is usually small. This is a plain way to tell a team, and later a reader of the report, that the set was chosen with care.

These measures follow the research on choosing diverse scenario sets (see `method-background.md`). Difference is necessary and it is not enough: a very different set that leaves out the anchor, or that never makes the room face the hardest question about its topic, is a poor set. That is why difference is one criterion of eight.

## Easy to believe, or surprising

Each combination carries a count of unusual pairings. A team has a real choice here.

- **For a workshop with participants**, include at least one skeleton with unusual pairings (criterion 6). These are the futures the room would not have reached alone, and the stories behind the pairings give the table something concrete to work on.
- **For a written study that has to convince sceptical readers**, a team may prefer to choose only from combinations with no unusual pairings (`--max-unusual 0`), and keep the unusual ones as variants. SA Futures Agency has done both.

Say which choice was made and why.

## A stress test

Some teams add one extra scenario outside the set: a combination that is possible in each of its parts and extreme taken together, used to test how the hosts would cope with a crisis. Keep it clearly separate from the main set, and do not give it to a table unless the workshop has time for it.

## Keeping a record

Write down the two or three sets that were compared, the criteria each met, and the reason for the choice. The write-up needs it, and so will anyone who asks later why these scenarios and not others.

## How many scenarios

Published advice gathers around three to five scenarios, with four the most common and six the usual upper limit. Two tends to be read as good and bad. Three invites people to pick the middle one. This is why the workshop uses four to six tables, and why a workshop with three tables should take extra care that none of its three skeletons is a midpoint between the other two.

One arithmetic limit applies. A set cannot use every end state unless it has at least as many skeletons as the largest number of end states on any one uncertainty. The program says so when that is the case.

## Three further checks

The eight criteria cover what the main published lists ask for: plausibility, consistency, relevance, challenge and difference (Wilson's five tests are the best known). Three things in those lists are not among the eight, and are worth a minute each.

- **Balance.** No end state appears in more than half the skeletons. The program reports this.
- **Names people will remember.** Short, neutral, different from each other.
- **Ownership.** Each table can see its own day 1 work in the set. Criterion 4 does most of this. Saying it aloud on day 2 does the rest.

## Consistency is a pass mark

Use the compatibility ratings to remove what is impossible. Do not then rank the survivors by how many supporting pairs they have and take the top ones. End states in the middle of a range tend to fit with everything and so rate as more compatible, and a set chosen that way drifts towards the middle of the field. This finding is reported in Lord, Helfgott and Vervoort (2016), and it is the reason this skill selects on difference, coverage and relevance among the survivors.
