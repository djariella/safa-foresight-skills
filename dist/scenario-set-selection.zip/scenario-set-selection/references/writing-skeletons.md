# Writing the skeletons

A skeleton is what a table receives on the morning of day 2. It has to be short enough to read in two minutes and firm enough that the table does not argue with it for the first half hour.

## The five parts

| Part | Rule |
|---|---|
| Working title | Two to five words that say what happens. Neutral. The table will choose its own name. |
| Tagline | One sentence. For a skeleton built from the most hopeful or the most worrying end states, say so plainly. |
| End states | One for each uncertainty, with code and full name, exactly as agreed in the team review. |
| How it fits together | One paragraph, four to six sentences. The chain of cause that makes these end states true at the same time. Use the team's stories for the unusual pairings. Present tense. No facts about today, and no numbers. |
| What it asks about the topic | One question, or two closely linked. Drawn from the topic questions this skeleton makes central. If a left-out candidate's question has been passed to this table, add it here. |

Then the table and the facilitator.

## Tests

- Could someone who missed day 1 picture this future from the paragraph?
- Does the paragraph explain every unusual pairing in the skeleton?
- Does it leave the topic open? The skeleton sets the conditions. The table works out what happens to the topic inside them.
- Is the hopeful skeleton free of promises, and the worrying one free of blame?

## An example

This skeleton is invented to show the form. It does not come from a workshop. The topic is public transport in a made-up country called Northland, and the target year is 2045.

**E. Buses follow the new estates.** Services grow while towns spread out. Two unusual pairings.
H2 Towns spread outward along the highways. F1 Fares and rates pay for frequent services. W2 One large employer on the edge of each town. P2 Transport policy changes with each government.
*How it fits together.* Land on the edge of towns stays cheap and most new homes are built there. Councils charge a levy on every new estate and use it to pay for buses, because national policy changes too often to rely on. The large employers on the edge of town agree their shift times with the bus operators. Town centres have fewer residents and fewer shops than today.
*What it asks.* Services are well funded and the distances are long. What can public transport do well when most trips run from one edge of town to another, and who is still left without a way to get to work or school?
*Table 4, facilitated by [name].*
