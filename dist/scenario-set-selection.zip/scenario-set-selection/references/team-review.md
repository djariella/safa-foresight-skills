# The team review

The whole facilitation team reviews the draft together: the lead facilitator and every table facilitator. The table facilitators know what their tables meant, so the review cannot be done without them. Put the review pack on a screen everyone can see. Record the discussion. Allow about two hours.

## Agenda

| Part | What the team does | Decisions to record |
|---|---|---|
| 1. End states | Read each uncertainty's end states aloud. The table facilitator confirms or corrects. | Final wording. Any end state added or merged. |
| 1. Pairs that cannot be true | Take each X in turn. Someone argues that both could be true. | Each X confirmed, or changed to T with its story. |
| 1. Open pairs | Take each Q in turn. | Each Q settled. |
| 2. Unusual pairings | Tell the story for each T. | The story for each. Any T changed to X. |
| 3. Results | Look at the numbers and the patterns in what survived. | Anything that looks wrong, to recheck. |
| 3. Candidates | For each: plausible, interesting, buildable in 90 minutes? | Candidates set aside, with the reason. |
| 3. The set | Check the proposed set against the eight criteria. | The chosen skeletons, their working titles, and the question for each. |
| 3. Tables | Give each skeleton a table and a facilitator. | The allocation. |

## Questions to ask

For an X: "Why can these two not exist together?" "Can anyone tell a story where both are true by the target year?" "Does that story still fit the end state as the table wrote it?" "Is that possible within the years we have?"

For a T: "How did both of these come to be true?" "Who made it happen?" "Is it believable?"

For a candidate: "Could this happen?" "What would a table learn from building it?" "Is it different enough from the others?" "Can a table build it in 90 minutes?"

## Things that usually come up

**"The end states do not mention our topic."** They should not. The end states describe the setting. Each table works out on day 2 what the topic looks like inside its scenario. A country of compact towns and a country of spread-out suburbs can both have good public transport, and it will look very different in each. If the topic itself appears as an uncertainty, set it aside and take the next one.

**"That one would never happen."** Ask what would have to happen for it to be true. If there is an answer, it is plausible. If there is not, check the ratings inside it.

**"Do we need a best case and a worst case?"** No. The set needs one anchor that the team agrees must be there, and the other skeletons are chosen for their difference from it and from each other. If a skeleton where today's problems carry on is in the set, give it a neutral title. Tables usually do very good work on it.

**"Our favourite is missing."** If the team wants the future the tables hoped for in the set, make it the anchor. If it is left out, say so when the set is presented, and tell the room that the vision session on day 2 is where that future is built.

**"Two of these look the same."** Check criterion 5. If two skeletons share half or more of their end states, replace one.

**A team member's own assumptions.** The review often shows the team its own assumptions about the topic, for example that better public transport must mean more buses. Name these when they appear. They are useful.

## After the review

Update the workshop file with every decision. Re-run the analysis and the review pack. Save the recording and a short list of decisions with the reasons. The write-up after the workshop needs both.

## Four things worth recording for the next team

The published research gives procedures for this step and very little measurement. A team that repeats the workshop can add evidence at almost no cost. Record:

1. **Where the team changed the draft.** Claude drafts every rating first and the team reviews the draft. When a rating is changed, keep the first one in `draft_rating`. `pairs-import` does this automatically, and `check` reports the count.
2. **How long the review took**, for the matrix and for the choice of set.
3. **Any combination removed when read as a whole**, with the end states involved (`excluded_combos`).
4. **Who spoke most in the review**, in one honest line. If one person settled most of the ratings, say so in the method section.
