# Decision record for the set of skeletons

Fill this in at the end of the team review. Keep it with the workshop file. The write-up uses it, and so will anyone who asks later why these scenarios were chosen.

| | |
|---|---|
| Workshop and date | |
| Who took part in the decision | |
| The field | Number of uncertainties, end states, pairs rated, combinations, survivors |
| Ratings the team was split on | Each contested pair, the rating recorded, and whether reversing it would change which skeletons are possible |
| Combinations struck after reading them as wholes | Each one, with the reason |
| How the survivors were grouped | The two uncertainties used for families, and why. What the similarity check showed |
| The anchor | The one combination the team agreed the set must contain, and why |
| The sets compared | Two or three sets, with the criteria each met and its diversity and balance figures |
| The set chosen | Each skeleton with its working title, table and facilitator |
| Why this set | Two or three sentences |
| Any criterion relaxed | Which one, and what it costs |
| What was left out | Strong candidates not chosen, and which table took each one's question |
