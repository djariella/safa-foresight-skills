---
name: scenario-set-selection
description: Choose the best set of scenario skeletons, one per table. Starts from one anchor the team picks, then checks difference, coverage and the topic questions, and writes the skeletons. Step 4 of 4.
---

# Scenario set selection

This is the fourth of four skills that take a facilitation team from end states to scenario skeletons: compatibility-matrix, then morphological-analysis, then scenario-families, then **scenario-set-selection**. It was developed by Ariella Helfgott and SA Futures Agency.

The team has a shortlist of candidates, one from each family, and needs one skeleton for each table. The question is no longer which scenarios are good. It is which set is good. A set works when its members are possible, clearly different from each other, use everything the room produced, include both the future people hope for and the one they fear, and between them force the workshop's topic to be thought through from every side.

Choosing diverse sets from a large field is a studied problem, and one of the main papers on it is by Ariella Helfgott of SA Futures Agency with Steven Lord and Joost Vervoort. `references/method-background.md` summarises that work and the rest of the field. This skill applies the same idea in a form a team can use in an hour.

## What you need

The workshop file with `candidates` and `family_axes` filled in, and the number of tables.

## Steps

### 1. Choose the anchor

Ask the team for one anchor: the one combination the set must contain. Everything else is chosen from there. Record it in the workshop file as `anchor`, with one line on why:

```
"anchor": { "combo": ["H1", "F1", "W1", "P1"], "why": "The future the tables hoped for." }
```

The team decides which combination it is. Common choices are the future the tables hoped for, the future where today's problems carry on, and the combination closest to where the country is heading now. Do not require both a most hopeful and a most worrying skeleton. One anchor is enough, and the others are chosen for their difference from it and from each other. `references/selection-criteria.md` explains the choice and where the procedure comes from.

### 2. Write the questions the topic has to face

List four to seven questions that the workshop's topic has to answer in this country, in the words the tables used on day 1. Record them as `topic_questions`, each with where it was heard. For each candidate, mark a question `central` if a table cannot build that scenario without answering it, and `partly` if the scenario touches it. `references/selection-criteria.md` gives examples.

### 3. Build the set from the anchor

```
python scripts/morph.py sets FILE
```

This keeps the anchor in every set. It first grows one set from the anchor, adding each time the candidate farthest from those already chosen. It then tries every set of the right size that contains the anchor, and checks each against criteria 2 to 8 in `references/selection-criteria.md`. For the best set it also reports:

- the smallest and the mean number of uncertainties on which any two skeletons differ, and the most any set of that size could reach
- diversity as one number: the smallest difference in the set divided by the best achievable, which is the measure used in Lord, Helfgott and Vervoort (2016)
- balance: whether one end state appears in more than half the skeletons
- how many random sets from the survivors are as different and use every end state, as a plain measure of how good the set is

Useful options: `--anchor B` tries a different anchor without changing the file, which is a quick way to show the team how far the set depends on the starting point. `--pool survivors` searches every surviving combination when the shortlist is too narrow. `--max-unusual 0` limits the search to combinations with no unusual pairings, for teams that want the most easily believed set. `--set A,C,D,E` checks a set the team proposes.

### 4. Present two or three sets, and recommend one

Show the top sets side by side: what is in each, which criteria each meets, and what each gains and loses. Recommend one and say why in two or three sentences. Several sets usually score about the same. The research on this step is clear that the last choice between them is made by people, on which set makes the better group of stories for this room. If the team proposes a different set, check it with `--set` and report honestly how it compares. The team decides.

When no set meets every criterion, keep criteria 1, 2 and 8 (one for each table, the anchor, and every skeleton possible), get as close as possible on the rest, and say which criterion was relaxed.

### 5. Check that the choice does not rest on a contested rating

```
python scripts/morph.py sensitivity FILE
```

If reversing a contested rating would make a chosen skeleton impossible, tell the team before the set is final.

### 6. Read the chosen set as wholes, and name it well

Run `python scripts/morph.py whole FILE --set A,B,D,E` with the chosen ids and read each skeleton in full with the team one last time. Then check the working titles together: each one neutral, each one clearly different from the others, and each one easy to remember and say aloud. People will use these names for two days.

### 7. Deal with what was left out

For each strong candidate that is not chosen, name the question it raised and pass that question to the table whose skeleton is closest. Record this in the skeleton's `asks`.

### 8. Write the skeletons and the decision record

For each chosen skeleton write a working title, a one-line tagline, the end states, a paragraph on how they fit together, and the question it asks about the topic. `references/writing-skeletons.md` has the rules and an example. Record them in `skeletons` with the table and facilitator.

Then run `python scripts/review_pack.py FILE` so the team's page ends with the chosen skeletons, and fill in the decision record in `references/decision-record.md`. It takes five minutes and the write-up needs it.

## What good looks like

- The team can say in one sentence what each skeleton is about and how it differs from the others.
- Every table facilitator can explain why their skeleton is possible.
- Nobody on the team is saying "that one would never happen".
- The record shows the anchor and why it was chosen, which sets were considered, and why this one was chosen.

## Check the program

On `assets/example/example.workshop.json`, a made-up workshop file with placeholder wording, the set grown from the anchor is A, C, E and H. It is the only one of the 56 sets of four candidates containing the anchor that meets every criterion. Its skeletons differ on 3.5 of 4 uncertainties on average, which is the most a set of four can reach in that field.

## Next

Hand over to the **scenario-day2-materials** skill for the slides, placemats and facilitator packs.

Follow `references/writing-rules.md` and `references/brand.md`.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
