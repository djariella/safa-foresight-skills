# The three placemats

Each participant gets all three, printed at A3. Each has the same structure: a header with the method name, a title and one line of explanation; three small cards that say what the method is, why we do it and what the table will have at the end; then the numbered steps, each with its time and who does it.

## 1. Horizon scanning and critical uncertainties (day 1, 105 minutes, five steps)

| Step | Time | Who | What is on the placemat |
|---|---|---|---|
| 1 Notice | 10 min | On your own | "Write what you see changing. One idea on each post-it." Three prompts: your work, village and market; the region and the world; a small thing today that could be big by the target year. |
| 2 Share and discuss | 35 min | At your table | "Read your post-its aloud. Group similar ones under STEEP + V." The six headings with examples: Social, Technological, Economic, Environmental, Political, Values. |
| 3 Enter in Menti | 15 min | On your phone | Menti question 1, word for word. |
| 4 Word cloud | 5 min | Whole room | "We read the top uncertainties together. Each table takes one of them." |
| 5 End states | 40 min | At your table | A box for the table's critical uncertainty. "What could happen with this by [year]?" Three boxes for end states. "An end state is one way it could turn out. Make each one clearly different from the others." |

## 2. Scenario development (day 2 morning, 90 minutes, four steps)

| Step | Time | What is on the placemat |
|---|---|---|
| 1 Read your skeleton | 10 min | A table of uncertainty and end state, with room for six rows. On the evening of day 1 each table's copy is printed with its own skeleton written in. |
| 2 Build your scenario | 65 min | "It is [year]. Talk as if you live there." Eight prompts in tiles: the four main parts of the system the workshop is about, then Markets and money, Daily life, Decisions, Nature. Then "How did we get from [today] to this [year]? Name three things that happened along the way." |
| 3 Name it | 10 min | Boxes for the scenario name and a newspaper headline from the target year. |
| 4 Prepare | 5 min | "Finish your flipchart. Choose who will report back. They have five minutes to present." |

The first four prompts change with the topic. Write them as the four main parts of the system, and put them in `system_parts` in the `workshop` block of the configuration file. Each part has a title of one to three words (18 characters at most, so it fits the tile), a short question for the tile, and a longer prompt that the facilitator pack uses. For public transport they could be: daily trips, buses and trains, roads and paths, and paying for it. If `system_parts` is left out, the placemat uses four general parts: who uses the system, who provides it, what it depends on, and what is left over.

## 3. Visioning (day 2 afternoon, 105 minutes, five steps, after the guided visualisation)

| Step | Time | Who | What is on the placemat |
|---|---|---|---|
| 1 Reflect and write | 10 min | On your own | "What matters most in this future, and for whom?" "One vision element on each post-it. Use words or drawings." A postcard from the target year that starts "By [year], [country]'s [system] is…" |
| 2 Speed dating | 3 × 10 min | New partner each round | "Tell your partner what you saw. Then listen." |
| 3 One shared vision | 40 min | Whole group | "Bring your post-its to the vision table. Together we group similar ones and name each theme." Then the checks: does our vision deliver on each of these? Use the aims of the program the workshop belongs to, and set them in `vision_checks` in the `workshop` block: up to five, one or two words each. If there are none, the placemat uses five general checks: Fair, Sustainable, Affordable, Resilient, Healthy. |
| 4 Enter in Menti | 5 min | On your phone | Menti question 2, word for word. |
| 5 First priorities | 20 min | At your table | Priority opportunities, Enabling conditions, Partnerships, each with one question and a line to write on. |

## Design rules that matter for placemats

- Little blank note space. People write on post-its and flipcharts. The placemat is a guide.
- Every step shows its time and who does it.
- Nothing smaller than 11 point.
- The same wording as the slides and the Menti.
- Host logos and the SA Futures Agency logo on every placemat.

## Adapting the wording

Every line of text on the placemats can be changed in the `placemats` block of the configuration file. The keys are listed in `defaults()` in `scripts/build_placemats.py`. The ones most often changed:

| Key | What it is | When to change it |
|---|---|---|
| `p1_steep` | The six STEEP + V headings with their examples | A landlocked country: take "sea" out of the Environmental examples |
| `p2_prompts` | All eight scenario prompts | To change the last four as well as the four system parts, for example "rivers and the sea" in a landlocked country |
| `p3_checks` | The checks on the shared vision | Use the aims of the program the workshop belongs to |
| `p3_priorities` | The three questions for first priorities | To name the kind of action the workshop is looking for |
| `menti_q1`, `menti_q2` | The Menti questions | They must match the Menti word for word |
| `footer_logos`, `host_logo` | Logo files in `assets/placemat` | A different host or partner. Add the logo file to that folder first |
