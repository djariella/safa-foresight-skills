# The workshop deck

One deck carries the whole day and a half, about 95 slides. The words the facilitator says are in the speaker notes of every slide. In the notes, "Say" is read aloud and "Do" is an action.

## Outline of the deck

| Section | Slides in it | For each workshop |
|---|---|---|
| Cover | Title, place, dates, logos | Written fresh |
| Opening | Title, day 1 divider, opening and welcome, what we are here to do, the two days, working agreements, meet your table | Change dates, times, speakers and the question for "meet your table" |
| Setting the scene, from the hosts | The hosts' own slides on the system today, 10 to 12 slides | Ask the hosts for these. A simple diagram of the system and its main parts helps as a frame |
| Break | One slide | Change the time |
| Introduction to foresight | Four questions about the future, why scenarios, how scenarios and vision fit, the journey over two days | The same at every workshop. Change the year where it appears |
| Horizon scanning | Signs of change, STEEP + V | The same at every workshop |
| Four provocations | One slide each: two or three facts with sources, one real headline image, one question | Written fresh from the fact base (see the foresight-workshop-setup skill) |
| Placemat 1 | The five steps on placemat 1 | The same at every workshop |
| Critical uncertainties | What one is, and the steps | The same at every workshop |
| Menti question 1 | The join slide and the results slide | Put in the Menti code and QR. Change the country and topic in the question |
| An example | One uncertainty with its end states | Use an example from a different topic, so it does not steer the room. The notes say to go back to the steps slide after showing it |
| Lunch | Lunch, and what happens overnight | Change times |
| Day 2 opening | Day 2 divider, a short recap of foresight, the day 2 agenda | Change the date and times |
| Recap of day 1 | The numbers, each uncertainty and its end states, the rating key, the matrix, the pairs that cannot be true, unusual pairings, results, families, candidates, the topic questions, the chosen set | Built on the evening of day 1 from the workshop file. Some of these slides are optional and marked in their notes |
| The skeletons | One slide for each skeleton, with the read-aloud description in the notes | Built on the evening of day 1, one for each table |
| Scenario building | What makes a good scenario, the eight prompts, the four steps | Change the four system prompts and the capital city in the Daily life prompt |
| Report-back | Break, report-back, questions to ask of the scenarios, lunch | Change times, and the minutes for insights if there are more than four tables |
| Visioning | Divider, from scenarios to vision, why be ambitious, the guided visualisation, capture and share | Write the visualisation script into the notes at lunch on day 2 (see the scenarios-vision-writeup skill) |
| Shared harvest | Break, one shared vision, Menti question 2 and results, first priorities | Put in the Menti code |
| Closing | Reflections, Menti question 3 and results, what happens next, thank you | Put in the Menti code. Change next steps. Translate the thank you |

## The kinds of slide

- Content slides: light grey background, the title in navy capitals, and a small orange eyebrow label above it.
- Dividers, breaks and Menti join slides: navy background.
- A cover and a closing slide, both with the host logo and the SA Futures Agency logo.
- The hosts' setting-the-scene slides keep the hosts' own layout.

When adding a slide to an existing deck, copy a slide of the kind you need and change its text. This keeps the eyebrow, title and card styles exact.

## The Menti

One Menti, three questions, the same code throughout:

1. Day 1, critical uncertainties (word cloud): "What are the most important and uncertain factors impacting [topic] in [country]?"
2. Day 2, after the shared vision (word cloud): "One word for the [system] you saw in [year]."
3. Day 2, closing (open text): "One thing you will do differently after this workshop."

The join slides show the join code and a QR code. Add both once the Menti is live. Each results slide has a box for the results, shown from the Menti site or from its PowerPoint add-in.

## Rebuilding the day 2 recap and skeleton slides

Use the scenario-day2-materials skill. It writes the text for the recap and skeleton slides from the workshop file, and the read-aloud descriptions for the notes.

## Checks before the deck is final

- Every date, time, place and year is right, on the slides and in the notes.
- The wording of every step matches the placemats and the run sheet.
- Each provocation fact has its source on the slide.
- No slide has more than about 60 words.
- The speaker notes are still there for every slide that was edited.
- Rendered to images and looked at, slide by slide.
