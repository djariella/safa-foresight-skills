#!/usr/bin/env python3
"""Build the three A3 workshop placemats as an editable PowerPoint file.

Usage
  python build_placemats.py CONFIG.json OUT.pptx
  python build_placemats.py CONFIG.json OUT.pptx --skeletons WORKSHOP.json

CONFIG.json holds the workshop details and any wording to change (see
assets/example/placemats.config.json). Anything left out uses the default wording,
with the country, topic and years filled in from the "workshop" block.

--skeletons makes placemat 2 once for each skeleton in the workshop file, with that
table's end states written in, for printing on the evening of day 1.

Design by SA Futures Agency. Needs python-pptx.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from lib import *


def general_parts(system):
    """The four main parts of the system, used when the workshop block has no "system_parts".
    Each part: [title of at most 18 characters, short question for the placemat tile, longer prompt for the facilitator pack]."""
    return [["Who uses it", "Who uses it? What do they get from it?", f"What do people get from the {system} on an ordinary day? What does it cost them, and who goes without?"],
            ["Who provides it", "Who does the work, and how?", "Who provides it: public bodies, businesses, cooperatives, households? Are they young or old, women or men? What do they earn?"],
            ["What it depends on", "Which resources? Where from?", f"Which resources does the {system} depend on: land, water, energy, materials, skills, money? Where do they come from, and who controls them?"],
            ["What is left over", "What is wasted or lost? Where does it go?", "What is wasted, lost or polluted along the way, and where does it go? What is used again, and by whom?"]]


def defaults(w):
    c = w.get("country", "the country"); y = w.get("target_year", 2045); b = w.get("base_year", 2027)
    topic = w.get("topic", "the topic"); system = w.get("system", "system"); cap = w.get("place", "the capital")
    poss = c + ("'" if c.endswith("s") else "'s")
    parts = [list(x)[:2] for x in (w.get("system_parts") or general_parts(system))][:4]
    return {
        "p1_title": "What are you noticing?",
        "p1_sub": f"The changes shaping {poss} {system} to {y}, and which of them are most uncertain",
        "p1_total": "105 MINUTES IN FIVE STEPS",
        "p1_explain": [["WHAT IS HORIZON SCANNING?", "Looking for signs of change, close to home and far away."],
                       ["A CRITICAL UNCERTAINTY", f"A change with a big effect on the {system}, where we cannot know which way it will go."],
                       ["BY THE END YOU WILL HAVE", f"One critical uncertainty for your table, and two or three ways it could turn out by {y}."]],
        "p1_notice": ["What is changing in your work, your community, your market?", "What is changing in the region and the world that will reach us?", f"What small thing today could be big by {y}?"],
        "p1_steep": [["S", "Social", "people, health, culture"], ["T", "Technological", "digital, energy, tools"], ["E", "Economic", "jobs, prices, trade"],
                     ["E", "Environmental", "climate, water, soil, sea"], ["P", "Political", "laws, policies, institutions"], ["V", "Values", "what people care about"]],
        "menti_q1": w.get("menti_question_1") or f"What are the most important and uncertain factors impacting {topic} in {c}?",
        "p1_endq": f"What could happen with this by {y}?",
        "p2_title": "Bring your scenario to life",
        "p2_sub": f"One possible future for {poss} {system}. It does not have to be the future you want.",
        "p2_total": "90 MINUTES AT YOUR TABLE",
        "p2_explain": [["WHAT IS A SCENARIO?", "A plausible description of one way the future could turn out. It is not a prediction."],
                       ["WHY WE DO IT", "We cannot predict the future, but we can prepare for more than one."],
                       ["BY THE END YOU WILL HAVE", f"A named scenario for {y}, ready to present to the room in five minutes."]],
        "p2_read": f"Every end state here is true in {y}. Check that everyone understands each one.",
        "p2_endhead": f"END STATE IN {y}",
        "p2_build": f"It is {y}. Talk as if you live there.",
        "p2_prompts": parts + [["Markets and money", "Who is doing well? Who is struggling?"],
                               ["Daily life", f"A family in {cap}. A family in a village."], ["Decisions", "Who decides? Whose voice is heard?"], ["Nature", "Soil, forests, rivers and the sea."]],
        "p2_path": f"How did we get from {b} to this {y}?",
        "p2_headline": f"NEWSPAPER HEADLINE FROM {y}",
        "p3_title": "The future we want",
        "p3_sub": (w.get("vision_phrase") or f"The {system} we want for {c} in {y}") + ". Be ambitious.",
        "p3_total": "105 MINUTES, AFTER THE VISUALISATION",
        "p3_explain": [["WHAT IS A VISION?", "The future we would choose, and are willing to work for."],
                       ["WHY WE DO IT", "Scenarios ask what could happen. A vision asks what we want, so we can plan back from it."],
                       ["BY THE END YOU WILL HAVE", "One shared vision for the whole room, built from everyone's ideas."]],
        "p3_postcard_head": f"POSTCARD FROM {y}",
        "p3_postcard": f"By {y}, {poss} {system} is…",
        "p3_checks": w.get("vision_checks") or ["Fair", "Sustainable", "Affordable", "Resilient", "Healthy"],
        "menti_q2": f"One word for the {system} you saw in {y}.",
        "p3_priorities": [["Priority opportunities", "Which actions take us closest to the vision?"],
                          ["Enabling conditions", "What needs to be in place? Finance, markets, data, skills, policy."],
                          ["Partnerships", "Who needs to work together? Who is missing?"]],
        "footer": f"{w.get('title', '')}   ·   {cap}, {w.get('dates_short', '')}".strip(" ·"),
    }

G = 0.22; FW = W - 1.2
P = 0.3  # card inner padding


def placemat1(TX, N=1):
    # ================= 1 HORIZON SCANNING AND CRITICAL UNCERTAINTIES (v5, 22 Nov 2026: Menti 15, word cloud 5, end states 40) =================
    acc = ORANGE; T = mix(acc, 0.10)
    s = page(N, "HORIZON SCANNING", TX["p1_title"], TX["p1_sub"], TX["p1_total"], acc, (GOLD, ORANGE),
             "binoculars.png", (13.3, 1.62, 2.8, None),
             [*TX["p1_explain"]])
    CW = (FW - 2 * G) / 3; X = [0.6 + i * (CW + G) for i in range(3)]; IW = CW - 2 * P
    h1 = 4.4; yb = Y0 + h1 + G
    # 1 Notice
    card(s, X[0], Y0, CW, h1, T)
    y = head(s, X[0], Y0, CW, 1, "Notice", "10 MIN", "ON YOUR OWN", acc)
    tb(s, X[0] + P, y, IW, 0.6, "Write what you see changing. One idea on each post-it.", size=16); y += 0.8
    for i, q in enumerate(TX["p1_notice"]):
        rect(s, X[0] + P, y + 0.03, 0.07, 0.56, acc, r=0.035)
        tb(s, X[0] + P + 0.24, y, IW - 0.24, 0.62, q, size=17, color=NAVY, bold=True, lsp=0.98, anchor=MSO_ANCHOR.MIDDLE); y += 0.8
    # 2 Share and discuss
    card(s, X[1], Y0, CW, h1, T)
    y = head(s, X[1], Y0, CW, 2, "Share and discuss", "35 MIN", "AT YOUR TABLE", acc)
    tb(s, X[1] + P, y, IW, 0.6, "Read your post-its aloud. Group similar ones under STEEP + V.", size=16); y += 0.72
    for i, (L, lab, d) in enumerate(TX["p1_steep"]):
        yy = y + i * 0.405
        rect(s, X[1] + P, yy, 0.34, 0.34, CYC[i], r=0.08)
        tb(s, X[1] + P, yy, 0.34, 0.34, L, size=15, color=WHITE, bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        tb(s, X[1] + P + 0.48, yy, IW - 0.48, 0.34, [[(lab + "   ", NAVY, True, 15.5), (d, GRAY, False, 14)]], anchor=MSO_ANCHOR.MIDDLE)
    # 3 Menti
    card(s, X[0], yb, CW, YB - yb, T)
    y = head(s, X[0], yb, CW, 3, "Enter in Menti", "15 MIN", "ON YOUR PHONE", acc)
    tb(s, X[0] + P, y, IW, 0.9, TX["menti_q1"], size=16, color=NAVY, bold=True, lsp=0.98)
    # 4 Word cloud
    card(s, X[1], yb, CW, YB - yb, NAVY)
    y = head(s, X[1], yb, CW, 4, "Word cloud", "5 MIN", "WHOLE ROOM", acc, dark=True)
    tb(s, X[1] + P, y, IW, 0.6, "We read the top uncertainties together.", size=17, color=WHITE, bold=True, lsp=0.98)
    tb(s, X[1] + P, y + 0.44, IW, 0.3, "Each table takes one of them.", size=15, color="D5E2EE")
    # 5 End states
    card(s, X[2], Y0, CW, YB - Y0, T)
    y = head(s, X[2], Y0, CW, 5, "End states", "40 MIN", "AT YOUR TABLE", acc)
    tb(s, X[2] + P, y, IW, 0.25, "OUR CRITICAL UNCERTAINTY", size=11.5, color=acc, bold=True, spc=120)
    field(s, X[2] + P, y + 0.29, IW, 0.92, line=mix(acc, 0.45)); y += 0.29 + 0.92 + 0.26
    tb(s, X[2] + P, y, IW, 0.34, TX["p1_endq"], size=17, color=NAVY, bold=True); y += 0.44
    tb(s, X[2] + P, y, IW, 0.25, "TWO OR THREE END STATES", size=11.5, color=acc, bold=True, spc=120); y += 0.29
    note_h = 0.66
    fh = (YB - 0.24 - note_h - 0.14 - y - 2 * 0.1) / 3
    for i in range(3):
        yy = y + i * (fh + 0.1)
        field(s, X[2] + P, yy, IW, fh, line=mix(acc, 0.45))
        tb(s, X[2] + P + 0.1, yy, 0.34, fh, str(i + 1), size=21, color=CYC[i], font=BLACK, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    y += 3 * fh + 2 * 0.1 + 0.14
    tb(s, X[2] + P, y, IW, note_h, "An end state is one way it could turn out. Make each one clearly different from the others.", size=15, color=GRAY, lsp=0.98)

def placemat2(TX, N=2, SK=None):
    # ================= 2 SCENARIO DEVELOPMENT =================
    acc = TEAL; T = mix(acc, 0.09)
    s = page(N, "SCENARIO DEVELOPMENT" + (("   ·   " + SK["label"].upper()) if SK else ""), TX["p2_title"], TX["p2_sub"], TX["p2_total"], acc, (TEAL, SKY),
             "cone.png", (13.42, 1.84, 2.88, None),
             [*TX["p2_explain"]],
             hero=[(11.5, 1.85), (12.3, 1.6), (12.98, 1.82), (13.22, 2.5), (13.05, 3.22), (12.5, 3.62), (11.8, 3.42), (11.2, 2.6)])
    WA, WB = 5.0, 5.9; WC = FW - WA - WB - 2 * G; XA = 0.6; XB = XA + WA + G; XC = XB + WB + G
    card(s, XA, Y0, WA, YB - Y0, T)
    y = head(s, XA, Y0, WA, 1, "Read your skeleton", "10 MIN", "AT YOUR TABLE", acc)
    tb(s, XA + P, y, WA - 2 * P, 0.6, TX["p2_read"], size=16); y += 0.74
    c1 = 1.5
    tb(s, XA + P + 0.42, y, c1, 0.25, "UNCERTAINTY", size=11.5, color=GRAY, bold=True, spc=120)
    tb(s, XA + P + 0.42 + c1 + 0.2, y, 2.4, 0.25, TX["p2_endhead"], size=11.5, color=acc, bold=True, spc=120)
    NR = max(4, len(SK["rows"])) if SK else 6  # blank version has room for six uncertainties
    y += 0.3; gap = 0.07; bh = (YB - 0.2 - y - (NR - 1) * gap) / NR
    for i in range(NR):
        yy = y + i * (bh + gap); bw = WA - 2 * P
        field(s, XA + P, yy, bw, bh, line=mix(acc, 0.45))
        tb(s, XA + P + 0.1, yy, 0.3, bh, str(i + 1), size=19, color=CYC[i], font=BLACK, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        if SK and i < len(SK["rows"]):
            un, es = SK["rows"][i]
            tb(s, XA + P + 0.42, yy + 0.06, c1, bh - 0.12, un, size=12.5, color=GRAY, bold=True, anchor=MSO_ANCHOR.MIDDLE, lsp=0.95)
            tb(s, XA + P + 0.42 + c1 + 0.2, yy + 0.06, bw - 0.42 - c1 - 0.2 - 0.14, bh - 0.12, es, size=14.5, color=NAVY, bold=True, anchor=MSO_ANCHOR.MIDDLE, lsp=0.95)
        elif not SK:
            for k in (0.46, 0.86):
                rect(s, XA + P + 0.42, yy + k * bh, c1, 0.013, LINE); rect(s, XA + P + 0.42 + c1 + 0.2, yy + k * bh, bw - 0.42 - c1 - 0.2 - 0.14, 0.013, LINE)
    card(s, XB, Y0, WB, YB - Y0, T)
    y = head(s, XB, Y0, WB, 2, "Build your scenario", "65 MIN", "AT YOUR TABLE", acc)
    tb(s, XB + P, y, WB - 2 * P, 0.3, TX["p2_build"], size=16); y += 0.44
    tw = (WB - 2 * P - 0.12) / 2; th = (YB - 0.26 - 0.66 - 0.2 - y - 0.3) / 4
    for i, (lab, q) in enumerate(TX["p2_prompts"]):
        tx = XB + P + (i % 2) * (tw + 0.12); ty = y + (i // 2) * (th + 0.1)
        rect(s, tx, ty, tw, th, WHITE, r=0.1)
        rect(s, tx + 0.16, ty + 0.22, 0.15, 0.15, CYC[i], r=0.075)
        tb(s, tx + 0.4, ty + 0.13, tw - 0.5, 0.3, lab, size=(15.5 if len(lab) <= 18 else max(11.5, round(15.5 * 18 / len(lab), 1))), color=NAVY, bold=True)   # a long title is set smaller so it stays on one line
        tb(s, tx + 0.16, ty + 0.44, tw - 0.28, 0.5, q, size=14, color=DARK, lsp=0.95)
    y += 4 * th + 3 * 0.1 + 0.2
    tb(s, XB + P, y, WB - 2 * P, 0.3, TX["p2_path"], size=17, color=NAVY, bold=True)
    tb(s, XB + P, y + 0.34, WB - 2 * P, 0.3, "Name three things that happened along the way.", size=15, color=GRAY)
    h3 = 4.12
    card(s, XC, Y0, WC, h3, T)
    y = head(s, XC, Y0, WC, 3, "Name it", "10 MIN", "AT YOUR TABLE", acc)
    tb(s, XC + P, y, WC - 2 * P, 0.25, "SCENARIO NAME", size=11.5, color=acc, bold=True, spc=120)
    field(s, XC + P, y + 0.28, WC - 2 * P, 0.72, line=mix(acc, 0.45))
    tb(s, XC + P, y + 1.16, WC - 2 * P, 0.25, TX["p2_headline"], size=11.5, color=acc, bold=True, spc=120)
    field(s, XC + P, y + 1.44, WC - 2 * P, 1.3, line=mix(acc, 0.45))
    y4 = Y0 + h3 + G
    card(s, XC, y4, WC, YB - y4, NAVY)
    y = head(s, XC, y4, WC, 4, "Prepare", "5 MIN", "", acc, dark=True)
    tb(s, XC + P, y + 0.06, WC - 2 * P, 1.6, ["Finish your flipchart.", "Choose who will report back.", "They have five minutes to present."], size=16, color=WHITE, after=7, lsp=0.98)
    pic(s, "mic.png", XC + WC - 1.22, y4 - 0.24, h=1.26)

def placemat3(TX, N=3):
    # ================= 3 VISIONING (v7, 22 Nov 2026: speed dating 3 x 10, no theme boxes; reflect and write, speed dating, one shared vision, Menti, first priorities) =================
    acc = GREEN; T = mix(acc, 0.10)
    s = page(N, "VISIONING", TX["p3_title"], TX["p3_sub"], TX["p3_total"], acc, (GREEN, TEAL),
             "compass.png", (13.85, 1.58, None, 2.0),
             [*TX["p3_explain"]])
    WA, WB = 4.6, 5.9; WC = FW - WA - WB - 2 * G; XA = 0.6; XB = XA + WA + G; XC = XB + WB + G
    # 1 Reflect and write
    card(s, XA, Y0, WA, YB - Y0, T)
    y = head(s, XA, Y0, WA, 1, "Reflect and write", "10 MIN", "ON YOUR OWN", acc)
    tb(s, XA + P, y, WA - 2 * P, 0.6, "What matters most in this future, and for whom?", size=17, color=NAVY, bold=True, lsp=0.98)
    lines(s, XA + P, y + 1.0, WA - 2 * P, 2, gap=0.42); y += 1.8
    tb(s, XA + P, y, WA - 2 * P, 0.6, "One vision element on each post-it. Use words or drawings.", size=16); y += 0.78
    ph = YB - 0.24 - y
    field(s, XA + P, y, WA - 2 * P, ph, line=mix(acc, 0.5))
    rect(s, XA + WA - P - 0.62, y + 0.14, 0.46, 0.56, mix(acc, 0.25), r=0.05, line=acc, lw=1)
    tb(s, XA + P + 0.2, y + 0.16, 3.0, 0.25, TX["p3_postcard_head"], size=11.5, color=acc, bold=True, spc=120)
    tb(s, XA + P + 0.2, y + 0.46, WA - 2 * P - 1.0, 0.6, TX["p3_postcard"], size=15.5, color=NAVY, bold=True, lsp=0.98)
    nl = 4
    lines(s, XA + P + 0.2, y + ph - 0.24 - (nl - 1) * 0.38, WA - 2 * P - 0.4, nl, gap=0.38)
    # 2 Speed dating
    h2 = 3.02
    card(s, XB, Y0, WB, h2, T)
    y = head(s, XB, Y0, WB, 2, "Speed dating", "3 × 10 MIN", "NEW PARTNER EACH ROUND", acc)
    tb(s, XB + P, y, WB - 2 * P, 0.3, "Tell your partner what you saw. Then listen.", size=16); y += 0.5
    tw = (WB - 2 * P - 2 * 0.14) / 3; th = Y0 + h2 - 0.26 - y
    for i in range(3):
        tx = XB + P + i * (tw + 0.14)
        rect(s, tx, y, tw, th, WHITE, r=0.1)
        tb(s, tx, y + 0.13, tw, 0.25, f"ROUND {i + 1}", size=11.5, color=acc, bold=True, align=PP_ALIGN.CENTER, spc=120)
        tb(s, tx, y + 0.4, tw, 0.36, "10 min", size=21, color=NAVY, bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        tb(s, tx, y + 0.8, tw, 0.26, "New partner", size=13.5, color=GRAY, align=PP_ALIGN.CENTER)
    # 3 One shared vision
    y3 = Y0 + h2 + G
    card(s, XB, y3, WB, YB - y3, T)
    y = head(s, XB, y3, WB, 3, "One shared vision", "40 MIN", "WHOLE GROUP", acc)
    tb(s, XB + P, y, WB - 2 * P, 0.6, "Bring your post-its to the vision table. Together we group similar ones and name each theme.", size=16); y += 0.84
    tb(s, XB + P, y, WB - 2 * P, 0.25, "DOES OUR VISION DELIVER ON EACH OF THESE?", size=11.5, color=GRAY, bold=True, spc=110)
    for i, g in enumerate(TX["p3_checks"]):
        cx = XB + P + [0, 1.62, 3.62, 0, 1.62][i]; cy = y + 0.36 + (i // 3) * 0.38
        rect(s, cx, cy, 0.24, 0.24, WHITE, r=0.04, line=acc, lw=1.25)
        tb(s, cx + 0.34, cy - 0.03, 1.8, 0.3, g, size=14.5, color=DARK, anchor=MSO_ANCHOR.MIDDLE)
    # 4 Menti
    h4 = 1.9
    card(s, XC, Y0, WC, h4, T)
    y = head(s, XC, Y0, WC, 4, "Enter in Menti", "5 MIN", "ON YOUR PHONE", acc)
    tb(s, XC + P, y, WC - 2 * P, 0.6, TX["menti_q2"], size=16.5, color=NAVY, bold=True, lsp=0.98)
    # 5 First priorities
    y5 = Y0 + h4 + G
    card(s, XC, y5, WC, YB - y5, T)
    y = head(s, XC, y5, WC, 5, "First priorities", "20 MIN", "AT YOUR TABLE", acc)
    for lab, q in TX["p3_priorities"]:
        tb(s, XC + P, y, WC - 2 * P, 0.3, lab, size=17, color=NAVY, bold=True)
        tb(s, XC + P, y + 0.32, WC - 2 * P, 0.52, q, size=14.5, color=DARK, lsp=0.96)
        lines(s, XC + P, y + 0.95, WC - 2 * P, 1, gap=0.42); y += 1.16


def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cfg = json.load(open(sys.argv[1], encoding="utf-8"))
    w = cfg.get("workshop", {})
    TX = defaults(w); TX.update({k: v for k, v in cfg.get("placemats", {}).items() if not k.startswith("_")})
    lib.FOOTER = TX["footer"]
    lib.FOOTER_LOGOS = TX.get("footer_logos", lib.FOOTER_LOGOS)
    lib.HOST_LOGO = TX.get("host_logo", lib.HOST_LOGO)
    if TX.get("font"):
        lib.set_fonts(TX["font"], TX.get("font_black", TX["font"]))
    if "--skeletons" in sys.argv:
        ws = json.load(open(sys.argv[sys.argv.index("--skeletons") + 1], encoding="utf-8"))
        names = {e["code"]: e["name"] for u in ws["uncertainties"] for e in u["end_states"]}
        owner = {e["code"]: u.get("short") or u["name"] for u in ws["uncertainties"] for e in u["end_states"]}
        for sk in ws["skeletons"]:
            rows = [(owner[c], names[c]) for c in sk["combo"]]
            placemat2(TX, N=2, SK={"rows": rows, "label": sk.get("table") or ("Skeleton " + sk["id"])})
    else:
        placemat1(TX); placemat2(TX); placemat3(TX)
    prs.save(sys.argv[2]); print("ok", len(prs.slides), "page(s) ->", sys.argv[2])


if __name__ == "__main__":
    main()
