"""Drawing helpers for the A3 workshop placemats. Design by SA Futures Agency."""
import os, sys
from pptx import Presentation
from pptx.util import Inches, Pt, Mm
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from lxml import etree

A = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "placemat") + os.sep
FOOTER = ""
FOOTER_LOGOS = ["partner_logo_1.png", "partner_logo_2.png"]   # left out if the file is not in assets/placemat
HOST_LOGO = "host_logo.png"
METHOD_LOGO = "safa_dark.png"
TOTAL_PAGES = 3
NS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
def C(h): return RGBColor.from_string(h)
def mix(h, pct):
    v = [int(h[i:i+2], 16) for i in (0, 2, 4)]
    return RGBColor(*[round(255 - (255 - x) * pct) for x in v])
NAVY, TEAL, SKY, GREEN, ORANGE, GOLD, BLUE, CORAL, PURPLE = "28537D", "0297A6", "46BBD4", "22AD7A", "E86933", "DD9103", "5088C6", "F15B6C", "9853A1"
CYC = [TEAL, GOLD, ORANGE, BLUE, CORAL, GREEN, SKY, PURPLE]
DARK, GRAY, WHITE, LINE = "1F2D3A", "5B6770", "FFFFFF", "9FB0BF"
FONT, BLACK = "Aptos", "Aptos Black"
def set_fonts(font, black):
    global FONT, BLACK
    FONT, BLACK = font, black
W, HH = 16.535, 11.693
prs = Presentation(); prs.slide_width = Mm(420); prs.slide_height = Mm(297)

def tb(s, x, y, w, h, text, size=15, color=DARK, bold=False, italic=False, font=None, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, spc=None, lsp=None, after=None):
    t = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); tf = t.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0; tf.vertical_anchor = anchor
    font = font or FONT
    paras = text if isinstance(text, list) else [text]
    for i, para in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph(); p.alignment = align
        if lsp: p.line_spacing = lsp
        if after is not None: p.space_after = Pt(after)
        runs = para if isinstance(para, list) else [(para, color, bold)]
        for run in runs:
            txt, col, b = run[:3]
            r = p.add_run(); r.text = txt; f = r.font; f.size = Pt(run[3] if len(run) > 3 else size); f.color.rgb = C(col); f.bold = b; f.italic = italic
            f.name = (run[4] if len(run) > 4 else font) if (run[4] if len(run) > 4 else font) != "__BLACK__" else BLACK
            if spc: r._r.get_or_add_rPr().set("spc", str(spc))
    return t

def _clean(sh):
    st = sh._element.find(qn('p:style'))
    if st is not None: sh._element.remove(st)

def rect(s, x, y, w, h, color, r=None, line=None, lw=0.75, shadow=None):
    sh = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if r else MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    if r: sh.adjustments[0] = min(0.5, r / min(w, h))
    _clean(sh)
    if color is None: sh.fill.background()
    else: sh.fill.solid(); sh.fill.fore_color.rgb = color if isinstance(color, RGBColor) else C(color)
    if line is None: sh.line.fill.background()
    else: sh.line.color.rgb = line if isinstance(line, RGBColor) else C(line); sh.line.width = Pt(lw)
    if shadow: _shadow(sh, *shadow)
    return sh

def _shadow(sh, blur=0.14, dist=0.05, alpha=24):
    spPr = sh._element.spPr
    for e in spPr.findall(qn('a:effectLst')): spPr.remove(e)
    spPr.append(etree.fromstring(f'<a:effectLst {NS}><a:outerShdw blurRad="{int(blur*914400)}" dist="{int(dist*914400)}" dir="5400000" algn="t" rotWithShape="0"><a:srgbClr val="16324D"><a:alpha val="{alpha*1000}"/></a:srgbClr></a:outerShdw></a:effectLst>'))

def pill(s, x, y, w, h, text, fill, fg=WHITE, size=12, spc=120, line=None):
    sh = rect(s, x, y, w, h, fill, r=h / 2, line=line); tf = sh.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0; tf.vertical_anchor = MSO_ANCHOR.MIDDLE; tf.word_wrap = False
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER; r = p.add_run(); r.text = text
    r.font.size = Pt(size); r.font.bold = True; r.font.color.rgb = C(fg); r.font.name = FONT
    if spc: r._r.get_or_add_rPr().set("spc", str(spc))
    return sh

def pic(s, name, x, y, w=None, h=None):
    kw = {}
    if w: kw["width"] = Inches(w)
    if h: kw["height"] = Inches(h)
    if not name or not os.path.exists(A + name):
        return None   # a logo that has not been supplied is left out
    return s.shapes.add_picture(A + name, Inches(x), Inches(y), **kw)

def lines(s, x, y, w, n, gap=0.4, color=LINE):
    for i in range(n): rect(s, x, y + i * gap, w, 0.013, color)
    return y + n * gap

def _catmull(pts, closed):
    n = len(pts); segs = []
    for i in (range(n) if closed else range(n - 1)):
        p0 = pts[(i - 1) % n] if (closed or i > 0) else pts[0]
        p1 = pts[i]; p2 = pts[(i + 1) % n]
        p3 = pts[(i + 2) % n] if (closed or i + 2 < n) else pts[-1]
        segs.append(((p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6), (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6), p2))
    return segs

def blob(s, pts, fill=None, grad=None, ang=0, line=None, lw=1.0, closed=True, alpha=None):
    segs = _catmull(pts, closed)
    allp = [pts[0]] + [q for sg in segs for q in sg]
    x0, x1 = min(p[0] for p in allp), max(p[0] for p in allp); y0, y1 = min(p[1] for p in allp), max(p[1] for p in allp)
    sh = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x0), Inches(y0), Inches(x1 - x0), Inches(y1 - y0)); _clean(sh)
    spPr = sh._element.spPr; prst = spPr.find(qn('a:prstGeom')); idx = list(spPr).index(prst); spPr.remove(prst)
    E = 914400; P = lambda p: f'<a:pt x="{int((p[0]-x0)*E)}" y="{int((p[1]-y0)*E)}"/>'
    path = f'<a:path w="{int((x1-x0)*E)}" h="{int((y1-y0)*E)}"' + ('' if closed else ' fill="none"') + f'><a:moveTo>{P(pts[0])}</a:moveTo>' + ''.join(f'<a:cubicBezTo>{P(a)}{P(b)}{P(c)}</a:cubicBezTo>' for a, b, c in segs) + ('<a:close/>' if closed else '') + '</a:path>'
    spPr.insert(idx, etree.fromstring(f'<a:custGeom {NS}><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/><a:pathLst>{path}</a:pathLst></a:custGeom>'))
    if grad:
        sh.fill.gradient(); sh.fill.gradient_angle = ang; st = sh.fill.gradient_stops
        st[0].color.rgb = C(grad[0]); st[0].position = 0; st[1].color.rgb = C(grad[1]); st[1].position = 1.0
    elif fill: sh.fill.solid(); sh.fill.fore_color.rgb = C(fill)
    else: sh.fill.background()
    if line:
        sh.line.color.rgb = C(line); sh.line.width = Pt(lw)
        if alpha is not None:
            clr = sh._element.spPr.find(qn('a:ln')).find(qn('a:solidFill')).find(qn('a:srgbClr'))
            clr.append(etree.fromstring(f'<a:alpha {NS} val="{alpha*1000}"/>'))
    else: sh.line.fill.background()
    return sh

Y0, YB = 4.24, 10.8
def card(s, x, y, w, h, fill): return rect(s, x, y, w, h, fill, r=0.16)
def head(s, x, y, w, n, title, mins, who, acc, dark=False):
    tb(s, x + 0.3, y + 0.1, 0.62, 0.85, str(n), size=46, color=(GOLD if dark else acc), font="__BLACK__", anchor=MSO_ANCHOR.MIDDLE)
    tb(s, x + 0.98, y + 0.19, w - 1.2, 0.42, title, size=23, color=(WHITE if dark else NAVY), bold=True, anchor=MSO_ANCHOR.MIDDLE)
    pw = 0.105 * len(mins) + 0.36
    pill(s, x + 0.98, y + 0.66, pw, 0.29, mins, (GOLD if dark else acc), size=11.5, spc=90)
    tb(s, x + 0.98 + pw + 0.14, y + 0.66, w - 2.4, 0.29, who, size=11.5, color=("D5E2EE" if dark else GRAY), bold=True, anchor=MSO_ANCHOR.MIDDLE, spc=120)
    return y + 1.14
def field(s, x, y, w, h, line=LINE): return rect(s, x, y, w, h, WHITE, r=0.1, line=line, lw=1)
def numbered(s, x, y, w, n, gap=0.46, cols=CYC):
    for i in range(n):
        yy = y + i * gap
        tb(s, x, yy, 0.34, 0.36, str(i + 1), size=19, color=cols[i % len(cols)], font="__BLACK__", anchor=MSO_ANCHOR.MIDDLE)
        rect(s, x + 0.42, yy, w - 0.42, 0.36, WHITE, r=0.18, line=cols[i % len(cols)], lw=1.25)
    return y + n * gap

# ---------- v2 tightened header (overrides the first page()) ----------
Y0, YB = 3.92, 10.8
def page(n, method, title, sub, total, acc, hero_grad, illo, ibox, explain, hero=None, tsize=48):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    rect(s, 0, 0, W, HH, WHITE)
    hero = hero or [(11.7, 1.75), (12.75, 1.52), (13.95, 1.72), (14.7, 2.4), (14.35, 3.2), (13.2, 3.62), (12.0, 3.42), (11.3, 2.62)]
    blob(s, hero, grad=hero_grad, ang=35)
    blob(s, [(-1.2, -1.2), (12.7, -1.2), (12.25, 0.5), (12.8, 1.45), (12.2, 2.3), (11.2, 2.84), (9.0, 3.08), (6.3, 2.86), (3.6, 3.08), (1.3, 2.9), (-1.2, 3.1)], grad=(NAVY, "2D6796"), ang=0)
    blob(s, [(10.7, -0.3), (11.45, 0.7), (11.2, 1.75), (12.2, 2.95), (14.2, 3.45)], line=WHITE, lw=0.9, closed=False, alpha=55)
    tag = f"{n} OF {TOTAL_PAGES}   ·   {method}"
    pw = 0.118 * len(tag) + 0.55
    pill(s, 0.6, 0.42, pw, 0.4, tag, WHITE, fg=NAVY, size=12.5, spc=140)
    tb(s, 0.6 + pw + 0.28, 0.42, 5, 0.4, total, size=12.5, color=WHITE, bold=True, anchor=MSO_ANCHOR.MIDDLE, spc=140)
    tb(s, 0.6, 0.88, 11.3, 0.84, title, size=tsize, color=WHITE, font="__BLACK__", anchor=MSO_ANCHOR.MIDDLE)
    tb(s, 0.62, 1.74, 11.0, 0.4, sub, size=18, color="EAF2F8")
    pic(s, HOST_LOGO, 13.2, 0.36, w=2.9)
    pic(s, METHOD_LOGO, 13.2, 0.93, w=2.9)
    cw = 3.62; y0 = 2.3; ch = 1.38
    for i, (lab, txt) in enumerate(explain):
        x = 0.6 + i * (cw + 0.2)
        rect(s, x, y0, cw, ch, WHITE, r=0.14, shadow=(0.16, 0.05, 26))
        tb(s, x + 0.24, y0 + 0.19, cw - 0.4, 0.25, lab, size=11.5, color=acc, bold=True, spc=130)
        tb(s, x + 0.24, y0 + 0.47, cw - 0.44, 0.85, txt, size=15, color=DARK, lsp=0.98)
    ix, iy, iw, ih = ibox
    pic(s, illo, ix, iy, w=iw) if iw else pic(s, illo, ix, iy, h=ih)
    fx = 0.6
    for lg in FOOTER_LOGOS:
        p_ = pic(s, lg, fx, 11.04, h=0.4)
        if p_ is not None: fx += p_.width / 914400 + 0.3
    tb(s, 5.5, 11.04, W - 0.6 - 5.5, 0.4, FOOTER, size=12, color=GRAY, align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)
    return s
