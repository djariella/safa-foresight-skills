---
name: foresight-workshop-materials
description: Make the slides and A3 placemats for a participatory foresight workshop (horizon scanning, scenarios, visioning) in SA Futures Agency design. Use when preparing workshop materials.
---

# Foresight workshop materials

This skill produces the two things participants look at for a day and a half: the three A3 placemats and the workshop slide deck. Both were designed by Ariella Helfgott and SA Futures Agency. They carry the host's logo, and the SA Futures Agency logo and credit.

The materials do real work in the room. Each placemat shows the steps, timings and prompts for one part of the workshop, so every participant can see where they are, even when they are following through an interpreter. The slides carry the words the facilitator says, in the speaker notes. Keep both simple, large and uncluttered.

## Before you start

Ask for, or find in the conversation:

- The workshop details: country, city, topic, target year, dates, hosts and partner logos. If a workshop file exists (`references/workshop-file.md`), read them from its `workshop` block.
- The run sheet, so timings on the placemats and slides match it. If there is none, use the foresight-workshop-setup skill first.
- The fact base for the country, for the provocation slides.
- The host's logo files and PowerPoint template, if it has one, and any deck from an earlier workshop in this format.

## Placemats

Read `references/placemats.md` for what each placemat contains and why.

1. Copy `assets/example/placemats.config.json` and fill in the `workshop` block, including `system_parts`: the four main parts of the system the workshop is about (see `references/placemats.md`). Leave the `placemats` block empty to get the standard wording with the country, topic and years filled in. Add a key only to change something, for example the three questions for first priorities on placemat 3.
2. Build:
   ```
   python scripts/build_placemats.py CONFIG.json placemats.pptx
   ```
3. On the evening of day 1, once the skeletons are chosen, build placemat 2 for each table with its skeleton written in:
   ```
   python scripts/build_placemats.py CONFIG.json placemat-2-by-table.pptx --skeletons WORKSHOP.json
   ```
4. Open the result and check every page: nothing overflows its card, no text is smaller than 11 point, the timings match the run sheet, the Menti questions match the Menti exactly.
5. Give the user the editable PowerPoint file. For printing, they export it to PDF from PowerPoint (File, Export, PDF) and print at A3, in colour, single-sided.

The placemats use the Aptos font, which comes with Microsoft 365. If you render a preview where Aptos is not installed, the text will look wider than it will in PowerPoint. Say so when you show a preview, and do not shrink text to fit the preview.

To change the layout itself, edit `scripts/build_placemats.py`. The helpers are in `scripts/lib.py`. Keep to `references/brand.md`.

## Slides

Read `references/deck.md`. It gives the outline of the deck section by section, and says which parts are the same at every workshop and which are written fresh.

Build the deck in the host's own PowerPoint template when the host has one, and following `references/brand.md` otherwise. Use the pptx skill if it is available. If the user already has a deck from an earlier workshop in this format, edit a copy of it with python-pptx and do not start again: replace the text in the existing shapes, keep their position, size and font, and update the speaker notes wherever the slide text changes, because the notes hold the words to say.

After building or editing, render every slide to an image and look at each one. Check that no text overflows, that dates, places and the year are right on every slide, and that nothing from an earlier workshop is left in.


## The Menti

The workshop uses one Menti with three questions and no more. The wording is in `references/deck.md`. The placemats and the slides must show exactly the same wording as the Menti. Remind the user to put the join code and QR on the Menti slides once the Menti is live.

## Writing and design

Follow `references/writing-rules.md` for every word and `references/brand.md` for everything visual. Two rules matter most here: plain words that survive interpretation, and nothing too small to read at arm's length.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
