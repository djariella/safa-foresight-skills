# The fact base and the provocations

## The fact base

A sourced set of notes on the country's system today. Every present-day fact used later, in provocation slides, facilitator packs, read-aloud descriptions and the write-up, comes from this document with its source named. It is the single most valuable piece of preparation, and it takes the most time.

Outline, to adapt to the topic:

1. People: population, age, where people live, migration, work.
2. Who uses the system and what they get from it: access, cost, quality, who goes without.
3. Who provides it: the organisations, businesses and workers involved, and how they are organised.
4. What it depends on: natural resources, energy, infrastructure, skills.
5. Markets and trade: prices, imports and exports, dependence on particular suppliers or partners.
6. Waste and side effects: what is lost or wasted, pollution, what is reused now.
7. Climate and shocks: recent floods, droughts, outbreaks, price shocks.
8. Public finance and policy: the main laws and plans, what is funded and for how long.
9. Knowledge and institutions: schooling, training, customary rules, the main organisations.
10. What is already working: local examples of the topic in practice.

For each fact record the figure, the year, the source and a link. Prefer the hosts' own research, national statistics and recent reports from international agencies. Where sources disagree, record both.

## The provocations

Four slides shown at the start of horizon scanning. Their job is to widen where people look before they write their own post-its. They are prompts. They are not the answer, and they should not all point the same way.

Choose four areas where change is under way and the direction matters for the topic. Public finance, trade, climate, and people and cities are common choices.

Each slide has:

- A title that states the change in plain words, such as "Fewer people under 30 live in the regions each year".
- Two or three facts, each with its figure, year and source.
- One real news headline from the past year or two, with its date and publisher.
- One question to the room.

Rules:

- Every fact from the fact base. Nothing invented. If a fact cannot be sourced, leave it out.
- Mix scales: one close to daily life, one national, one from the region or the world.
- Include at least one change that could go well and one that could go badly.
- About a minute each when spoken.
