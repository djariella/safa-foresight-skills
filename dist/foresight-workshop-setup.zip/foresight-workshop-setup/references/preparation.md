# Preparation

## Roles

| Role | What they do |
|---|---|
| Lead facilitator | Holds the room, introduces each activity, chairs the report-back, leads the analysis between the days |
| Second facilitator | Leads horizon scanning and visioning, leads the clustering of the shared vision |
| Table facilitators, one for each table | Keep the table on task and on time, make sure every voice is heard, record the table, photograph the flipcharts |
| Analysis support | Collects recordings, photos and Menti results at lunch on day 1, helps with the analysis and printing |
| Hosts | Welcome, opening and closing remarks, setting the scene |

A table facilitator needs to have been through the method at least once. With more tables than trained people, reduce the number of tables.

## Four to six weeks before

- Dates set, with the half day before the full day.
- Venue: mixed tables, projector and screen, flipcharts at every table, one large extra table for the shared vision, reliable internet.
- Participants invited across sectors, with seating planned so every table is mixed.
- Interpreters booked and briefed.
- Fact base written, with sources.
- Hosts' slides for setting the scene requested.
- Two online preparation sessions with the facilitation team: one on scenario development, one on visioning.

## The week before

- Run sheet final and sent to the venue.
- Deck final, with the hosts' slides and the names of speakers.
- Menti created with three questions and tested in the room.
- Placemats printed at A3, one set for each person.
- Post-its in several colours, markers, flipchart paper, tape.
- A recorder or phone for every table, charged, with storage free.
- A shared folder, with file naming agreed.
- A printer available on the evening of day 1 for placemat 2 and the facilitator packs.

## The day before

The facilitation team walks through the slides, the placemats and the Menti together in the room, sets the tables, tests the projector and the internet, and agrees who records each table.

## Telling participants about recording

Say at the start that tables are recorded so that nothing people say is lost, that the recordings are used only to write up the workshop, and that anyone can ask for the recorder to be paused.

## Working with interpreters

- Interpreters interpret. Do not ask them to facilitate, take notes or explain what a participant "means".
- Brief them before each day on the method words: horizon scanning, critical uncertainty, end state, scenario, skeleton, vision. Debrief at the end of each day.
- Speakers use short sentences and pause. Slides and placemats carry the same words that are spoken.
- Allow extra time for every plenary step. The spare 25 minutes on the afternoon of day 2 is there for this.

## Consent

Tell participants at the start that tables are recorded, why, and that anyone can ask for a recorder to be paused. If the workshop is also treated as research, your organisation will normally require written consent that names the recording. Check this with your ethics or legal contact before the workshop.

## What to expect from a workshop of this length

Scenarios built at a table in 90 minutes open a conversation and show people more than one future. They are not finished strategy scenarios, and some scenario researchers are critical of very short exercises for that reason. The write-up after the workshop is where the scenarios are completed and checked. Say this to the hosts when planning, so the workshop is not asked to carry more than it can.
