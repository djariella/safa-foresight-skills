# Run sheet

Standard timings for the day and a half. Keep the durations. Change clock times to suit the venue.

## Day 1: exploring change (half day)

| Time | Min | Session and step | What happens | Lead | Materials |
|---|---|---|---|---|---|
| 8:30 | 30 | Registration and coffee | Participants sit at mixed tables, with sectors spread across every table | Hosts | |
| 9:00 | 45 | Opening and welcome | Welcome and opening remarks, the program, the purpose and flow of the workshop, working agreements, introductions at tables (one minute each: name, organisation, and one thing about the topic that matters to you) | Hosts | Opening slides |
| 9:45 | 30 | Setting the scene | The system today: what the hosts' research and earlier consultations found | Hosts and partners | Hosts' slides |
| 10:15 | 15 | Break | | | |
| 10:30 | 30 | Introduction to foresight | Four questions about the future, why we use scenarios, how scenarios and vision work together, the journey over the two days | Lead facilitator | Foresight slides |
| 11:00 | 10 | Horizon scanning: introduction | Looking for signs of change, the six places to look (STEEP + V), four provocations about the country | Second facilitator | Provocation slides |
| 11:10 | 10 | Step 1. Notice | On your own. One idea on each post-it | Table facilitators | Placemat 1, post-its |
| 11:20 | 35 | Step 2. Share and discuss | At tables. Read post-its aloud and group them under STEEP + V. Keep every post-it | Table facilitators | Flipchart |
| 11:55 | 15 | Step 3. Enter in Menti | Explain a critical uncertainty: high impact and highly uncertain. Tables agree the factors and the wording, then each person enters them | Lead facilitator | Phones, Menti question 1 |
| 12:10 | 5 | Step 4. Word cloud | Whole room. Read the largest groups and give one uncertainty to each table | Lead facilitator | Results slide |
| 12:15 | 40 | Step 5. End states | At tables. Two or three ways the uncertainty could turn out, each clearly different. Written large on flipchart paper. Photograph every flipchart | Table facilitators | Flipcharts |
| 12:55 | 5 | Wrap-up | Three questions to take away: What surprised you? What did we miss? What future do you hope for? | Hosts | |
| 1:00 | | Lunch | End of day 1 for participants | | |
| Afternoon and evening | | Facilitation team: scenario skeletons | End states written up, every pair rated, team review, morphological analysis, set chosen, day 2 materials made and printed | Lead facilitator, all table facilitators | compatibility-matrix, morphological-analysis, scenario-families, scenario-set-selection and scenario-day2-materials skills |

## Day 2: scenarios and vision (full day)

| Time | Min | Session and step | What happens | Lead | Materials |
|---|---|---|---|---|---|
| 8:30 | 30 | Registration and coffee | Same tables as day 1 | Hosts | |
| 9:00 | 15 | Recap and the skeletons | The uncertainties and end states, how the skeletons were built, the skeleton for each table, what makes a good scenario. Allow 20 minutes if every slide is shown | Lead facilitator | Recap slides |
| 9:15 | 10 | Step 1. Read your skeleton | Every end state is true in the target year. Check everyone understands each one | Table facilitators | Placemat 2, facilitator pack |
| 9:25 | 65 | Step 2. Build your scenario | Talk as if you live there. Eight prompts. Then: how did we get here? Stay inside the skeleton | Table facilitators | Flipchart |
| 10:30 | 10 | Step 3. Name it | A short name and a newspaper headline | Table facilitators | |
| 10:40 | 5 | Step 4. Prepare | Finish the flipchart and choose who reports back | Table facilitators | |
| 10:45 | 15 | Break | | | |
| 11:00 | 75 | Report-back and insights | Each table has ten minutes: five to present and five for questions. Then insights across the set. With four tables that leaves 35 minutes for insights, with five 25, with six 15 | Lead facilitator | Flipchart |
| 12:15 | 60 | Lunch | The visualisation script is rewritten from the report-backs | | |
| 1:15 | 10 | Visioning: introduction | From what could happen to what we want. Why a vision should be ambitious | Second facilitator | |
| 1:25 | 10 | Guided visualisation | Read slowly, with every pause counted | A calm reader | Script |
| 1:35 | 10 | Step 1. Reflect and write | On your own, in silence for the first two or three minutes. One vision element on each post-it | | Placemat 3, post-its |
| 1:45 | 30 | Step 2. Speed dating | Three rounds of ten minutes, a new partner each round | | |
| 2:15 | 25 | Spare time | For changing partners, interpretation and anything that ran over | | |
| 2:40 | 15 | Break | | | |
| 2:55 | 40 | Step 3. One shared vision | Whole group at the vision table. Gather 10, cluster 20, check 10. Photograph the table | Second facilitator | Vision table |
| 3:35 | 5 | Step 4. Enter in Menti | One word for the system you saw | | Menti question 2 |
| 3:40 | 20 | Step 5. First priorities | At tables. Priority opportunities, enabling conditions, partnerships | Table facilitators | Flipchart |
| 4:00 | 15 | Closing | Reflections, Menti question 3, next steps, closing remarks | Hosts | Menti question 3 |

The morning after: a reflection session with the facilitation team.
