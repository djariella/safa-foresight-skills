---
name: foresight-workshop-setup
description: Plan a participatory foresight workshop (horizon scanning, scenarios, visioning) for a new country or topic. Makes the run sheet, roles, checklists, fact base outline, provocations and Menti set.
---

# Foresight workshop setup

This skill plans a day-and-a-half participatory foresight workshop in the format developed by Ariella Helfgott and SA Futures Agency. The format helps a mixed group explore how a system could change, build a set of scenarios for a future year, agree one shared vision, and name first priorities and partnerships.

The people using this skill have usually run the workshop once with expert help. Give them a complete plan they can act on, explain why each part is there, and say what cannot be changed without breaking the method.

## Ask first

Get these before writing anything. Ask for all of them in one message.

1. Country, city and venue.
2. Topic, in a few words (for example, public transport), and the target year. Suggest 10 to 20 years ahead.
3. Dates. The half day has to come before the full day.
4. Number of participants and who they are. Number of tables: four to six.
5. Working languages, and whether there is interpretation.
6. Hosts, partners and the program the workshop belongs to.
7. Who the facilitators are, and which of them have run the method before.
8. Whether a fact base exists for the country and topic.

## What to produce

1. **The workshop file.** Create `<place>-<year>.workshop.json` with the `workshop` block filled in (`references/workshop-file.md`). The other skills add to it.
2. **The run sheet.** A timed table for each day with the session, step, what happens, the lead, and the slides and materials. Start from `references/run-sheet.md`, which has the standard timings, and adjust the clock times, names and number of tables. Keep the durations unless the user has a reason to change them.
3. **Roles.** One lead facilitator, a second facilitator, one trained table facilitator for each table, analysis support, and hosts. Say plainly if there are more tables than trained facilitators, and recommend fewer tables.
4. **A preparation checklist** with dates counted back from the workshop: `references/preparation.md`.
5. **A fact base outline**, or a review of the one supplied: `references/fact-base-and-provocations.md`.
6. **Four draft provocations** for horizon scanning, each with two or three facts and a real headline to look for. Mark every fact with its source, or as "to check". Never invent a figure or a headline.
7. **The three Menti questions**, worded for this topic and country.
8. **The participant mix to aim for**, by sector, including people who use the system as well as those who run it, and including people with the power to act on the results. A review of 23 participatory scenario cases found powerful actors missing in 8 of them.
9. **Where the results will go.** Ask which decision, plan or policy process the workshop feeds, who will carry it there, and what follow-up is planned. Evaluations of scenario workshops find that contacts and understanding are the usual results, and that changes in policy came where the work was tied to a live policy process and people kept in touch with decision makers afterwards. Write the answer into the plan.

Deliver the run sheet as a document the team can edit, and the rest as a short plan.

## What must not change

Explain these if the user asks to change them.

- The half day comes first. The team needs the afternoon and evening between the days to build the scenario skeletons.
- Day 1 ends with end states. Day 2 starts with skeletons.
- Scenarios come before the vision, so the vision is tested against more than one future.
- People write on their own before any group discussion, in horizon scanning and in visioning.
- One Menti, three questions.
- One trained facilitator at every table.

If the team cannot do the analysis between the days, offer the shorter two-axis method described in the morphological-analysis skill, and say what it loses.

## Next

When the plan is agreed, the foresight-workshop-materials skill makes the placemats and slides.

Follow `references/writing-rules.md` and `references/brand.md` in everything you write.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
