#!/usr/bin/env python3
"""Build the team review pack: one self-contained HTML page to put on screen during the
team review and to print afterwards (open it in a browser and print to PDF).

Usage:  python review_pack.py WORKSHOP.json [OUT.html]

It shows the end states, the rating key, the matrix, the pairs that cannot both be true,
the unusual pairings and their stories, the results, the families, the candidates, the
topic questions each candidate raises, and (when chosen) the skeletons.
"""
import base64, html, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from morph import Model, analyse, anchor_combo, load

HERE = os.path.dirname(os.path.abspath(__file__))
BRAND = os.path.join(HERE, "..", "assets", "brand")
COL = {"S": ("#22AD7A", "#fff"), "I": ("#DCE6EE", "#22303C"), "T": ("#FFD166", "#22303C"), "X": ("#1C3D5E", "#fff"), "Q": ("#E86933", "#fff")}
KEY = [("S", "They support each other", "One makes the other more likely."),
       ("I", "They can sit side by side", "Neither affects the other much."),
       ("T", "An unusual pairing that can still be true", "It needs a story."),
       ("X", "They cannot both be true", "As the end states are written."),
       ("Q", "Not decided yet", "The team settles it as S, I, T or X.")]


def img(name, h):
    p = os.path.join(BRAND, name)
    if not os.path.exists(p):
        return ""
    b = base64.b64encode(open(p, "rb").read()).decode()
    return f'<img src="data:image/png;base64,{b}" style="height:{h}">'


def e(s):
    return html.escape(str(s or ""))


CSS = """
@page{size:A4 landscape;margin:12mm}
*{box-sizing:border-box}body{font-family:Helvetica,Arial,'Liberation Sans',sans-serif;color:#22303C;margin:0;background:#F4F6F7;font-size:11pt;line-height:1.45}
section{background:#fff;margin:14px auto;padding:26px 34px;max-width:1180px;border-radius:8px;page-break-after:always}
.eyebrow{color:#E86933;font-weight:bold;letter-spacing:3px;font-size:9.5pt;text-transform:uppercase}
h1{color:#28537D;font-size:25pt;margin:4px 0 6px 0;line-height:1.12}h2{color:#28537D;font-size:19pt;margin:4px 0 12px 0}
h3{color:#0297A6;font-size:12.5pt;margin:14px 0 4px 0}.sub{color:#5B6770;max-width:820px}
.logos{display:flex;gap:26px;align-items:center;margin-top:22px;padding-top:14px;border-top:1px solid #D5DEE5}.logos .r{margin-left:auto}
.tiles{display:grid;grid-template-columns:repeat(8,1fr);gap:8px;margin:14px 0}
.tile{background:#F4F6F7;border-top:5px solid #0297A6;border-radius:5px;text-align:center;padding:10px 4px}.tile b{display:block;font-size:24pt;color:#28537D;line-height:1}.tile span{font-size:8.5pt;color:#5B6770}
.tile.end{border-color:#E86933}.tile.end b{color:#E86933}
.cols{display:grid;gap:12px}.card{background:#F4F6F7;border-radius:6px;padding:12px 14px;border-top:5px solid #28537D}
.card h4{margin:0 0 6px 0;color:#28537D;font-size:11pt}.es{background:#fff;border-radius:5px;padding:8px 10px;margin-top:7px;font-size:9.5pt}.es b{color:#0297A6}
table{border-collapse:collapse;width:100%;font-size:9.5pt}th{background:#28537D;color:#fff;text-align:left;padding:6px 8px;vertical-align:bottom}td{padding:6px 8px;border-bottom:1px solid #D5DEE5;vertical-align:top}
table.mx td,table.mx th{text-align:center;padding:5px 3px;font-size:8.5pt}table.mx th.rowh{text-align:left;background:#F4F6F7;color:#22303C;min-width:170px}
table.mx td.r{font-weight:bold;border:2px solid #fff;border-radius:4px}
.key{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0}.key div{display:flex;align-items:center;gap:8px;font-size:9.5pt}.chip{display:inline-block;width:26px;height:26px;border-radius:5px;text-align:center;line-height:26px;font-weight:bold}
.fam{display:grid;gap:8px}.fc{background:#F4F6F7;border-radius:6px;padding:10px 12px;font-size:9.5pt}.fc.edge{background:#1C3D5E;color:#fff}.fc b{display:block;font-size:8pt;letter-spacing:2px;color:#E86933}
.fc.edge b{color:#FFD166}.fc .n{font-size:17pt;font-weight:bold;color:#28537D}.fc.edge .n{color:#fff}
.note{background:#E9F6F8;border-left:6px solid #0297A6;border-radius:5px;padding:10px 14px;margin:12px 0;font-size:10pt}
.warn{background:#FDF0E8;border-left:6px solid #E86933;border-radius:5px;padding:10px 14px;margin:12px 0;font-size:10pt}
.credit{font-size:8.5pt;color:#7a8791;margin-top:14px}
@media print{body{background:#fff}section{margin:0;border-radius:0;max-width:none}}
"""


def build(path, out=None):
    w = load(path)
    m = Model(w)
    r = analyse(m)
    ws = w.get("workshop", {})
    credit = ws.get("method_credit", "Foresight method and materials: SA Futures Agency")
    H = []
    add = H.append
    nsk = len(w.get("skeletons", []))
    tiles = [(r["uncertainties"], "uncertainties"), (r["end_states"], "end states"), (r["pairs_rated"], "pairs rated"),
             (r["combinations"], "possible combinations"), (r["survivors"], "survive the check"),
             (len([f for f in r["families"] if f["size"]]), "families"), (len(w.get("candidates", [])), "candidates"),
             (nsk or ws.get("tables", ""), "skeletons")]
    add(f'<section><div class="eyebrow">Team review pack</div><h1>From the tables\' end states to scenario skeletons</h1>'
        f'<div class="sub">{e(ws.get("title", ""))}. What the tables produced on day 1, which end states can be true together, and the candidate skeletons for the team to choose from.</div>'
        '<div class="tiles">' + "".join(f'<div class="tile{" end" if i == 7 else ""}"><b>{e(n)}</b><span>{e(l)}</span></div>' for i, (n, l) in enumerate(tiles)) + "</div>")
    if r["problems"] or r["missing_pairs"] or r["rating_counts"]["Q"]:
        add(f'<div class="warn"><b>Not final yet.</b> {len(r["missing_pairs"])} pairs have no rating and {r["rating_counts"]["Q"]} are still Q. The numbers will change when the team settles them.</div>')
    add(f'<div class="logos">{img("host_logo.png", "30px")}{img("partner_logo_1.png", "38px")}<span class="r">{img("safa_dark.png", "20px")}</span></div><div class="credit">{e(credit)}</div></section>')
    # end states
    add(f'<section><div class="eyebrow">What the tables produced</div><h2>{r["uncertainties"]} uncertainties, {r["end_states"]} end states</h2>'
        f'<div class="cols" style="grid-template-columns:repeat({min(len(m.unc), 4)},1fr)">')
    for u in m.unc:
        add(f'<div class="card"><h4>{e(u.get("name"))}</h4>' + "".join(
            f'<div class="es"><b>{e(s["code"])} {e(s.get("name"))}</b><br>{e(s.get("description", ""))}'
            + (f'<br><i>Team note: {e(s["team_note"])}</i>' if s.get("team_note") else "") + "</div>" for s in u["end_states"]) + "</div>")
    add('</div><div class="note">For the team: read each one aloud. The table facilitator confirms or corrects the wording. Agree anything that was added or merged.</div></section>')
    # key + matrix
    rc = r["rating_counts"]
    add('<section><div class="eyebrow">The compatibility check</div><h2>Can both be true in this country in the target year?</h2><div class="key">'
        + "".join(f'<div><span class="chip" style="background:{COL[k][0]};color:{COL[k][1]}">{k}</span><span><b>{e(t)}</b> ({rc[k]})<br>{e(d)}</span></div>' for k, t, d in KEY) + "</div>")
    rows = [x for u in m.order[:-1] for x in m.states[u]]
    cols = [x for u in m.order[1:] for x in m.states[u]]
    add('<table class="mx"><tr><th></th>' + "".join(f"<th>{e(c)}<br>{e(m.short[c])}</th>" for c in cols) + "</tr>")
    for a in rows:
        add(f'<tr><th class="rowh">{e(a)} {e(m.short[a])}</th>')
        for b in cols:
            if m.order.index(m.owner[b]) <= m.order.index(m.owner[a]):
                add("<td></td>")
            else:
                k = m.rating(a, b)
                add(f'<td class="r" style="background:{COL[k][0]};color:{COL[k][1]}">{k}</td>')
        add("</tr>")
    add("</table></section>")
    # X
    add('<section><div class="eyebrow">Part 1 of the review</div><h2>Pairs that cannot both be true</h2><table><tr><th>Pair</th><th>Why</th><th>Removes</th></tr>')
    for p in r["x_pairs"]:
        add(f'<tr><td><b>{e(p["a"])}</b> {e(m.name[p["a"]])}<br><b>{e(p["b"])}</b> {e(m.name[p["b"]])}</td><td>{e(p["reason"]) or "<b>Reason needed</b>"}</td><td>{p["removes"]}</td></tr>')
    add(f'</table><div class="note">For each one, someone argues that both could be true. Four checks: Are we rating the end states as written? Is it impossible, or only unlikely? Could both be true within the years we have? Does the story that makes it work change one end state into another? Together these pairs remove {r["removed"]} of the {r["combinations"]} combinations.</div>')
    qs = [(k, i) for k, i in m.pairinfo.items() if m.pairs[k] == "Q"]
    if qs:
        add("<h3>Open pairs for the team to settle</h3><table><tr><th>Pair</th><th>Note</th></tr>" + "".join(
            f'<tr><td><b>{e(i["a"])}</b> {e(m.name[i["a"]])}<br><b>{e(i["b"])}</b> {e(m.name[i["b"]])}</td><td>{e(i.get("reason", ""))}</td></tr>' for k, i in qs) + "</table>")
    add("</section>")
    # T
    ts = [(k, i) for k, i in m.pairinfo.items() if m.pairs[k] == "T"]
    add('<section><div class="eyebrow">Part 2 of the review</div><h2>Unusual pairings, and the story for each</h2><table><tr><th style="width:36%">Pair</th><th>Story</th></tr>')
    for k, i in ts:
        add(f'<tr><td><b>{e(i["a"])}</b> {e(m.name[i["a"]])}<br><b>{e(i["b"])}</b> {e(m.name[i["b"]])}</td><td>{e(i.get("story")) or "<b>Story needed</b>"}</td></tr>')
    add('</table><div class="note">Tell each story aloud. If the team believes it, the pair stays T and the story goes into the skeleton. If nobody can tell a believable story, the pair becomes X.</div></section>')
    # results + families
    add(f'<section><div class="eyebrow">Part 3 of the review</div><h2>Of {r["combinations"]} combinations, {r["survivors"]} survive</h2><ul>')
    add(f'<li>{r["removed"]} were removed because they contain a pair that cannot both be true.</li><li>{r["all_supporting"]} have every pair supporting each other. These are the combinations people reach for first.</li>')
    if r["compatible_with_everything"]:
        add("<li>Compatible with every other end state: " + "; ".join(f"{e(x)} {e(m.name[x])}" for x in r["compatible_with_everything"]) + ".</li>")
    for p in r["x_pairs"]:
        add(f'<li>{e(p["a"])} {e(m.name[p["a"]])} never appears with {e(p["b"])} {e(m.name[p["b"]])}.</li>')
    add("</ul>")
    cand_by_fam = {}
    for c in w.get("candidates", []):
        cand_by_fam[c.get("family")] = c
    if r["families"]:
        a0, a1 = r["family_axes"]
        add(f'<h3>Families: {e(m.uname[a0])} by {e(m.uname[a1])}</h3><div class="fam" style="grid-template-columns:160px repeat({len(m.states[a1])},1fr)"><div></div>'
            + "".join(f'<div class="fc"><b>{e(s)}</b>{e(m.name[s])}</div>' for s in m.states[a1]))
        hop, wor = r["edges"].get("hopeful"), r["edges"].get("worrying")
        it = iter(r["families"])
        for s0 in m.states[a0]:
            add(f'<div class="fc"><b>{e(s0)}</b>{e(m.name[s0])}</div>')
            for s1 in m.states[a1]:
                f = next(it)
                combos = [c["combo"] for c in f["members"]]
                anc = anchor_combo(w)
                edge = (anc in combos) if anc else ((hop in combos) or (wor in combos))
                lab = "anchor" if (anc and anc in combos) else ("most hopeful" if hop in combos else ("most worrying" if wor in combos else ""))
                c = cand_by_fam.get(f["n"])
                add(f'<div class="fc{" edge" if edge else ""}"><b>FAMILY {f["n"]}{" · " + lab.upper() if lab else ""}</b><span class="n">{f["size"]}</span> combinations'
                    + (f'<br>Candidate {e(c["id"])}: {e(c["title"])}' if c else "") + "</div>")
        add("</div>")
    add("</section>")
    # candidates and questions
    if w.get("candidates"):
        qs = w.get("topic_questions", [])
        add('<section><div class="eyebrow">Part 3 of the review</div><h2>The candidates, and the questions each one raises</h2><table><tr><th>Candidate</th>'
            + "".join(f"<th>{e(m.uname[u])}</th>" for u in m.order) + "<th>Unusual pairs</th>" + "".join(f'<th>{e(q["id"])} {e(q.get("short", ""))}</th>' for q in qs) + "</tr>")
        chosen = [s["id"] for s in w.get("skeletons", [])]
        for c in w["candidates"]:
            t = sum(1 for i, a in enumerate(c["combo"]) for b in c["combo"][i + 1:] if m.rating(a, b) == "T")
            add(f'<tr><td><b>{e(c["id"])} {e(c["title"])}</b>{" (chosen)" if c["id"] in chosen else ""}</td>' + "".join(f"<td>{e(x)} {e(m.short[x])}</td>" for x in c["combo"]) + f"<td>{t}</td>"
                + "".join("<td>" + ("<b>Central</b>" if q["id"] in c.get("central", []) else ("Partly" if q["id"] in c.get("partly", []) else "")) + "</td>" for q in qs) + "</tr>")
        add("</table>")
        if qs:
            add("<h3>The questions</h3><ol>" + "".join(f'<li value="{e(q["id"])}"><b>{e(q.get("short", ""))}.</b> {e(q["question"])} <i>{e(q.get("heard", ""))}</i></li>' for q in qs) + "</ol>")
        add('<div class="note">For each candidate: is it plausible, is it interesting, and can a table build it in 90 minutes? Then choose one skeleton for each table against the eight criteria in references/selection-criteria.md.</div></section>')
    for s in w.get("skeletons", []):
        add(f'<section><div class="eyebrow">Skeleton {e(s["id"])}{" · " + e(s.get("table", "")) if s.get("table") else ""}</div><h2>{e(s["id"])}. {e(s["title"])}</h2><div class="sub">{e(s.get("tagline", ""))}</div>'
            '<div class="cols" style="grid-template-columns:1fr 1.3fr;margin-top:14px"><div>'
            + "".join(f'<div class="card" style="margin-bottom:8px"><h4>{e(m.uname[m.owner[x]])}</h4><b style="color:#0297A6">{e(x)}</b> {e(m.name[x])}</div>' for x in s["combo"])
            + f'</div><div><h3>How it fits together</h3><p>{e(s.get("how_it_fits", ""))}</p><h3>What it asks about {e(ws.get("topic", "the topic"))}</h3><p>{e(s.get("asks", ""))}</p></div></div></section>')
    doc = f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Team review pack: {e(ws.get("title", ""))}</title><style>{CSS}</style></head><body>{"".join(H)}</body></html>'
    out = out or os.path.join(os.path.dirname(os.path.abspath(path)), "team-review-pack.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(doc)
    print("Wrote", out)


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__); sys.exit(0 if len(sys.argv) > 1 else 1)
    build(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
