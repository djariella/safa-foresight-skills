#!/usr/bin/env python3
"""Morphological analysis for multi-factor, multi-state scenario building.

Reads a workshop file (JSON) holding the critical uncertainties, their end states and
a rating for every pair of end states, and works out which combinations can be true
together, how they group into families, and which sets of skeletons meet the criteria.

Ratings:  S support each other | I can sit side by side | T unusual pairing that can
          still be true (needs a story) | X cannot both be true | Q not decided yet

Commands
  couplings    FILE           list every pair of uncertainties so the team can mark how strongly they are linked
  template     FILE           add every missing pair of end states (rating Q, or I where the uncertainties are independent)
  pairs-export FILE [CSV]     write the pairs to a spreadsheet file for the team to rate
  pairs-import FILE CSV       read the team's ratings back in
  check        FILE           validate the file and list what is missing
  whole        FILE [--set A,B]  lay out each candidate with all its pairs, for the whole-combination review
  analyse      FILE [--out D] run the analysis; writes analysis.json and analysis.md
  sensitivity  FILE           show what changes if each contested or open rating went the other way
  families     FILE [--cluster K]
                              group the survivors into families, by two uncertainties or by similarity
  sets         FILE [--n N] [--anchor A] [--pool candidates|survivors] [--max-unusual K] [--set A,B,D,E] [--top K]
                              rank sets of N skeletons against the selection criteria, or check one set
  twoaxis      FILE A B       the two-axis (deductive) method on uncertainties A and B

No third-party packages are needed.
"""
import argparse, collections, csv, itertools, json, os, random, sys

RATINGS = {"S": "support each other", "I": "can sit side by side",
           "T": "unusual pairing that can still be true", "X": "cannot both be true",
           "Q": "not decided yet"}


def load(path):
    with open(path, encoding="utf-8") as f:
        w = json.load(f)
    # topic questions may be written as plain sentences; give each one a number
    qs = []
    for i, q in enumerate(w.get("topic_questions", []) or [], 1):
        if isinstance(q, str):
            q = {"id": i, "short": "", "question": q}
        q.setdefault("id", i)
        qs.append(q)
    if qs:
        w["topic_questions"] = qs
    return w


def save(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1, ensure_ascii=False)


class Model:
    def __init__(self, w):
        self.w = w
        self.unc = w["uncertainties"]
        self.order = [u["code"] for u in self.unc]
        self.states = {u["code"]: [e["code"] for e in u["end_states"]] for u in self.unc}
        self.owner = {e: u for u, es in self.states.items() for e in es}
        self.name = {e["code"]: e.get("name", e["code"]) for u in self.unc for e in u["end_states"]}
        self.short = {e["code"]: e.get("short", e.get("name", e["code"])) for u in self.unc for e in u["end_states"]}
        self.uname = {u["code"]: u.get("name", u["code"]) for u in self.unc}
        self.pairs = {}
        self.pairinfo = {}
        self.problems = []
        for p in w.get("pairs", []):
            a, b, r = p.get("a"), p.get("b"), str(p.get("rating", "Q")).upper()
            if a not in self.owner or b not in self.owner:
                self.problems.append(f"pair {a}/{b}: unknown end state code")
                continue
            if self.owner[a] == self.owner[b]:
                self.problems.append(f"pair {a}/{b}: both belong to the same uncertainty, so they are never compared")
                continue
            if r not in RATINGS:
                self.problems.append(f"pair {a}/{b}: rating '{r}' is not one of S, I, T, X, Q")
                continue
            key = frozenset((a, b))
            if key in self.pairs:
                self.problems.append(f"pair {a}/{b}: rated more than once")
            self.pairs[key] = r
            self.pairinfo[key] = p

    def expected_pairs(self):
        out = []
        for u1, u2 in itertools.combinations(self.order, 2):
            for a in self.states[u1]:
                for b in self.states[u2]:
                    out.append((a, b))
        return out

    def missing(self):
        return [(a, b) for a, b in self.expected_pairs() if frozenset((a, b)) not in self.pairs]

    def rating(self, a, b):
        return self.pairs.get(frozenset((a, b)), "Q")

    def combos(self):
        out = []
        for c in itertools.product(*[self.states[u] for u in self.order]):
            codes = [self.rating(a, b) for a, b in itertools.combinations(c, 2)]
            out.append({"combo": list(c), "codes": codes, "count": dict(collections.Counter(codes))})
        return out


def dist(a, b):
    return sum(1 for x, y in zip(a, b) if x != y)


def cmd_template(args):
    w = load(args.file)
    m = Model(w)
    miss = m.missing()
    w.setdefault("pairs", [])
    indep = {frozenset((c["a"], c["b"])) for c in w.get("couplings", []) if str(c.get("strength", "")).lower().startswith("indep")}
    n_i = 0
    for a, b in miss:
        if frozenset((m.owner[a], m.owner[b])) in indep:
            w["pairs"].append({"a": a, "b": b, "rating": "I", "reason": "The two uncertainties were judged independent of each other.", "default": True})
            n_i += 1
        else:
            w["pairs"].append({"a": a, "b": b, "rating": "Q", "reason": ""})
    save(args.file, w)
    print(f"{len(m.expected_pairs())} pairs are needed. Added {len(miss)}: {len(miss) - n_i} to rate (Q) and {n_i} set to I because their uncertainties are marked independent.")


def cmd_check(args):
    m = Model(load(args.file))
    exp = m.expected_pairs()
    counts = collections.Counter(m.pairs.values())
    print(f"Uncertainties: {len(m.order)}  ({', '.join(u + ' ' + str(len(m.states[u])) for u in m.order)})")
    print(f"End states: {sum(len(v) for v in m.states.values())}")
    print(f"Pairs needed: {len(exp)}   rated: {len(m.pairs)}   missing: {len(m.missing())}")
    print("Ratings: " + ", ".join(f"{k} {counts.get(k, 0)}" for k in "SITXQ"))
    total = 1
    for u in m.order:
        total *= len(m.states[u])
    print(f"Possible combinations: {total}")
    for p in m.problems:
        print("PROBLEM:", p)
    for a, b in m.missing():
        print(f"MISSING: {a} with {b}")
    noreason = [sorted(k) for k, r in m.pairs.items() if r == "X" and not (m.pairinfo[k].get("reason") or "").strip()]
    nostory = [sorted(k) for k, r in m.pairs.items() if r == "T" and not (m.pairinfo[k].get("story") or "").strip()]
    for k in noreason:
        print(f"NEEDS A REASON: {k[0]} with {k[1]} is rated X. Say which words contradict.")
    for k in nostory:
        print(f"NEEDS A STORY: {k[0]} with {k[1]} is rated T. Write how both came to be true.")
    for k, r in m.pairs.items():
        info = m.pairinfo[k]; kind = str(info.get("kind", "")).lower()
        a_, b_ = sorted(k)
        if r == "X" and kind.startswith("norm"):
            print(f"LOOK AGAIN: {a_} with {b_} is rated X on normative grounds. A pairing the team does not want is still possible. Rate it T, or give a logical or empirical reason.")
        elif r == "X" and not kind:
            print(f"ADD THE KIND: {a_} with {b_} is rated X. Say whether the contradiction is logical (in the wording) or empirical (cannot happen in this place by the target year).")
    for e in [x for u in m.order for x in m.states[u]]:
        for u in m.order:
            if u == m.owner[e]:
                continue
            rs = [m.rating(e, o) for o in m.states[u]]
            if all(r == "X" for r in rs):
                print(f"SHUT OUT: {e} {m.name[e]} is rated X against every end state of {m.uname[u]}, so it can never appear in a scenario. Check those ratings with the table facilitator.")
            elif sum(1 for r in rs if r != "X") == 1 and len(rs) > 2:
                print(f"NOTE: {e} {m.name[e]} fits only one end state of {m.uname[u]}. Every scenario with {e} will have that end state.")
    for u in m.order:
        for a, b in itertools.combinations(m.states[u], 2):
            others = [o for v in m.order if v != u for o in m.states[v]]
            if others and all(m.rating(a, o) == m.rating(b, o) for o in others) and not any(m.rating(a, o) == "Q" for o in others):
                print(f"SAME PATTERN: {a} and {b} have the same rating against every other end state. Check that they are really different. Keep both only if a table would build a different story from each.")
    changed = [k for k in m.pairs if m.pairinfo[k].get("draft_rating") and m.pairinfo[k]["draft_rating"] != m.pairs[k]]
    if changed:
        print(f"Ratings the team changed from the first draft: {len(changed)} of {len(m.pairs)}. Report this number in the write-up.")
    contested = [sorted(k) for k in m.pairs if m.pairinfo[k].get("contested")]
    if contested:
        print(f"Contested ratings: {len(contested)}. Run the sensitivity command to see what depends on them.")
    q = [sorted(k) for k, r in m.pairs.items() if r == "Q"]
    for k in q:
        print(f"OPEN: {k[0]} with {k[1]} is still Q. The team needs to settle it.")
    ok = not m.problems and not m.missing() and not q
    print("READY FOR ANALYSIS" if ok else "NOT READY: settle the items above first (analyse will still run and will flag them).")
    return 0 if ok else 1


def analyse(m):
    w = m.w
    combos = m.combos()
    total = len(combos)
    survivors = [c for c in combos if c["count"].get("X", 0) == 0]
    removed = total - len(survivors)
    struck = [x for x in w.get("excluded_combos", []) if x.get("combo")]
    struck_keys = {tuple(x["combo"]) for x in struck}
    n_before = len(survivors)
    survivors = [c for c in survivors if tuple(c["combo"]) not in struck_keys]
    removed_whole = n_before - len(survivors)
    open_dep = [c for c in survivors if c["count"].get("Q", 0) > 0]
    npairs = len(m.order) * (len(m.order) - 1) // 2
    all_s = [c for c in survivors if c["count"].get("S", 0) == npairs]
    # how many combinations each X pair removes on its own
    x_pairs = []
    for key, r in m.pairs.items():
        if r != "X":
            continue
        a, b = sorted(key, key=lambda e: m.order.index(m.owner[e]))
        n = sum(1 for c in combos if a in c["combo"] and b in c["combo"])
        x_pairs.append({"a": a, "b": b, "removes": n, "reason": m.pairinfo[key].get("reason", "")})
    # patterns
    all_states = [e for u in m.order for e in m.states[u]]
    universal = []
    for e in all_states:
        others = [o for o in all_states if m.owner[o] != m.owner[e]]
        if all(m.rating(e, o) != "X" for o in others):
            universal.append(e)
    never = []
    for a, b in m.expected_pairs():
        if m.rating(a, b) == "X":
            continue
        if not any(a in c["combo"] and b in c["combo"] for c in survivors):
            never.append([a, b])
    usage = {e: sum(1 for c in survivors if e in c["combo"]) for e in all_states}
    # families
    axes = w.get("family_axes")
    axis_options = []
    for u1, u2 in itertools.combinations(m.order, 2):
        fam = collections.Counter((c["combo"][m.order.index(u1)], c["combo"][m.order.index(u2)]) for c in survivors)
        cells = len(m.states[u1]) * len(m.states[u2])
        axis_options.append({"axes": [u1, u2], "families": cells, "empty_families": cells - len(fam),
                             "sizes": sorted(fam.values())})
    families = []
    if axes and len(axes) == 2 and all(a in m.order for a in axes):
        i1, i2 = m.order.index(axes[0]), m.order.index(axes[1])
        n = 0
        for a in m.states[axes[0]]:
            for b in m.states[axes[1]]:
                n += 1
                members = [c for c in survivors if c["combo"][i1] == a and c["combo"][i2] == b]
                members.sort(key=lambda c: (-c["count"].get("S", 0), c["count"].get("T", 0), c["count"].get("Q", 0)))
                families.append({"n": n, "key": [a, b], "size": len(members), "members": members})
    edges = w.get("edges", {})
    for c in survivors:
        c["coherence"] = c["count"].get("S", 0); c["surprise"] = c["count"].get("T", 0)
    profile = collections.Counter(c["surprise"] for c in survivors)
    for f in families:
        mem = f["members"]
        if mem:
            f["medoid"] = min(mem, key=lambda c: sum(dist(c["combo"], o["combo"]) for o in mem))["combo"]
            f["most_coherent"] = max(mem, key=lambda c: (c["coherence"], -c["surprise"]))["combo"]
            f["most_surprising"] = max(mem, key=lambda c: (c["surprise"], c["coherence"]))["combo"]
            f["spread"] = {u: sorted({c["combo"][i] for c in mem}) for i, u in enumerate(m.order) if u not in (axes or [])}
    result = {
        "unusual_pairings_profile": {str(k): profile[k] for k in sorted(profile)},
        "uncertainties": len(m.order), "end_states": len(all_states),
        "pairs_needed": len(m.expected_pairs()), "pairs_rated": len(m.pairs),
        "rating_counts": {k: sum(1 for r in m.pairs.values() if r == k) for k in "SITXQ"},
        "combinations": total, "removed": removed, "removed_after_whole_review": removed_whole, "excluded_combos": struck, "survivors": len(survivors),
        "share_removed": round(removed / total, 3) if total else 0,
        "survivors_depending_on_open_pairs": len(open_dep),
        "all_supporting": len(all_s), "all_supporting_list": [c["combo"] for c in all_s],
        "x_pairs": sorted(x_pairs, key=lambda p: -p["removes"]),
        "compatible_with_everything": universal, "never_together_among_survivors": never,
        "end_state_usage": usage, "family_axes": axes, "axis_options": axis_options,
        "families": families, "edges": edges, "survivor_list": survivors,
        "problems": m.problems, "missing_pairs": m.missing(),
    }
    return result


def fmt(m, combo):
    return " + ".join(f"{e} {m.short[e]}" for e in combo)


def report_md(m, r):
    w = m.w.get("workshop", {})
    L = []
    title = w.get("title", "Workshop")
    L.append(f"# Morphological analysis: {title}\n")
    L.append("| | |\n|---|---|")
    L.append(f"| Uncertainties | {r['uncertainties']} |")
    L.append(f"| End states | {r['end_states']} |")
    rc = r["rating_counts"]
    L.append(f"| Pairs rated | {r['pairs_rated']} of {r['pairs_needed']}: {rc['S']} support each other, {rc['I']} sit side by side, {rc['T']} unusual, {rc['X']} cannot both be true, {rc['Q']} not decided |")
    L.append(f"| Possible combinations | {r['combinations']} |")
    L.append(f"| Removed (contain a pair that cannot both be true) | {r['removed']} ({round(100 * r['share_removed'])} per cent) |")
    if r.get("removed_after_whole_review"):
        L.append(f"| Removed after reading whole combinations (three or more end states that cannot all be true) | {r['removed_after_whole_review']} |")
    L.append(f"| Surviving | {r['survivors']} |")
    L.append(f"| Surviving with every pair supporting | {r['all_supporting']} |")
    if r["survivors_depending_on_open_pairs"]:
        L.append(f"| Surviving but depending on an undecided pair | {r['survivors_depending_on_open_pairs']} |")
    L.append("")
    if r["problems"] or r["missing_pairs"] or rc["Q"]:
        L.append("## To settle before these numbers are final\n")
        for p in r["problems"]:
            L.append(f"- {p}")
        for a, b in r["missing_pairs"]:
            L.append(f"- Missing rating: {a} with {b}")
        if rc["Q"]:
            L.append(f"- {rc['Q']} pairs are still rated Q.")
        L.append("")
    share = r["share_removed"]
    if r["rating_counts"]["X"] == 0:
        L.append("> No pair is rated X, so every combination survives. Check with the team whether any pair really cannot be true together.\n")
    elif share < 0.25:
        L.append("> Fewer than a quarter of the combinations were removed. Check whether any pair rated T is really a contradiction.\n")
    elif share > 0.67:
        L.append("> More than two thirds of the combinations were removed. Check each X: is it impossible, or only unlikely? Also check whether two uncertainties overlap.\n")
    # matrix
    L.append("## The matrix\n")
    rows = [e for u in m.order[:-1] for e in m.states[u]]
    cols = [e for u in m.order[1:] for e in m.states[u]]
    L.append("| | " + " | ".join(f"{c} {m.short[c]}" for c in cols) + " |")
    L.append("|---|" + "---|" * len(cols))
    for a in rows:
        cells = []
        for b in cols:
            if m.order.index(m.owner[b]) <= m.order.index(m.owner[a]):
                cells.append("")
            else:
                cells.append(m.rating(a, b))
        L.append(f"| **{a} {m.short[a]}** | " + " | ".join(cells) + " |")
    L.append("\nS support each other. I can sit side by side. T unusual pairing that can still be true. X cannot both be true. Q not decided.\n")
    L.append("## Pairs that cannot both be true\n")
    if r["x_pairs"]:
        L.append("| Pair | Reason | Combinations it removes |\n|---|---|---|")
        for p in r["x_pairs"]:
            L.append(f"| {p['a']} {m.name[p['a']]}, with {p['b']} {m.name[p['b']]} | {p['reason'] or 'REASON NEEDED'} | {p['removes']} |")
        L.append(f"\nSome combinations contain more than one of these pairs. Together they remove {r['removed']} of the {r['combinations']}.\n")
    else:
        L.append("None.\n")
    ts = [(k, i) for k, i in m.pairinfo.items() if m.pairs[k] == "T"]
    L.append("## Unusual pairings and their stories\n")
    if ts:
        L.append("| Pair | Story |\n|---|---|")
        for k, i in ts:
            L.append(f"| {i['a']} {m.name[i['a']]}, with {i['b']} {m.name[i['b']]} | {i.get('story') or 'STORY NEEDED'} |")
        L.append("")
    else:
        L.append("None. A set with no unusual pairings usually produces only a best case and a worst case. Look again for pairs that people would not expect and that could still be true.\n")
    L.append("## Patterns in what survived\n")
    if r["compatible_with_everything"]:
        L.append("- Compatible with every other end state: " + "; ".join(f"{e} {m.name[e]}" for e in r["compatible_with_everything"]) + ".")
    for a, b in r["never_together_among_survivors"]:
        L.append(f"- {a} {m.name[a]} never appears with {b} {m.name[b]}, although the pair itself is not rated X.")
    for p in r["x_pairs"]:
        L.append(f"- {p['a']} {m.name[p['a']]} never appears with {p['b']} {m.name[p['b']]}.")
    unused = [e for e, n in r["end_state_usage"].items() if n == 0]
    for e in unused:
        L.append(f"- WARNING: {e} {m.name[e]} appears in no surviving combination. Check its ratings.")
    L.append("")
    L.append("## Survivors by number of unusual pairings\n")
    L.append("| Unusual pairings inside the combination | Combinations |\n|---|---|")
    for k, v in r["unusual_pairings_profile"].items():
        L.append(f"| {k} | {v} |")
    L.append("\nCombinations with none are the easiest to believe. Combinations with one or more are where the less expected scenarios come from, and each unusual pairing needs its story.\n")
    L.append("## Choosing the two uncertainties that define the families\n")
    L.append("| Uncertainties | Families | Empty families | Sizes |\n|---|---|---|---|")
    for o in r["axis_options"]:
        L.append(f"| {m.uname[o['axes'][0]]} and {m.uname[o['axes'][1]]} | {o['families']} | {o['empty_families']} | {', '.join(map(str, o['sizes']))} |")
    L.append("\nChoose the two where a change of end state changes the story most. Set them as `family_axes` in the workshop file.\n")
    if r["families"]:
        a0, a1 = r["family_axes"]
        L.append(f"## Families by {m.uname[a0]} and {m.uname[a1]}\n")
        hop, wor = r["edges"].get("hopeful"), r["edges"].get("worrying")
        for f in r["families"]:
            L.append(f"### Family {f['n']}: {f['key'][0]} {m.short[f['key'][0]]} with {f['key'][1]} {m.short[f['key'][1]]} ({f['size']} combinations)\n")
            if not f["members"]:
                L.append("No surviving combination.\n")
                continue
            L.append(f"Most central: {fmt(m, f['medoid'])}. Most coherent: {fmt(m, f['most_coherent'])}. Most surprising: {fmt(m, f['most_surprising'])}.\n")
            L.append("| Combination | Ratings | S | T | Note |\n|---|---|---|---|---|")
            for c in f["members"]:
                note = "marked most hopeful" if c["combo"] == hop else ("marked most worrying" if c["combo"] == wor else "")
                if anchor_combo(m.w) == c["combo"]:
                    note = "anchor" + (", " + note if note else "")
                L.append(f"| {fmt(m, c['combo'])} | {''.join(c['codes'])} | {c['count'].get('S', 0)} | {c['count'].get('T', 0)} | {note} |")
            L.append("")
    return "\n".join(L)


def cmd_analyse(args):
    m = Model(load(args.file))
    r = analyse(m)
    out = args.out or os.path.dirname(os.path.abspath(args.file))
    os.makedirs(out, exist_ok=True)
    save(os.path.join(out, "analysis.json"), r)
    with open(os.path.join(out, "analysis.md"), "w", encoding="utf-8") as f:
        f.write(report_md(m, r))
    rc = r["rating_counts"]
    print(f"{r['uncertainties']} uncertainties, {r['end_states']} end states, {r['pairs_rated']} of {r['pairs_needed']} pairs rated "
          f"(S {rc['S']}, I {rc['I']}, T {rc['T']}, X {rc['X']}, Q {rc['Q']})")
    print(f"{r['combinations']} combinations, {r['removed']} removed, {r['survivors']} survive, {r['all_supporting']} with every pair supporting"
          + (f" ({r['removed_after_whole_review']} more removed after reading whole combinations)" if r.get("removed_after_whole_review") else ""))
    if r["families"]:
        print(f"{len(r['families'])} families by {' and '.join(r['family_axes'])}: sizes {[f['size'] for f in r['families']]}")
    for p in r["x_pairs"]:
        print(f"  X {p['a']} with {p['b']} removes {p['removes']}")
    print("Wrote", os.path.join(out, "analysis.json"), "and analysis.md")



def cmd_couplings(args):
    w = load(args.file); m = Model(w)
    have = {frozenset((c["a"], c["b"])): c for c in w.get("couplings", [])}
    w.setdefault("couplings", [])
    added = 0
    for u1, u2 in itertools.combinations(m.order, 2):
        if frozenset((u1, u2)) not in have:
            w["couplings"].append({"a": u1, "b": u2, "strength": "", "note": ""}); added += 1
    save(args.file, w)
    print("How strongly is each pair of uncertainties linked? Mark each as strong, conditional or independent.\n")
    to_rate = 0
    for c in w["couplings"]:
        n = len(m.states[c["a"]]) * len(m.states[c["b"]])
        st = c.get("strength") or "NOT MARKED"
        if not str(st).lower().startswith("indep"):
            to_rate += n
        print(f"  {m.uname[c['a']]} and {m.uname[c['b']]}: {st}  ({n} pairs of end states)")
    print(f"\n{added} added to the file. Pairs of end states that need a judgement: {to_rate} of {len(m.expected_pairs())}. The rest default to I when you run template.")


FIELDS = ["a", "a_name", "b", "b_name", "rating", "kind", "contested", "reason", "story"]


def cmd_pairs_export(args):
    w = load(args.file); m = Model(w)
    out = args.csv or os.path.join(os.path.dirname(os.path.abspath(args.file)), "pairs-to-rate.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        wr = csv.DictWriter(f, fieldnames=FIELDS); wr.writeheader()
        for a, b in m.expected_pairs():
            i = m.pairinfo.get(frozenset((a, b)), {})
            wr.writerow({"a": a, "a_name": m.name[a], "b": b, "b_name": m.name[b], "rating": i.get("rating", "Q"), "kind": i.get("kind", ""),
                         "contested": "yes" if i.get("contested") else "", "reason": i.get("reason", ""), "story": i.get("story", "")})
    print(f"Wrote {out} with {len(m.expected_pairs())} pairs. Rating: S, I, T, X or Q. Kind (for X only): logical or empirical. Contested: yes if the team was split.")


def cmd_pairs_import(args):
    w = load(args.file); m = Model(w)
    by = {frozenset((p["a"], p["b"])): p for p in w.get("pairs", [])}
    n = 0
    with open(args.csv, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            a, b = row["a"].strip(), row["b"].strip()
            if a not in m.owner or b not in m.owner:
                print(f"skipped {a}/{b}: unknown code"); continue
            p = by.get(frozenset((a, b)))
            if p is None:
                p = {"a": a, "b": b}; w.setdefault("pairs", []).append(p); by[frozenset((a, b))] = p
            new = (row.get("rating") or "Q").strip().upper()[:1] or "Q"
            old = p.get("rating")
            if old and old != "Q" and new != old and "draft_rating" not in p:
                p["draft_rating"] = old      # keep the first draft, so the report can say what the team changed
            p["rating"] = new
            for k in ("kind", "reason", "story"):
                if (row.get(k) or "").strip():
                    p[k] = row[k].strip()
            p["contested"] = (row.get("contested") or "").strip().lower() in ("yes", "y", "true", "1")
            p.pop("default", None); n += 1
    save(args.file, w)
    print(f"Read {n} pairs into {args.file}. Run check next.")


def _with_rating(w, a, b, rating):
    w2 = json.loads(json.dumps(w))
    for p in w2["pairs"]:
        if {p["a"], p["b"]} == {a, b}:
            p["rating"] = rating
    return w2


def cmd_sensitivity(args):
    w = load(args.file); m = Model(w)
    base = analyse(m)
    sk = [(s.get("id", ""), s["combo"]) for s in w.get("skeletons", [])] or [(c.get("id", ""), c["combo"]) for c in w.get("candidates", [])]
    tests = []
    for key, r in m.pairs.items():
        info = m.pairinfo[key]
        if not (info.get("contested") or r == "Q" or (args.all_x and r == "X")):
            continue
        a, b = sorted(key, key=lambda e: m.order.index(m.owner[e]))
        for alt in ({"X": ["T"], "T": ["X"], "Q": ["X", "T"]}.get(r, [])):
            tests.append((a, b, r, alt))
    L = [f"# What depends on the contested ratings\n", f"As rated now: {base['survivors']} of {base['combinations']} combinations survive.\n"]
    if not tests:
        L.append("No rating is marked contested and none is still Q. Mark a pair with \"contested\": true when the team was split, or use --all-x to test every X.")
    else:
        L.append("| Pair | Rated | If it were | Survivors | Change | Skeletons or candidates that would no longer be possible |\n|---|---|---|---|---|---|")
        for a, b, r, alt in tests:
            m2 = Model(_with_rating(w, a, b, alt)); r2 = analyse(m2)
            lost = [i or "-".join(c) for i, c in sk if any(m2.rating(x, y) == "X" for x, y in itertools.combinations(c, 2))]
            L.append(f"| {a} {m.short[a]} with {b} {m.short[b]} | {r} | {alt} | {r2['survivors']} | {r2['survivors'] - base['survivors']:+d} | {', '.join(lost) or 'none'} |")
        L.append("\nIf a row changes which skeletons are possible, settle that rating with the whole team before choosing the set. If no row does, the choice does not depend on the disagreement, and the team can move on.")
    text = "\n".join(L)
    out = os.path.join(os.path.dirname(os.path.abspath(args.file)), "sensitivity.md")
    open(out, "w", encoding="utf-8").write(text)
    print(text); print("\nWrote", out)


def _kmedoids(items, k, seed=7):
    """Small k-medoids on Hamming distance. items: list of combos."""
    rnd = random.Random(seed)
    med = [rnd.randrange(len(items))]
    while len(med) < k:  # farthest-first start
        med.append(max(range(len(items)), key=lambda i: min(dist(items[i], items[j]) for j in med)))
    for _ in range(30):
        groups = collections.defaultdict(list)
        for i, c in enumerate(items):
            groups[min(med, key=lambda j: (dist(c, items[j]), j))].append(i)
        new = [min(g, key=lambda i: sum(dist(items[i], items[j]) for j in g)) for g in groups.values()]
        if sorted(new) == sorted(med):
            break
        med = new
    return [(items[j], [items[i] for i in g]) for j, g in groups.items()]


def cmd_families(args):
    w = load(args.file); m = Model(w); r = analyse(m)
    surv = [c["combo"] for c in r["survivor_list"]]
    L = ["# Families\n", f"{len(surv)} surviving combinations.\n", "## Option 1. Group by two uncertainties\n",
         "| Uncertainties | Families | Empty | Smallest | Largest | Evenness |\n|---|---|---|---|---|---|"]
    import math
    for o in r["axis_options"]:
        sizes = o["sizes"]; tot = sum(sizes) or 1
        ent = -sum((x / tot) * math.log(x / tot) for x in sizes if x) / (math.log(o["families"]) or 1)
        L.append(f"| {m.uname[o['axes'][0]]} and {m.uname[o['axes'][1]]} | {o['families']} | {o['empty_families']} | {min(sizes) if sizes else 0} | {max(sizes) if sizes else 0} | {ent:.2f} |")
    L.append("\nEvenness runs from 0 to 1. A higher value means the survivors are spread more evenly across the families. Choose the two uncertainties where a change of end state changes the story most, and use evenness to break a tie. Set them as `family_axes`.\n")
    if r["families"]:
        a0, a1 = r["family_axes"]
        L.append(f"### Families by {m.uname[a0]} and {m.uname[a1]}\n")
        L.append("| Family | Size | Most central | Most coherent | Most surprising |\n|---|---|---|---|---|")
        for f in r["families"]:
            if f["size"]:
                L.append(f"| {f['n']}. {f['key'][0]} {m.short[f['key'][0]]} with {f['key'][1]} {m.short[f['key'][1]]} | {f['size']} | {'-'.join(f['medoid'])} | {'-'.join(f['most_coherent'])} | {'-'.join(f['most_surprising'])} |")
            else:
                L.append(f"| {f['n']}. {f['key'][0]} {m.short[f['key'][0]]} with {f['key'][1]} {m.short[f['key'][1]]} | 0 | no survivor | | |")
        L.append("")
    if args.cluster:
        k = min(args.cluster, len(surv))
        items = surv if len(surv) <= 1500 else random.Random(3).sample(surv, 1500)
        L.append(f"## Option 2. Group by similarity into {k} clusters\n")
        if len(items) < len(surv):
            L.append(f"Clustered on a sample of {len(items)} of the {len(surv)} survivors.\n")
        L.append("| Cluster | Size | Most central combination | What its members share |\n|---|---|---|---|")
        for n, (med, mem) in enumerate(sorted(_kmedoids(items, k), key=lambda x: -len(x[1])), 1):
            shared = []
            for i, u in enumerate(m.order):
                top, cnt = collections.Counter(c[i] for c in mem).most_common(1)[0]
                if cnt / len(mem) >= 0.75:
                    shared.append(f"{top} {m.short[top]} ({round(100 * cnt / len(mem))}%)")
            L.append(f"| {n} | {len(mem)} | {fmt(m, med)} | {'; '.join(shared) or 'no end state in three quarters or more'} |")
        L.append("\nUse the clusters as a check on option 1. If the clusters are defined by the same two uncertainties as your families, the grouping is sound. If they are defined by others, look at those as family axes.\n")
    text = "\n".join(L)
    out = os.path.join(os.path.dirname(os.path.abspath(args.file)), "families.md")
    open(out, "w", encoding="utf-8").write(text)
    print(text); print("Wrote", out)


def anchor_combo(w, override=None):
    """The one combination the team has agreed must be in the set, or None.
    In the workshop file: "anchor": {"combo": [...], "why": "..."}; a plain list or a candidate id also works."""
    a = override if override else w.get("anchor")
    if not a:
        return None
    if isinstance(a, dict):
        a = a.get("combo") or a.get("id")
    if isinstance(a, str):
        for c in w.get("candidates", []):
            if c.get("id") == a:
                return list(c["combo"])
        return a.replace("+", "-").split("-")
    return list(a)


def score_set(m, w, combos_meta, n_unc, analysis_fams, anchor=None):
    """Check one set of skeletons against the selection criteria. Returns a dict."""
    combos = [c["combo"] for c in combos_meta]
    all_states = set(e for u in m.order for e in m.states[u])
    used = set(e for c in combos for e in c)
    ds = [dist(a, b) for a, b in itertools.combinations(combos, 2)] or [0]
    edges = w.get("edges", {}) or {}
    anc = anchor if anchor is not None else anchor_combo(w)
    axes = w.get("family_axes")
    fam_keys = []
    if axes:
        i1, i2 = m.order.index(axes[0]), m.order.index(axes[1])
        fam_keys = [(c[i1], c[i2]) for c in combos]
    t_counts = [sum(1 for a, b in itertools.combinations(c, 2) if m.rating(a, b) == "T") for c in combos]
    any_x = any(m.rating(a, b) == "X" for c in combos for a, b in itertools.combinations(c, 2))
    any_q = any(m.rating(a, b) == "Q" for c in combos for a, b in itertools.combinations(c, 2))
    qs = [q["id"] for q in w.get("topic_questions", [])]
    central = set()
    for c in combos_meta:
        central |= set(c.get("central", []))
    res = {
        "combos": combos, "ids": [c.get("id", "") for c in combos_meta],
        "c2_anchor_in": (anc in combos) if anc else None,
        "marked_edges_in": {k: (v in combos) for k, v in edges.items() if v},
        "c3_one_per_family": (len(set(fam_keys)) == len(fam_keys)) if fam_keys else None,
        "c4_all_end_states_used": used == all_states, "end_states_left_out": sorted(all_states - used),
        "c5_min_difference": min(ds), "c5_sum_difference": sum(ds), "c5_mean_difference": round(sum(ds) / len(ds), 2),
        "c6_unusual_pairings": sum(t_counts), "c6_has_unusual": any(t_counts),
        "c7_questions_central": sorted(central & set(qs)) if qs else None,
        "c7_all_questions_central": (set(qs) <= central) if qs else None,
        "c8_possible": not any_x and not any_q,
    }
    use = collections.Counter(e for c in combos for e in c)
    top_e, top_n = use.most_common(1)[0]
    res["most_used_end_state"] = [top_e, top_n]
    res["balanced"] = top_n <= (len(combos) + 1) // 2
    majority = n_unc // 2 + 1
    passes = [res["c8_possible"], res["c4_all_end_states_used"], res["c5_min_difference"] >= majority, res["c6_has_unusual"]]
    for k in ("c2_anchor_in", "c3_one_per_family", "c7_all_questions_central"):
        if res[k] is not None:
            passes.append(res[k])
    res["criteria_met"] = sum(1 for p in passes if p)
    res["criteria_checked"] = len(passes)
    return res



def cmd_whole(args):
    """Lay out candidates in full so the team can read each as a whole."""
    w = load(args.file); m = Model(w)
    by_id = {c["id"]: c for c in w.get("candidates", []) if c.get("id")}
    items = []
    if args.set:
        for tok in [t.strip() for t in args.set.split(",") if t.strip()]:
            items.append(by_id[tok] if tok in by_id else {"id": "", "title": "", "combo": tok.replace("+", "-").split("-")})
    else:
        items = w.get("candidates", [])
    L = ["# Reading each combination as a whole\n",
         "Pair ratings can miss a clash between three or more end states. For each combination below, read all its end states together and ask: could one country be all of this at once, in the target year? If three or more of them cannot all be true, add the combination to `excluded_combos` in the workshop file with the reason, and run analyse again.\n"]
    for c in items:
        combo = c["combo"]
        L.append(f"## {c.get('id', '')} {c.get('title', '')}".rstrip() + "\n")
        for e in combo:
            d = next((s.get("description", "") for u in w["uncertainties"] for s in u["end_states"] if s["code"] == e), "")
            L.append(f"- **{e} {m.name[e]}.** {d}")
        L.append("\n| Pair | Rating | Reason or story |\n|---|---|---|")
        for a, b in itertools.combinations(combo, 2):
            i = m.pairinfo.get(frozenset((a, b)), {})
            L.append(f"| {a} with {b} | {m.rating(a, b)} | {i.get('story') or i.get('reason') or ''} |")
        L.append("")
    text = "\n".join(L)
    out = os.path.join(os.path.dirname(os.path.abspath(args.file)), "whole-combinations.md")
    open(out, "w", encoding="utf-8").write(text)
    print(text); print("Wrote", out)


def max_mean_difference(m, n):
    """The highest mean number of differences any set of n combinations could have, given how many end states each uncertainty has."""
    pairs = n * (n - 1) // 2
    total = 0.0
    for u in m.order:
        k = len(m.states[u]); q, rem = divmod(n, k)
        same = rem * (q + 1) * q // 2 + (k - rem) * q * (q - 1) // 2
        total += 1 - same / pairs
    return round(total, 2)


def best_min_difference(survivors, n, limit=1200000):
    """The largest value the smallest pairwise difference can take for any set of n survivors. Returns (value, exact)."""
    k = len(survivors)
    if k < n:
        return 0, True
    d = [[dist(a, b) for b in survivors] for a in survivors]
    total = 1
    for i in range(n):
        total = total * (k - i) // (i + 1)
    if total <= limit:
        best = 0
        for idx in itertools.combinations(range(k), n):
            mn = min(d[i][j] for i, j in itertools.combinations(idx, 2))
            if mn > best:
                best = mn
        return best, True
    best = 0
    rnd = random.Random(9)
    for _ in range(300):  # farthest-first from random starts: at least half the true best when it finds a set
        cur = [rnd.randrange(k)]
        while len(cur) < n:
            cur.append(max(range(k), key=lambda i: (min(d[i][j] for j in cur), rnd.random())))
        best = max(best, min(d[i][j] for i, j in itertools.combinations(cur, 2)))
    return best, False


def _tcount(m, combo):
    return sum(1 for a, b in itertools.combinations(combo, 2) if m.rating(a, b) == "T")


def cmd_sets(args):
    w = load(args.file)
    m = Model(w)
    n = args.n or w.get("workshop", {}).get("tables") or 4
    r = analyse(m)
    by_id = {c["id"]: c for c in w.get("candidates", []) if c.get("id")}
    if args.pool == "candidates" and w.get("candidates"):
        pool = [dict(c) for c in w["candidates"]]
    else:
        pool = [{"id": "", "combo": c["combo"]} for c in r["survivor_list"]]
    pool = [c for c in pool if not any(m.rating(a, b) == "X" for a, b in itertools.combinations(c["combo"], 2))]
    anc = anchor_combo(w, getattr(args, "anchor", None))
    if anc and (len(anc) != len(m.order) or any(c not in m.owner for c in anc)):
        print(f"Could not read the anchor {anc}. Use a candidate id, or codes joined with hyphens in the order {'-'.join(m.order)}."); return 1
    if anc and any(m.rating(a, b) == "X" for a, b in itertools.combinations(anc, 2)):
        print("The anchor contains a pair rated X, so it is not possible. Choose another anchor."); return 1
    must = [anc] if anc else []
    if args.max_unusual is not None:
        pool = [c for c in pool if _tcount(m, c["combo"]) <= args.max_unusual or c["combo"] in must]
    best_possible = max_mean_difference(m, n)
    surv_all = [c["combo"] for c in r["survivor_list"]]
    best_min, best_min_exact = best_min_difference(surv_all, n)
    most_states = max(len(m.states[u]) for u in m.order)

    def show(s):
        label = ", ".join(i or "-".join(c) for i, c in zip(s["ids"], s["combos"]))
        print(f"\n{label}   [{s['criteria_met']} of {s['criteria_checked']} criteria]")
        for c in s["combos"]:
            print(f"    {fmt(m, c)}   (unusual pairings: {_tcount(m, c)})")
        print(f"    anchor in the set: {s['c2_anchor_in'] if s['c2_anchor_in'] is not None else 'no anchor chosen'} | one per family: {s['c3_one_per_family']} | all end states used: {s['c4_all_end_states_used']}"
              + (f" (left out: {', '.join(s['end_states_left_out'])})" if s["end_states_left_out"] else ""))
        if s.get("marked_edges_in"):
            print("    for information, marked edges in the set: " + ", ".join(f"{k} {'yes' if v else 'no'}" for k, v in s["marked_edges_in"].items()))
        print(f"    differences between pairs: smallest {s['c5_min_difference']} of {len(m.order)}, mean {s['c5_mean_difference']} (the most any set of {len(s['combos'])} could reach is {max_mean_difference(m, len(s['combos']))})")
        if len(s["combos"]) == n and best_min:
            print(f"    diversity: smallest difference {s['c5_min_difference']} against a best achievable {best_min}{'' if best_min_exact else ' (estimate)'} for {n} survivors = {s['c5_min_difference'] / best_min:.2f}")
        me, mn_ = s["most_used_end_state"]
        print(f"    balance: the most used end state is {me} {m.short[me]}, in {mn_} of {len(s['combos'])} skeletons" + ("" if s["balanced"] else "  <- more than half: consider swapping one skeleton"))
        print(f"    unusual pairings in the set: {s['c6_unusual_pairings']} | questions central: {s['c7_questions_central']} | all possible: {s['c8_possible']}")

    def benchmark(s):
        surv = [c["combo"] for c in r["survivor_list"]]
        k = len(s["combos"])
        if len(surv) < k:
            return
        rnd = random.Random(11); trials = 20000; hit = 0
        allst = set(e for u in m.order for e in m.states[u])
        for _ in range(trials):
            pick = rnd.sample(surv, k)
            ds = [dist(a, b) for a, b in itertools.combinations(pick, 2)]
            if sum(ds) / len(ds) >= s["c5_mean_difference"] - 1e-9 and (not s["c4_all_end_states_used"] or set(e for c in pick for e in c) == allst):
                hit += 1
        pct = 100 * hit / trials
        print(f"    for comparison: {pct:.2f} per cent of {trials} random sets of {k} from the {len(surv)} survivors are as different from each other"
              + (" and also use every end state" if s["c4_all_end_states_used"] else ""))

    if args.set:
        chosen = []
        for tok in [t.strip() for t in args.set.split(",") if t.strip()]:
            if tok in by_id:
                chosen.append(dict(by_id[tok]))
            else:
                combo = tok.replace("+", "-").split("-")
                if len(combo) != len(m.order) or any(c not in m.owner for c in combo):
                    print(f"Could not read '{tok}'. Use a candidate id, or codes joined with hyphens in the order {'-'.join(m.order)}."); return 1
                chosen.append({"id": "", "combo": combo})
        s = score_set(m, w, chosen, len(m.order), r["families"], anc)
        print("Checking the set you gave:"); show(s); benchmark(s)
        return 0

    fixed = [c for c in pool if c["combo"] in must]
    rest = [c for c in pool if c["combo"] not in must]
    for e in must:
        if e not in [c["combo"] for c in fixed]:
            fixed.append({"id": "", "combo": e})
    k = n - len(fixed)
    if k < 0:
        fixed, rest, k = [], pool, n
    total_sets = 1
    for i in range(k):
        total_sets = total_sets * (len(rest) - i) // (i + 1)
    scored = []
    exhaustive = total_sets <= 400000
    if exhaustive:
        for extra in itertools.combinations(rest, k):
            scored.append(score_set(m, w, fixed + list(extra), len(m.order), r["families"], anc))
    else:
        # too many to try them all: build sets one skeleton at a time, always adding the one that keeps the set most spread out
        rnd = random.Random(5)
        for start in range(200):
            cur = list(fixed); avail = rest[:]; rnd.shuffle(avail)
            if not cur:
                cur.append(avail.pop())
            while len(cur) < n and avail:
                used = set(e for c in cur for e in c["combo"])
                nxt = max(avail, key=lambda c: (min(dist(c["combo"], o["combo"]) for o in cur), len(set(c["combo"]) - used), rnd.random()))
                cur.append(nxt); avail.remove(nxt)
            scored.append(score_set(m, w, cur, len(m.order), r["families"], anc))
    key = lambda s: (-s["criteria_met"], -s["c5_min_difference"], -s["c5_sum_difference"], -s["c6_unusual_pairings"])
    seen = set(); uniq = []
    for s in sorted(scored, key=key):
        sig = tuple(sorted("-".join(c) for c in s["combos"]))
        if sig not in seen:
            seen.add(sig); uniq.append(s)
    full = [s for s in uniq if s["criteria_met"] == s["criteria_checked"]]
    print(f"Pool: {len(pool)} combinations" + (f" with at most {args.max_unusual} unusual pairings" if args.max_unusual is not None else "") + "." + (f" Anchor: {fmt(m, anc)}. It is in every set, and the others are chosen from there." if anc else " No anchor is chosen yet. Agree with the team the one combination the set must contain, and set `anchor` in the workshop file or pass --anchor."))
    if anc:
        start = next((c for c in pool if c["combo"] == anc), {"id": "", "combo": anc})
        cur = [start]; avail = [c for c in pool if c["combo"] != anc]
        while len(cur) < n and avail:
            used = set(e for c in cur for e in c["combo"]); cen = set(q for c in cur for q in c.get("central", []))
            nxt = max(avail, key=lambda c: (min(dist(c["combo"], o["combo"]) for o in cur), len(set(c["combo"]) - used), len(set(c.get("central", [])) - cen)))
            cur.append(nxt); avail.remove(nxt)
        grown = ", ".join(c.get("id") or "-".join(c["combo"]) for c in cur)
        same = uniq and sorted("-".join(c["combo"]) for c in cur) == sorted("-".join(c) for c in uniq[0]["combos"])
        print(f"Grown from the anchor, adding each time the combination farthest from those already chosen: {grown}" + (" (the same as the top set below)" if same else " (compare with the ranked sets below)"))
    print(f"Sets of {n} looked at: {len(uniq)}" + ("" if exhaustive else f" (of {total_sets} possible: too many to try them all, so sets were built step by step for spread, and a better set may exist)"))
    print(f"Sets meeting every criterion that could be checked: {len(full)}. The most any set of {n} could differ, on average, is {best_possible} of {len(m.order)} uncertainties.")
    if n < most_states:
        print(f"Note: one uncertainty has {most_states} end states and there are {n} skeletons, so no set can use every end state. Criterion 4 cannot be met in full. Say which end states are left out and why.")
    for s in uniq[: args.top]:
        show(s)
    if uniq:
        benchmark(uniq[0])
    out = os.path.join(os.path.dirname(os.path.abspath(args.file)), "sets.json")
    save(out, {"n": n, "looked_at": len(uniq), "exhaustive": exhaustive, "meeting_all": len(full), "max_mean_difference": best_possible, "top": uniq[: args.top]})
    print("\nWrote", out)


def cmd_twoaxis(args):
    w = load(args.file)
    m = Model(w)
    a, b = args.a, args.b
    for x in (a, b):
        if x not in m.order:
            print(f"{x} is not an uncertainty code. Codes: {', '.join(m.order)}")
            return 1
    sa, sb = m.states[a], m.states[b]
    if len(sa) != 2 or len(sb) != 2:
        print("The two-axis method uses two opposite end states for each uncertainty.")
        print(f"{a} has {len(sa)} and {b} has {len(sb)}. Using the first and last of each as the two poles.")
    pa, pb = [sa[0], sa[-1]], [sb[0], sb[-1]]
    print(f"Axes: {m.uname[a]} and {m.uname[b]}\n")
    for i, (x, y) in enumerate(itertools.product(pa, pb), 1):
        r = m.rating(x, y)
        flag = "  <- rated X: this corner contradicts itself, so reword an end state or choose other axes" if r == "X" else ""
        print(f"Scenario {i}: {x} {m.name[x]}  +  {y} {m.name[y]}{flag}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("couplings", "template", "check"):
        p = sub.add_parser(name); p.add_argument("file")
    p = sub.add_parser("pairs-export"); p.add_argument("file"); p.add_argument("csv", nargs="?")
    p = sub.add_parser("pairs-import"); p.add_argument("file"); p.add_argument("csv")
    p = sub.add_parser("analyse"); p.add_argument("file"); p.add_argument("--out")
    p = sub.add_parser("sensitivity"); p.add_argument("file"); p.add_argument("--all-x", action="store_true")
    p = sub.add_parser("families"); p.add_argument("file"); p.add_argument("--cluster", type=int)
    p = sub.add_parser("whole"); p.add_argument("file"); p.add_argument("--set")
    p = sub.add_parser("sets"); p.add_argument("file"); p.add_argument("--n", type=int)
    p.add_argument("--pool", choices=["candidates", "survivors"], default="candidates"); p.add_argument("--top", type=int, default=5)
    p.add_argument("--max-unusual", type=int); p.add_argument("--set"); p.add_argument("--anchor")
    p = sub.add_parser("twoaxis"); p.add_argument("file"); p.add_argument("a"); p.add_argument("b")
    args = ap.parse_args()
    cmds = {"couplings": cmd_couplings, "template": cmd_template, "pairs-export": cmd_pairs_export, "pairs-import": cmd_pairs_import, "check": cmd_check,
            "analyse": cmd_analyse, "whole": cmd_whole, "sensitivity": cmd_sensitivity, "families": cmd_families, "sets": cmd_sets, "twoaxis": cmd_twoaxis}
    return cmds[args.cmd](args) or 0


if __name__ == "__main__":
    sys.exit(main())
