# Where this method comes from

The workshop uses a light version of methods that have a long record in futures research. This note says what they are, where to read more, and how the workshop version relates to them. Use it to answer "why do we do it this way?" and to go deeper when a team is ready.

## Morphological analysis and the compatibility matrix

Morphological analysis was developed by Fritz Zwicky and extended for policy and futures work by Tom Ritchey as General Morphological Analysis. A problem is described by a small number of parameters, each with a few possible states. Every combination of one state per parameter is a possible configuration. The team then compares every pair of states and removes the configurations that contain a contradictory pair. Ritchey calls this step the cross-consistency assessment. It is the same step as the compatibility matrix in this workshop.

Three points from that literature shape this skill:

- **There are three kinds of reason for ruling a pair out.** A logical contradiction lies in the wording of the two states. An empirical constraint means the pair is judged highly improbable or implausible in the real world. A normative constraint means people do not want it. Ritchey advises using normative constraints with great care. In this workshop only the first two count. A pairing the team dislikes stays possible.
- **The assessment also tests the end states.** If a team cannot judge a pair, the end states are usually unclear or overlapping, and should be rewritten.
- **Most of a field is usually removed.** In expert studies with many parameters, reductions of 90 per cent or more are common. A workshop field is smaller and its end states are written by tables in 40 minutes, so less is removed.

Read more: Ritchey, "General Morphological Analysis: An overview" (2022), https://philarchive.org/archive/RITGMA. Ritchey, "Principles of Cross-Consistency Assessment in General Morphological Modelling" (2015), https://www.swemorph.com/pdf/amg-4-2-2015.pdf.

## Consistency analysis and cross-impact balance

In formative scenario analysis, experts rate the consistency of every pair of factor levels on a number scale, and scenarios are then chosen for being both consistent and different from each other (Tietje 2005, European Journal of Operational Research 162(2), 418 to 432). Cross-impact balance analysis, developed by Wolfgang Weimer-Jehle, goes further. The team judges how each state pushes each other state, with a direction and a strength, and a calculation finds the combinations that hold together. It carries more information than a compatibility matrix and takes much longer.

The workshop uses five letters in place of a number scale because a facilitation team has one afternoon, and because letters with a written reason are easier to discuss and to explain to a room the next morning. If a team later wants more depth for a written scenario study, cross-impact balance is the natural next step. Read more: Schweizer (2020), "Reflections on cross-impact balances", Climatic Change, https://link.springer.com/article/10.1007/s10584-019-02615-2.

## Choosing a small, diverse set

A morphological field leaves tens, hundreds or thousands of possible combinations, and a workshop can build four to six. The research on how to choose them agrees on the main points.

- **Lord, Helfgott and Vervoort (2016)**, "Choosing diverse sets of plausible scenarios in multidimensional exploratory futures techniques", Futures 77, 11 to 27. Ariella Helfgott of SA Futures Agency is one of its authors, and the selection step in this skill follows it. The paper's main points: compatibility is used as a pass mark and not to rank the survivors; the diversity of a set is its smallest difference between any two scenarios, divided by the best that could be achieved; the search is repeated under many different ways of measuring difference, so the result holds up when people frame the factors differently; and the tool returns several good sets, so that people make the last choice on which set tells the better group of stories. It was built as software and used in the CGIAR regional scenarios. Open manuscript: https://ora.ox.ac.uk/objects/uuid:92cfd242-2f28-416b-bfd7-4f7f7ec63b6c/files/m10f0c4aa41b429846d8ce178d3af8d2f
- **Carlsen, Eriksson, Dreborg, Johansson and Bodin (2016)**, "Systematic exploration of scenario spaces", Foresight 18(1), 59 to 75. Names two common faults in scenario sets: every scenario sits close to business as usual, or the set mixes cautious and extreme scenarios without balance. Proposes choosing sets that are as different as they can be, scored on the smallest and the mean difference between scenarios. A later audit by the same group found that a widely used set of global scenarios reached about half of the difference it could have had. https://www.doi.org/10.1108/FS-02-2015-0011
- **Seeve and Vilkkumaa (2022)**, "Identifying and visualizing a diverse set of plausible scenarios for strategic planning", European Journal of Operational Research 298(2). Chooses the most consistent combinations that together cover every level of every factor. This is the reason for the criterion that every end state is used at least once.
- **Carlsen, Lempert, Wikman-Svahn and Schweizer (2016)**, "Choosing small sets of policy-relevant scenarios by combining vulnerability and diversity approaches". Argues that difference alone is not enough: the set should also include the futures that matter most for the decision at hand. In this workshop that is the job of the topic questions.

## Field anomaly relaxation, and reading combinations whole

Russell Rhyne's field anomaly relaxation uses two filters. The first is a lenient test of each pair: can we think of any pattern in which these two could exist together? It asks about possibility and not about likelihood. The second is a judgement of each whole combination, because three or more states can clash as a group although every pair passes. This workshop borrows both ideas: the lenient standard for an X, and the reading of every candidate as a whole.

## The CGIAR regional scenarios

The workshop format descends from the regional scenarios program of the CGIAR research program on Climate Change, Agriculture and Food Security, where Ariella Helfgott, Joost Vervoort and colleagues developed it with partners in East and West Africa, South and Southeast Asia and Latin America. Groups of people from government, research, business and civil society chose their own factors by voting on what was most uncertain and most relevant, wrote states for each factor that were plausible, mutually exclusive and far apart, and built scenarios from combinations of states. The program moved from two axes to four to six factors so that more of what people cared about could stay in the scenarios. Read more: Vervoort and colleagues (2014), "Challenges to scenario-guided adaptive action on food security under climate change", Global Environmental Change, https://hdl.handle.net/2440/94563. Mason-D'Croz and colleagues (2016), on the Southeast Asia scenarios, https://core.ac.uk/download/83641389.pdf.

## How the workshop version relates

| In the literature | In this workshop |
|---|---|
| Parameters and states | Critical uncertainties and end states, chosen and written by the room |
| Cross-consistency assessment, consistency matrix | The compatibility matrix: every pair rated S, I, T, X or Q with a reason |
| Removing contradictory configurations | The morphological analysis: every combination with an X pair is removed |
| Judging whole configurations | Reading every candidate as a whole |
| Clustering, scenario maps | Families: survivors grouped by the two uncertainties that change the story most, checked by similarity |
| Maximising diversity, covering every level, decision relevance | The eight selection criteria |

Two things are particular to this practice. Unusual pairings (T) are kept and valued, because in a room of participants they are what moves a set beyond a best case and a worst case. And the set is built from one anchor: a combination the team agrees must be in the set, with the others chosen for their difference from it and from each other. This follows the initial scenario in Lord, Helfgott and Vervoort (2016).
