# The two-axis method

Also called the deductive method or the 2 × 2. Use it when the team cannot do the full analysis between two days: a one-day workshop, a first introduction, or a team with nobody who has done the full method.

## How it works

1. From the word cloud, choose the two critical uncertainties that are most important and most uncertain, and that are independent of each other.
2. Give each one two opposite end states, the two ends of an axis. For example: "Policy is steady" and "Priorities keep changing".
3. Cross them. The four corners are four scenarios.
4. Check each corner: can both end states be true together? If a corner contradicts itself, the axes are not independent. Choose another pair.
5. Give each corner a working title and to a table.

`python scripts/morph.py twoaxis FILE A B` prints the four corners for uncertainties A and B and flags any corner rated X.

## What it keeps and what it loses

| | Two-axis method | Morphological analysis |
|---|---|---|
| Time for the team | 30 minutes | Four to six hours |
| Uncertainties used | 2 | 4 to 6 |
| End states for each | 2 | 2 to 4 |
| Scenarios | Always 4 | One for each table |
| Unusual combinations | Rare. Two of the four corners are usually a best and a worst case. | Found on purpose |
| Every table's work used | No. Most uncertainties are dropped. | Yes |
| Easy to explain | Very | Needs the recap slides |

## Making the most of it

- Work the other uncertainties from the word cloud into every scenario as things that are true in all four, or let each table decide how they turn out.
- Choose axes whose corners are all interesting. If one corner is "everything is good" and its opposite is "everything is bad", try a different pair.
- The rest of the workshop is unchanged: scenario building with the eight prompts, report-back, insights, visioning, shared harvest.
