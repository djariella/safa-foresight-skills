# Reading the results

## The size of the field

The number of combinations is the number of end states of each uncertainty multiplied together. Four uncertainties with 3, 3, 4 and 3 end states give 3 × 3 × 4 × 3 = 108.

| Uncertainties | End states each | Pairs to rate | Combinations |
|---|---|---|---|
| 3 | 3 | 27 | 27 |
| 4 | 3 | 54 | 81 |
| 4 | 3 or 4 | 63 | 108 |
| 5 | 3 | 90 | 243 |
| 6 | 3 | 135 | 729 |
| 8 | 3 or 4 | 250 to 450 | 6,500 to 65,000 |

For a workshop with one afternoon between the days, four to six uncertainties with two to four end states each is the working range. SA Futures Agency's own desk studies go up to eight uncertainties, and then use the couplings step in the compatibility-matrix skill to keep the rating manageable.

## Guide values

These come from practice. They are not rules.

| What you see | What it suggests | What to do |
|---|---|---|
| Between a quarter and two thirds of combinations removed | A healthy field | Carry on |
| Less than a quarter removed, or nothing | Ratings may be too generous, or the uncertainties really are independent | Re-read the pairs rated T: is any a real contradiction? If not, the result is honest. Selection matters more when little is removed. |
| More than two thirds removed | Ratings may be too strict, or two uncertainties are really one | Test each X: as written, impossible or only unlikely, within the horizon? Consider merging overlapping uncertainties. |
| One X removes a quarter of the field or more | That rating carries a lot of weight | Make sure the whole team agrees with it. Run the sensitivity check on it. |
| An end state appears in no survivor | Its ratings shut it out | Tell the table facilitator. Either a rating is wrong or the end state contradicts the rest of the room's picture, which is worth saying on day 2. |
| No survivor has every pair supporting | There is no "expected" future in the field | Unusual, and fine. Check the S ratings were not all given as I. |
| Every survivor has every pair supporting or independent | No unusual pairings | The skeletons will be a best case and a worst case. Look again for T pairs. |

Expert studies in the literature often remove 90 to 99 per cent of a field, though published examples range down to about 70 per cent. Those studies have more parameters, and states written by analysts to be sharply distinct. A workshop field is smaller and written by tables in 40 minutes, so less is removed. Between a quarter and two thirds is a good result.

One caution from the research applies to every field. Removing a whole combination because of one pair is a strong rule, and some authors criticise it (Seeve and Vilkkumaa 2022). That is the reason to use X sparingly, to write the reason for every X, and to run the sensitivity check.

## The patterns

`analysis.md` lists two kinds of pattern. Say both aloud to the team.

- **Compatible with everything.** An end state with no X against it can appear in any kind of future.
- **Never together.** Pairs that never share a survivor. Most are the X pairs themselves. Some are pairs that were not rated X and still never meet, because every combination that would join them is blocked by something else. Those are worth a sentence on day 2.

## The sensitivity check

Ratings are judgements, and teams disagree. The sensitivity check turns a disagreement into a practical question: does it change what we can choose?

When a team has debated a few pairs, the check often shows that reversing any one of them changes the number of survivors a little and leaves every chosen skeleton possible. The choice did not depend on those debates, and the team can say so in the write-up.

If a reversal does remove a skeleton the team wants, there are three honest options: settle the rating with the whole team, choose a different skeleton from the same family, or keep the skeleton and tell the room which pairing in it the team was unsure about.

## What to say on day 2

One slide with the numbers, and three or four patterns in plain words. People do not need the arithmetic. They need to see that the skeletons are made from their own end states, and that the combinations that were left out were left out for a reason they can follow.

## Going deeper than a compatibility matrix

For a written study with more time, cross-impact balance analysis asks how each end state pushes each other one, with a direction and a strength, and computes which combinations hold together. It records causes as well as fit, and it catches some indirect effects that a matrix of pairs misses. It needs about twice as many judgements and is harder for participants to follow. Free software exists for it (ScenarioWizard, at cross-impact.org). For a workshop with one afternoon, the compatibility matrix is the right tool.
