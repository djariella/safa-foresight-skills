---
name: morphological-analysis
description: Run the morphological analysis on rated scenario end states. Builds every combination, removes the impossible ones, reports the patterns and tests contested ratings. Step 2 of 4.
---

# Morphological analysis

This is the second of four skills that take a facilitation team from end states to scenario skeletons: compatibility-matrix, then **morphological-analysis**, then scenario-families, then scenario-set-selection. It was developed by Ariella Helfgott and SA Futures Agency.

A scenario is one end state from each uncertainty, taken together. Morphological analysis builds every such combination, removes every combination that contains a pair rated X, and describes what is left. It is also called multi-factor, multi-state scenario building. The arithmetic is simple. The value is in reading the result with the team: what survived, what never appears together, and whether the result can be trusted.

## What you need

The workshop file with every pair rated (`references/workshop-file.md`). If `python scripts/morph.py check FILE` does not say READY FOR ANALYSIS, go back to the compatibility-matrix skill.

## Steps

### 1. Run it

```
python scripts/morph.py analyse FILE
python scripts/review_pack.py FILE
```

`analyse` writes `analysis.json` and `analysis.md`. `review_pack.py` refreshes the team's review page with the results.

### 2. Tell the team what it shows

Read `analysis.md` and say, in plain words and in this order:

1. **The numbers.** How many combinations were possible, how many were removed, how many survive, and how many have every pair supporting each other.
2. **What each X did.** Each X removes every combination that contains that pair. Say how many each one removed. One X that removes a quarter of the field deserves a second look.
3. **The patterns.** Which end states are compatible with everything, and which never appear together. Say these aloud. They are findings about the system, and participants find them interesting on day 2.
4. **The unusual pairings.** How many survivors contain none, one, two or more. The survivors with none are the easiest to believe. The ones with some are where the less expected scenarios come from.
5. **Anything that looks wrong.** An end state that appears in no survivor. A field where nothing was removed. A field where almost everything was.

`references/reading-the-results.md` has guide values and what to do about each problem.

### 3. Test the contested ratings

```
python scripts/morph.py sensitivity FILE
```

For every pair marked contested or still Q, this shows what would change if the rating went the other way: how many combinations survive, and whether any candidate or chosen skeleton would stop being possible. Add `--all-x` to test every X.

Tell the team which disagreements matter and which do not. If flipping a rating changes nothing about the candidates, the team does not need to settle it. If it removes a skeleton the team likes, that pair needs the whole team's attention before going further.

### 4. Know what the pair check cannot see

The analysis checks two end states at a time. Three or more can clash as a group although every pair is possible. The remedy is to read the shortlisted combinations as wholes, which the scenario-families skill does with `python scripts/morph.py whole FILE`. If the team strikes a combination for that reason, add it to `excluded_combos` in the workshop file with the reason and run `analyse` again.

### 5. Record the result

Keep `analysis.md` and `sensitivity.md` with the workshop file. The numbers go on the recap slide on day 2 and into the write-up.

## If there is no time for the full method

`references/two-axis-method.md` describes the shorter deductive method: two uncertainties, two end states each, four scenarios. `python scripts/morph.py twoaxis FILE A B` lists the four corners and flags any that contradict themselves. Say clearly what is lost by using it.

## Check the program

`assets/example/example.workshop.json` is a made-up workshop file with placeholder wording. It should give 63 pairs, 108 combinations, 40 removed, 68 surviving and 5 with every pair supporting. Run it if a result ever looks wrong.

## Next

Hand over to the **scenario-families** skill.

Follow `references/writing-rules.md`. `references/method-background.md` explains where the method comes from.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
