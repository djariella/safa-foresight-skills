# The workshop write-up

## Structure

1. **Summary.** One page: what the workshop was, who took part, what it produced, and the three or four things most worth knowing.
2. **What the workshop did.** Purpose, dates, place, hosts, the number and mix of participants, and the method in one paragraph with a simple diagram of the steps.
3. **What is changing.** The main themes from horizon scanning under STEEP + V, drawn from the post-its and table recordings.
4. **Critical uncertainties and end states.** The Menti word cloud for question 1, the groups and their counts, and each uncertainty with its end states as the tables wrote them.
5. **From end states to skeletons.** A short account with the numbers: pairs rated, the pairs that cannot both be true and why, combinations and survivors, families, candidates, the criteria and the chosen set. The full matrix goes in an appendix.
6. **The scenarios.** One section for each, in the same structure (below). Open the section with a short statement of what scenarios are for: they describe futures that could happen, they are written to test ideas and plans, they are not forecasts, plans or recommendations, and they do not comment on any government, organisation or person. They are vivid on purpose. Hosts often worry that a hard scenario will be read as criticism, and this statement is what lets the report keep what the tables said.
7. **Insights across the scenarios.** What appears in every scenario, what changes most between them, and what the room said it would do differently today.
8. **The shared vision.** The themes in the room's own words, with the elements under each, the word cloud for Menti question 2, and how the vision does against the program's checks.
9. **First priorities and partnerships.** By table, as written: priority opportunities, enabling conditions, partnerships. Marked as a first list.
10. **What participants said they will do.** Menti question 3.
11. **Next steps.**
12. **Appendices.** Participants by sector, the run sheet, the full matrix and ratings with reasons, the fact base references, photographs of the flipcharts and the vision table.

## The structure of each scenario

Use exactly the same headings for every scenario.

| Heading | Content |
|---|---|
| Name | The table's name, with the skeleton's working title beside it, and the newspaper headline |
| The skeleton | The end states, and one paragraph on how they fit together |
| The scenario in the target year | One to two pages of narrative built from the table's flipchart and recording, under the eight prompts on placemat 2: the four main parts of the system, then markets and money, daily life, decisions and nature |
| What happens to the topic | What the table worked out about the workshop's topic in this scenario |
| How we got here | The three or more events the table named, in order |
| Who gains and who loses | As the table saw it |
| What the room said | Whether the room thought it could happen, and the questions it raised |
| Signals in the present | Things already happening that could grow into this scenario, each with its source. A reader who doubts the scenario can check them. Draft the list from the fact base, then ask the people who live and work in the country to add to it. They will know signals that no desk review finds |

## Writing the narratives

- Present tense, in the target year.
- Built from what the table said. Where the table was silent on a prompt, say so. Do not fill the gap.
- Each scenario keeps its own voice and details. Do not make them read the same.
- Every scenario has things that work and things that are hard, and gains that reach everyone as well as gains that reach a few.
- Keep the scenarios apart. A table often carries its fears from another scenario into its own, so the same problem turns up in several. Give each problem to the scenario it belongs to, and say in a note what was moved.
- Check the technical claims a table makes with someone who knows the subject, and mark what is unchecked.
- No closing summary paragraph, no "imagine", no invented people.
- Present-day facts only from the fact base, each with its source.

## If the team wants to add something

Sometimes the team sees that a scenario was softened at the table, or that the set is missing a future the organisation needs to face. Keep the room's scenarios as they were built. Put the team's additions in a separate section or paper, titled as the facilitation team's own, for discussion with the hosts.

## Checks before sending

- Every participant quote is word for word and not attributed by name without agreement.
- Every number about the present has a source.
- Scenario names, end state names and vision themes match the flipcharts and the workshop file.
- Nothing in the report grades or criticises a table.
- The hosts' logos and the SA Futures Agency credit are on the cover.

## Testing the vision and the priorities

Two checks from the research make this part of the report stronger.

- **Where do the vision's themes pull against each other?** Studies of visioning find that visions made quickly are weakest on coherence and trade-offs (Wiek and Iwaniec 2014 list ten quality criteria: visionary, sustainable, systemic, coherent, plausible, tangible, relevant, nuanced, motivational and shared). If the room named tensions, report them. If it did not, say which themes the facilitation team thinks need that conversation, in the team's own section.
- **Which priorities hold up in every scenario?** Sort each table's priority opportunities into three groups using what the tables said: works in every scenario, works in some, works in none. Add a short list of indicators to track each year that would show which scenario is unfolding. Keep these apart from the signals in the present. A signal is something a reader can check today. An indicator is a measure to follow over the years, and often nobody collects it yet.

Label this part of the report honestly. The priorities session comes last, when people are tired, and what it produces is usually thinner than the scenario discussions, so draw the actions from the scenarios as well. If the room did not work backwards from the vision to a pathway, do not write one into the report as if it had. A workshop of this length produces first priorities and the conditions they need. A roadmap with owners and dates takes at least another half day with the people who have the power to act.

## Returning the results

Send participants a short summary within days, with photographs of the flipcharts and the vision table, and ask them to correct anything that was recorded wrongly. Send the full write-up when it is ready. Document the method in the report, including how the skeletons were chosen.

## Using Claude and other AI tools responsibly

- **Say that AI was used**, and for what, in the method section of the report.
- **People decide.** The team checks every draft against the flipcharts and recordings and signs off the report.
- **Keep participants' words.** AI tools tend to replace a participant's exact word with a more general one, and scenario drafts written by AI tend to read alike. Compare theme names, scenario names and quotes with the photographs, word by word.
- **Facts come from the fact base.** Anything else is marked for checking.
- **Protect the recordings.** Recordings and transcripts hold what people said in confidence. Keep them with the facilitation team under your organisation's data rules, and do not pass them on with the report.
