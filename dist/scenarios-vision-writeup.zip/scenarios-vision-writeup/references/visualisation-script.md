# The guided visualisation script

## What it is for

It moves the room from analysing futures to picturing the one it wants. Each person builds their own picture in silence before any discussion, so the vision that follows comes from everyone and not from the first people to speak.

## Shape

About eight minutes when read slowly. Ten short sections, each a few sentences of setting followed by one or two questions and a pause.

| Section | What it does |
|---|---|
| Arrive | Settle. "It is a morning in [year]. You are [n] years older. You wake up at home." First sounds, who is there |
| Two or three sections on the main parts of the system | Each says what the room learned and did about that part, then asks what the listener sees |
| Everyone did their part | Who is working together, how decisions are made, who is listened to |
| Shared | Who benefits, and what it has paid for locally |
| Young people | A young person the listener knows. What is their work? What did elders pass on? |
| The hard years | It was not easy. One hard season. What did people do for each other? |
| Your part | Looking back from the target year to this week. "What is one thing you did?" The longest pause |
| Come back | Choose the one picture you most want to be true. Open your eyes. Stay quiet. Write what you saw |

## Rules

- **Use the room's own lessons.** Take them from the morning's report-backs and insights: what each scenario warned about, and what people said they would do to avoid it or reach it. Turn each into a line of the form "We learned ... So we ...".
- **Set the scene and ask. Do not describe the answer.** The script says that water is protected. It asks where the listener's water comes from this morning.
- **Second person, present tense, short sentences.** It will be interpreted.
- **Pauses are part of the script.** Mark each in seconds, between 5 and 20, and tell the reader to count them in full. The longest pause follows "What is one thing you did?"
- **Everyday scale.** Home, a meal, a walk, a place where people work together.
- **Include difficulty.** A good future that had no hard years is not believable.
- **Use local terms the room used**, such as customary practices, with the spelling checked.
- **No facts or figures.** This is not the place for them.
- **Timings in the margin**, so the reader can keep pace.
- **Invite. Do not instruct.** Closing the eyes is a choice. Tell people at the start that they can look at the table if they prefer, and that they can stop at any time. Start from something ordinary and pleasant.
- **A blank is fine.** Say so. If someone sees nothing for a question, that tells them something too.
- **Move outward in layers**: home, daily life, the place around, the people working together, the country. This is the shape of Donella Meadows' envisioning practice, and it suits a room of people from very different places.
- **Brief the interpreter beforehand** and give them the script. The pauses belong to the listeners, so the interpreter finishes each sentence before the count begins.

## A script to adapt

Fill in every part in square brackets from the morning's report-backs. Numbers in square brackets on their own are seconds of silence. Times in round brackets are for the reader's margin.

**Arrive (0:00).** Put your pen down and sit back. Close your eyes if you like, or look at the table. [5] We are going to [year]. I will tell you what we learned and what we did. You decide what it looks like, in your own place, with your own people. [5] It is a morning in [year]. You are [n] years older. You wake up at home, here in [country]. What is the first thing you hear? [10] Who else is there? [8]

**[First part of the system] (1:15).** You [an everyday action that touches this part]. We learned that [a lesson the room drew from the scenarios]. So we [what the room said it would do]. [A question about what the listener sees, in their own place]? [10] Who looks after it? [10]

**[Second part of the system] (2:10).** Now [the next everyday moment]. We learned [lesson]. We [what was done], and we kept what already worked. [Question]? [8] Who made it possible? Who taught them? [8]

**[Third part, or the place around] (3:05).** Walk outside. Look around you. We acted early, before [the harm the scenarios warned about]. What do you see that was not here in [base year]? [12] What is still here because people protected it? [12]

**Everyone did their part (4:00).** Keep walking. You come to a place where people are working together. We learned that no one could do this alone. [One line each on what communities, government, businesses and outside partners did, in the room's words.] Who is here, and what are they doing? [10] How do they decide things? Who is listened to? [10]

**Shared (5:05).** [What the country now earns or gains, in the room's words], and the benefit does not stay in a few hands. It comes back to every community. What has it paid for where you live? [10]

**Young people (5:35).** Find a young person you know, someone who is a child today. In [year] they chose to stay, because something here belongs to them. What is their work? [10] What did the elders pass on to them? [8]

**The hard years (6:15).** It was not easy. [Two or three hard things the scenarios showed, said plainly.] Think of one hard season. [5] What did people do for each other? [10] Who made sure no one was left out? [8]

**Your part (7:05).** Now look back from [year] to this week in [base year]. All of this began with what people did in the first few years. What is one thing you did? [20]

**Come back (7:40).** Choose the one picture from this morning in [year] that you most want to be true. [8] When you are ready, open your eyes. Stay quiet. Pick up your pen and write what you saw.
