---
name: scenarios-vision-writeup
description: Write the guided visualisation script at lunch on day 2, and after the workshop write up the scenarios, insights, shared vision and priorities from recordings, photos and Menti results.
---

# Scenarios and vision write-up

This skill covers two jobs at the end of a participatory foresight workshop: the guided visualisation script, written at lunch on day 2, and the write-up afterwards. It was developed by Ariella Helfgott and SA Futures Agency.

Both jobs have the same rule. The content belongs to the people who were in the room. Report what they built and said, in their words, and keep anything the facilitation team adds clearly separate.

## Job 1. The guided visualisation script (lunch on day 2)

The afternoon of day 2 opens with a guided visualisation: one person reads a script slowly while the room sits quietly and pictures a morning in the target year in which things have gone well. Each person then writes what they saw. The script works best when it uses what the room itself said that morning.

Ask for the report-back recording or transcript, or the facilitators' notes of what each table presented and what the room said in the insights discussion. Then write the script following `references/visualisation-script.md`. It has the shape, the rules and a script to adapt. The team has under an hour, so give them a finished script they can read from a phone or a printed page, about eight minutes long, with every pause marked in seconds.

## Job 2. The write-up (within two weeks)

Ask for:

- the workshop file, with the uncertainties, end states, ratings and skeletons
- photos of every scenario flipchart, and the recording or transcript of each table and of the report-backs
- the insights flipchart
- a photo of the vision table, with the theme names
- the Menti results for all three questions
- photos of the priorities flipcharts
- the fact base
- the recording or notes of the team review, for how the skeletons were chosen

Write the report following `references/write-up.md`. Deliver it as an editable document. Before writing, list what you have for each table and say what is missing. A scenario with no recording and one flipchart photo gets a shorter write-up, and the report says why.

## Rules that matter most

- **Each scenario as its table built it.** Under the name the table chose, with the skeleton's working title beside it. If the table left something out or the story breaks one of its end states, report that. Do not repair it.
- **The same structure for every scenario**, so readers can compare them.
- **Additions kept apart.** Anything the facilitation team adds, such as a harder version of a scenario or a future the room did not build, goes in a separate section marked as the team's own.
- **Facts from the fact base.** Every present-day fact has its source. Nothing about the present is taken from a table's discussion without checking.
- **Plain, factual language about participants.** Report what a table did and said. Do not grade it.
- **Quotes only where they add something**, word for word from the recording, and never attributed to a named person without their agreement.
- **Automatic transcripts are rough.** If a passage is unclear, say so or leave it out. Do not guess what was said.

Follow `references/writing-rules.md` and `references/brand.md`.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
