#!/usr/bin/env python3
"""Count Menti word cloud entries, treating entries that differ only in capitals, spacing,
punctuation or a small spelling slip as the same. This is a first pass. Grouping entries
by meaning is a judgement for the facilitation team.

Usage:  python menti_groups.py ENTRIES.txt
ENTRIES.txt has one entry per line. A line may end with a count, as in "education awareness, 8".
"""
import collections, difflib, re, sys


def norm(s):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s.lower())).strip()


def main(path):
    counts = collections.Counter()
    shown = {}
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        m = re.match(r"^(.*?)[,\t|;]\s*(\d+)$", line)
        text, n = (m.group(1), int(m.group(2))) if m else (line, 1)
        if re.fullmatch(r"[\d ]+", text):
            print(f"left out (looks like a join code): {text}")
            continue
        k = norm(text)
        counts[k] += n
        shown.setdefault(k, text)
    keys = sorted(counts, key=lambda k: -counts[k])
    groups = []
    for k in keys:
        for g in groups:
            if difflib.SequenceMatcher(None, k, g[0]).ratio() >= 0.88:
                g.append(k)
                break
        else:
            groups.append([k])
    rows = sorted(((sum(counts[k] for k in g), g) for g in groups), key=lambda r: -r[0])
    print(f"{sum(counts.values())} responses, {len(rows)} distinct after joining near-identical entries\n")
    for n, g in rows:
        extra = f"   (also: {', '.join(shown[k] for k in g[1:])})" if len(g) > 1 else ""
        print(f"{n:>3}  {shown[g[0]]}{extra}")
    print("\nNext: group these by meaning, name each group in the room's most common wording, and report the counts.")


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__); sys.exit(0 if len(sys.argv) > 1 else 1)
    main(sys.argv[1])
