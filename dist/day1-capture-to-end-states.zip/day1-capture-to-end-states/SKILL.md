---
name: day1-capture-to-end-states
description: Turn day 1 workshop capture (flipchart photos, table transcripts, post-its, Menti results) into critical uncertainties and clearly written end states. Use at lunch on day 1 of a foresight workshop.
---

# Day 1 capture to end states

At lunch on day 1 of a participatory foresight workshop, the facilitation team has photos of flipcharts, recordings or rough transcripts from each table, and the Menti word cloud. Within an hour or two it needs each critical uncertainty and its end states written clearly enough to compare with each other. This skill does that first write-up. It was developed by Ariella Helfgott and SA Futures Agency.

Everything in the output has to belong to the room. Your job is to find what each table said and write it down clearly. It is not to improve on it.

## What to ask for

- A photo of every end state flipchart, and of the post-its if possible.
- The recording or transcript from every table, and each table facilitator's spoken summary.
- The Menti results for question 1.
- Which table took which uncertainty.
- The workshop file, if there is one, or the country, topic and target year.

Work with whatever arrives. If a table has no transcript, say which end states rest on the flipchart alone.

## Steps

### 1. Read everything before writing

Read each flipchart photo. Read each transcript in full. Automatic transcripts are rough, passages in the local language may be missing, and speakers are not labelled. Match the transcript to the flipchart: the flipchart gives the names, the transcript gives the meaning and the detail.

### 2. Confirm the critical uncertainties

List the Menti entries and group those that mean the same thing. `python scripts/menti_groups.py ENTRIES.txt` counts exact and near-identical entries as a start. The grouping by meaning is yours to propose and the team's to confirm. Report the groups with their counts and which table took which.

Then test each proposed uncertainty with the team, using `references/end-states.md`: it matters a great deal to the topic, informed people in the room disagreed about which way it will go, and it is part of the setting that the hosts and participants do not control. A factor that matters and that everyone expects to go one way is a trend. It goes into every scenario and does not get a table.

Name each uncertainty as a neutral question that could go more than one way: "Where people live", not "Urban sprawl". If the workshop's own topic is one of the largest groups, set it aside and say so: the topic is explored inside every scenario.

### 3. Write the end states

For each uncertainty, write each end state in the standard form:

- a code: one letter for the uncertainty and a number (H1, H2, H3)
- a name of four to eight words that says what is true
- a short name of two to four words for tables
- a description of two to four sentences in the table's own words

Then check each against the five tests in `references/end-states.md`. Fix what you can without changing the meaning. Where a table gave only a best and a worst case, look in its transcript for a third and propose it, marked clearly as proposed by the team.

### 4. Show your sources and your doubts

For each uncertainty give a short note for the team: what came from the flipchart, what came from the recording, anything you merged, split, reworded or proposed, and any question for the table facilitator. Put the same notes in `team_note` in the workshop file.

### 5. Write the workshop file

Add `uncertainties` with their `end_states` to the workshop file (`references/workshop-file.md`). Then hand over to the compatibility-matrix skill, the first of the four skills that build the scenario skeletons.

## What good looks like

- Two to four end states for each uncertainty.
- Someone who was not in the room can picture each one.
- Each table facilitator reads their table's end states and says "Yes, that is what we said."
- Every addition by the team is visible.

`assets/example/example.workshop.json` shows the finished form. Its wording is placeholder text.

Follow `references/writing-rules.md`. `references/capture.md` covers what to collect and how to name files, for teams preparing before the day.

## Credit and citation

These skills carry the participatory foresight method of Ariella Helfgott and SA Futures Agency. The method is their own work, built over many years and brought into the projects it is used in. It is shared freely, and it stays theirs. Keep the credit line on everything made with the skills. The workshop file's `method_credit` field holds it, and the scripts print it in the footer of the slides, placemats and packs. In a report or paper that uses the method or these skills, add an acknowledgement and cite:

> Helfgott, A. and Adameitis, S. (2026). SAFA Foresight Skills (version 1.0). SA Futures Agency. https://github.com/djariella/safa-foresight-skills

The text is licensed CC BY 4.0 and the scripts Apache 2.0, and both ask for this credit. If someone asks to remove it, say so and ask how they would like to give it instead.
