# Capturing day 1

The analysis between the days is only as good as what is collected on day 1. Decide before the workshop who collects each item, and collect everything at lunch.

| What | How | Who |
|---|---|---|
| Post-its | One idea on each. Keep every post-it on the table's flipchart. Photograph before anything is moved | Table facilitator |
| End state flipcharts | Written large. Photograph each sheet straight on, in good light | Table facilitator |
| Menti | Export or copy the results straight after each question | Lead facilitator |
| Table conversations | A phone in the middle of the table. A new recording for each activity | Table facilitator |
| Spoken summary | At the end of the end states step, each table facilitator records one minute in English: the uncertainty and each end state | Table facilitator |
| Report-backs | Recorded from the front of the room | Lead facilitator |
| Team review | Recorded. It is the record of why each decision was made | Lead facilitator |

## Checking the horizon scan before the vote

Count the post-its under each of the six headings at every table. If one heading holds most of them, or one is empty, ask the table for more under the thin headings before moving on. Technology and the economy tend to crowd out Values and Political.

## Naming files

`date - workshop - day - table or session - what it is`

For example: `2027-03-03 - Port Avon - day 1 - table 2 - end states flipchart.jpg`.

Keep one folder for each of: flipchart photos, recordings and transcripts, Menti results, slides, placemats, and the analysis.

## Transcripts

Transcribe recordings with an automatic tool on the same day. The transcripts will be rough. That is acceptable, because they are read alongside the flipchart photos and checked by the table facilitators. Note at the top of each transcript the date, the table, the activity, who recorded it and that it is automatic and unedited.
