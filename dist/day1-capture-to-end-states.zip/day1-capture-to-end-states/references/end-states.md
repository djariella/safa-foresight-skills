# Writing end states

An end state is one way a critical uncertainty could turn out by the target year. A scenario skeleton is one end state from each uncertainty, so the quality of the end states decides the quality of the scenarios.

## The form

| Part | Rule | Example |
|---|---|---|
| Code | One capital letter for the uncertainty, a number for the end state | H2 |
| Name | Four to eight words that say what is true | Towns spread outward along the highways |
| Short name | Two to four words, for matrices and tables | Towns spread out |
| Description | Two to four sentences in the table's words | Most new homes are on the edge of towns, where land is cheap. Shops and schools follow the highways. Town centres have fewer residents than today. |

## Five tests

1. **It is a state.** It describes what is true in the target year. If a table wrote an action ("invest in buses", "train drivers"), ask what would be true if that was done and worked, and what would be true if it was not.
2. **It belongs to the room.** Every part can be traced to a flipchart, a post-it or something said at the table. Tidy grammar. Keep their terms.
3. **It is different from the others.** Two end states of the same uncertainty cannot both be true at once. If two overlap, merge them or sharpen the difference.
4. **The set covers the range.** More than a best and a worst case. Look for the mixed one: good for some and hard for others, or solved by someone unexpected, or solved at a price.
5. **The name is neutral.** It describes and does not judge. "Services run only on the main routes", not "The collapse of public transport".

## Prompts that produce a good set

Two sets of prompts work, and a table facilitator can use either.

- The hoped-for end state, the feared one, and a third that is neither.
- What most people expect, the opposite, and another direction altogether. This is the wording in UNDP's foresight guidance, and it is useful when a table is stuck on good and bad.

Start wide and trim. It is easier to merge two end states that turn out to behave alike than to find a missing one later. Keep likelihood out of it: an end state earns its place by being possible and different, and how probable it is does not matter at this step. Both points follow the practice of the CGIAR regional scenarios program and of Ritchey's morphological analysis.

## When a table gives only two extremes

This is common. Look in the transcript for a third end state that the table discussed and did not write up. Tables often describe a middle or mixed outcome in conversation and leave it off the flipchart. Add it, note in `team_note` that it was drawn from the transcript, and confirm it with the table facilitator. An end state added this way is often the one that makes an unexpected scenario possible.

## When a table gives five or more

Propose merging the closest. Four is the most the analysis uses well. Record what was merged.

## When the flipchart and the transcript disagree

The flipchart is what the table agreed to write down. The transcript shows what it meant. Use the flipchart for the names and the transcript for the description, and raise any real disagreement with the table facilitator.

## Testing a critical uncertainty

| Test | Question to ask | If the answer is no |
|---|---|---|
| Important | Would the topic look very different depending on how this turns out? | Leave it out |
| Uncertain | Do informed people in this room disagree about which way it will go? | It is a trend. Put it in every scenario. |
| Part of the setting | Is it outside what the hosts and participants decide themselves? | It is a choice or a goal. It belongs to the vision and priorities on day 2. |
| Distinct | Is it about something different from the other uncertainties? | Merge it with the one it overlaps |

The second test is from UNDP's guidance: disagreement among informed people is the practical sign of high uncertainty. The third is central to the Oxford scenario planning approach, which builds scenarios only from factors in the wider setting.

If there is no internet for the word cloud, give each person three votes for most important and three for most uncertain, and count them on a flipchart. The CGIAR regional scenarios program chose its factors this way.

## Grouping the Menti entries

- Count entries that are the same apart from spelling and capitals as one group.
- Then group by meaning: "public transport", "buses and trains" and "getting around without a car" are one group.
- Name the group with the room's most common wording.
- Report the count for each group and list what is in it, so the team can check.
- Entries that are a join code typed into the answer box are not responses.
- A word cloud shows the room what it said. It is not the analysis. The size of a word depends on how people happened to type it, so the grouping by meaning, checked by the team, is what decides.
