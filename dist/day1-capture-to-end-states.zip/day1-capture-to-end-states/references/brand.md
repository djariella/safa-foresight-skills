# Brand and design for workshop materials

These materials were designed by SA Futures Agency. Every output carries the logo of the organisation that hosts the workshop and the SA Futures Agency credit.

**The host and partner logo files are placeholders.** Before building anything, ask the user for the host's logo and any partner logos. Replace `host_logo.png`, `host_logo_white.png`, `partner_logo_1.png` and `partner_logo_2.png` in `assets/brand` (and in `assets/placemat` where that folder exists) with them. Keep the file names and roughly the same proportions. If there is no partner, delete the partner files and the programs leave that space empty. The SA Futures Agency logo and the credit line stay as they are.

## What goes on every output

- **Host logo.** `assets/brand/host_logo.png` on light backgrounds and `host_logo_white.png` on dark backgrounds.
- **Partner logos.** `partner_logo_1.png` and `partner_logo_2.png`, next to the host logo or in the footer. Use only the ones that apply to the workshop.
- **SA Futures Agency logo.** `assets/brand/safa_dark.png` on light backgrounds, `safa_white.png` on dark backgrounds. Place it at the bottom right of covers and placemats, smaller than the host logo.
- **Credit line.** "Foresight method and materials: SA Futures Agency" in the footer of documents and on the last slide of decks. Do not remove it when adapting the materials.

## Colours

| Use | Colour | Hex |
|---|---|---|
| Headings, table headers | Navy | 28537D |
| Dark backgrounds, covers | Deep navy | 1C3D5E |
| Subheadings, links, day 2 | Teal | 0297A6 |
| Light teal accent | Sky | 46BBD4 |
| Positive, "what good looks like" | Green | 22AD7A |
| Eyebrow labels, emphasis, the team's steps | Orange | E86933 |
| Highlights on dark backgrounds | Yellow | FFD166 |
| Secondary accent | Amber | DD9103 |
| Page and card backgrounds | Light grey | F4F6F7 |
| Body text | Dark grey | 22303C |
| Secondary text | Mid grey | 5B6770 |

Rating colours in matrices: S green 22AD7A, I pale blue DCE6EE, T yellow FFD166, X deep navy 1C3D5E, Q orange E86933.

If the host asks for its own colours, change the navy and teal to the host's two main colours and keep the rating colours. The values are set at the top of `scripts/lib.py` for the placemats and in the style block of each program that writes HTML.

## Type

- Documents and PDFs: Helvetica, with Arial as the fallback.
- PowerPoint: Aptos Display for titles and Aptos for body text, which come with Microsoft 365. Otherwise Arial, so the file opens the same on every computer.
- Titles are bold. Slide titles are in capitals, 30 point, navy. Above each title sits a small "eyebrow" label in orange capitals with wide letter spacing, 12 point.
- Nothing smaller than 9 point in a document, 12 point on a slide, or 11 point on an A3 placemat. People read placemats at arm's length and slides from the back of a room.

## Layout

- White or light grey backgrounds with white cards. One dark navy slide or panel for emphasis, used sparingly.
- A short orange bar above main headings. No rainbow or multicolour stripes.
- Numbered steps as large plain numerals, with the time and who does the step ("on your own", "at your table", "whole room"). Do not draw circles or badges with numbers inside them.
- One idea per slide. Leave space. If a slide needs more than about 60 words, split it.
- Illustrations: the hand-drawn SA Futures Agency illustrations supplied with the placemat kit (compass, path, binoculars, hands). Do not add stock clip art.

## Things to avoid

- Text over photographs without a solid panel behind it.
- More than three colours on one page besides navy, grey and white.
- Centred body text. Left-align it.
- Decorative icons that carry no meaning.

## Working with a host's own template

If the host has its own PowerPoint template or brand guide, use it for the slides: its layouts, fonts, colours and logo rules. Keep the workshop-specific elements from this file on top of it: the eyebrow labels, the step tiles, the rating colours, the placemats and the SA Futures Agency credit.
