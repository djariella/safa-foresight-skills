# Writing rules for workshop materials

The materials are read by people working in a second or third language, often through an interpreter, and by people who were not in the room. Write so that all of them understand the first time.

## Plain language

- Use short, common words. "Use", not "utilise". "Help", not "facilitate". "Businesses", not "firms" or "enterprises".
- One idea in each sentence. Most sentences between 10 and 25 words.
- Say what is meant directly. Avoid slogans, clever phrases and wordplay. They do not translate.
- Do not use "not X, but Y" constructions. State Y.
- Define a method word the first time it appears: horizon scanning, critical uncertainty, end state, scenario, skeleton, vision.
- Call them "scenarios". Do not call them "worlds".
- Do not use dashes to join clauses. Use a full stop or a comma.
- Avoid these words, which add length and no meaning: leverage, robust, holistic, synergy, stakeholders (name who you mean: residents, officials, businesses; the host's own titles can keep the word), outcomes on its own (say what the result is), deliverables, best practice, key learnings, going forward, innovative, transformative, impactful, ecosystem as a metaphor, unpack, deep dive, crucial, pivotal, comprehensive.
- No hedging words to avoid making a claim: perhaps, somewhat, arguably, kind of.

## Tone

- Factual and respectful. Report what a table did and said. Do not judge it, praise it or make fun of it. Write "The table renamed its scenario", not "The table rejected the name".
- Neutral names. An end state or a scenario title describes a situation. It does not say whether the situation is good or bad. "Services shrink to the main routes", not "Collapse". "Buses follow the new estates", not "Sprawl wins".
- Do not describe any group as lacking, backward or failing. Describe the situation and who is affected.

## The room's own words

- End states, scenario names, vision themes and priorities stay in the words the participants used. Tidy the grammar. Do not replace their terms with technical ones.
- Anything the facilitation team added, merged or reworded is marked as such, and confirmed with the table facilitator.

## Facts

- Every present-day fact comes from the workshop's fact base, with its source and year. If a fact is not in the fact base, either leave it out or mark it "to check" with where you found it.
- Do not invent numbers, quotes, names of people or names of organisations.
- Statements about the future are written as part of a scenario ("In this scenario, ...") and never as predictions.

## Scenario text (descriptions, narratives)

- Present tense, set in the target year.
- Describe mechanisms: what changed, what that caused, who gained and who lost.
- Every scenario has good and hard things in it, whichever skeleton it started from.
- No invented characters in read-aloud descriptions. No "imagine". No summary sentence at the end that repeats the text.
- Each scenario in a set follows the same structure, so readers can compare them.
