# The workshop file

All the skills read and write one file for each workshop, called the workshop file (`<place>-<year>.workshop.json`). Each stage adds its part, so the output of one stage is the input of the next. `assets/example/example.workshop.json` is a made-up workshop file, complete at every stage. Its wording is placeholder text that says what belongs in each field, and its ratings are made up so that the programs have something to run on.

The sample below shows the form of each part. Its content is invented for illustration (public transport in a made-up country called Northland) and does not come from a workshop.

```json
{
  "workshop": {
    "title": "Getting around Northland in 2045",
    "country": "Northland", "place": "Port Avon",
    "topic": "public transport", "system": "transport system",
    "vision_phrase": "A transport system that works for everyone in Northland in 2045",
    "target_year": 2045, "base_year": 2027,
    "day1": "Wednesday 3 March 2027", "day2": "Thursday 4 March 2027",
    "hosts": ["Host organisation", "Partner organisation"], "program": "",
    "languages": ["English"], "tables": 4,
    "method_credit": "Foresight method and materials: SA Futures Agency"
  },
  "uncertainties": [
    { "code": "H", "name": "Where people live", "short": "Homes",
      "question": "Where do people live, and how far is that from work, school and shops?",
      "menti_mentions": 11,
      "end_states": [
        { "code": "H2", "name": "Towns spread outward along the highways", "short": "Towns spread out",
          "description": "Most new homes are on the edge of towns, where land is cheap. Shops and schools follow the highways. Town centres have fewer residents than today.",
          "team_note": "" }
      ] }
  ],
  "couplings": [
    { "a": "H", "b": "F", "strength": "strong", "note": "Where people live decides what a service costs to run." }
  ],
  "pairs": [
    { "a": "H2", "b": "F1", "rating": "T", "reason": "", "story": "A levy on new estates pays for buses to reach them.", "contested": false },
    { "a": "H1", "b": "F3", "rating": "X", "kind": "logical", "reason": "F3 as written has no services in town centres after 7 pm. H1 as written has centres where people live without cars." }
  ],
  "family_axes": ["H", "F"],
  "anchor": { "combo": ["H1", "F1", "W1", "P1"], "why": "The future the tables hoped for." },
  "topic_questions": [
    { "id": 1, "short": "Distance", "question": "If most homes are far from the centre, what can public transport still do well?", "heard": "Three of the four tables raised it." }
  ],
  "candidates": [
    { "id": "E", "title": "Buses follow the new estates", "combo": ["H2", "F1", "W2", "P2"], "family": 2, "central": [1, 3], "partly": [4] }
  ],
  "skeletons": [
    { "id": "E", "title": "Buses follow the new estates", "tagline": "Services grow while towns spread out.",
      "combo": ["H2", "F1", "W2", "P2"], "how_it_fits": "...", "asks": "...", "table": "Table 4", "facilitator": "Name" }
  ]
}
```

## Who fills in what

| Part | Filled in by | When |
|---|---|---|
| `workshop` | foresight-workshop-setup | Before the workshop |
| `uncertainties` and `end_states` | day1-capture-to-end-states | Lunch on day 1 |
| `couplings` (optional) and `pairs` | compatibility-matrix, with the team's decisions | Afternoon of day 1 |
| `family_axes`, `candidates` | scenario-families | Afternoon of day 1 |
| `anchor`, `topic_questions`, `skeletons` | scenario-set-selection | Afternoon of day 1 |
| Read by | scenario-day2-materials and scenarios-vision-writeup | Evening of day 1 and afterwards |

## Rules

- Codes: one capital letter for each uncertainty and a number for each end state (F1, F2, W1). Use a different letter for each uncertainty.
- `combo` lists one end state code for each uncertainty, in the same order as `uncertainties`.
- `rating` is one of S, I, T, X, Q. Every T needs a `story`. Every X needs a `reason` and a `kind`: logical or empirical.
- `anchor` is the one combination the team agreed the set of skeletons must contain. Give its `combo` and one line on `why`. A candidate id also works.
- `edges` (optional) records a most `hopeful` and a most `worrying` combination. The program reports whether each is in a set. It does not require them.
- `contested` is true when the team was split on a rating. The sensitivity check uses it.
- `draft_rating` (optional) keeps the first draft of a rating the team later changed. `pairs-import` adds it, and `check` counts the changes for the write-up.
- `excluded_combos` is optional: a list of `{"combo": [...], "reason": "..."}` for combinations the team struck after reading them as wholes.
- `couplings` is optional and helps with large fields. `strength` is strong, conditional or independent. Pairs of end states from independent uncertainties are set to I automatically.
- `short` is a name of two to four words for tables and matrices. If it is missing, the full name is used.
- Keep the file in the workshop's shared folder and save a dated copy before each team review.
